// import React, { Component } from "react";
// import { withStyles } from "@material-ui/core/styles/index";
// import PropTypes from "prop-types";
// import AutorenewIcon from "@material-ui/icons/Autorenew";
// import { Done as DoneIcon } from "@material-ui/icons";
// import { Link } from "react-router-dom";
// import EditIcon from "../../images/icons/web-edit-blue.svg";
// import ViewIcon from "../../images/icons/web-view.svg";
// import TabContainer from "../../components/tabContainer";
// import DialogModel from "../../components/dialogModel";
// import { getAPI, postAPI } from "../../apiBase/apiClient";
// import StorageHelper from "../../helpers/storageHelper";
// import WebBackBlueIcon from "../../components/Icons/WebBackBlue";
// import CreateQuestions from "../createQuestions";
// import Pagination from "react-js-pagination";
// import WebFilterIcon from "../../components/Icons/WebFilter";
// import BreadCrumb from "../../components/BreadCrumb";
// import Dialog from "@material-ui/core/Dialog";
// import MuiDialogTitle from "@material-ui/core/DialogTitle";
// import MuiDialogContent from "@material-ui/core/DialogContent";
// import MuiDialogActions from "@material-ui/core/DialogActions";
// import CloseIcon from "@material-ui/icons/Close";
// import Swal from "sweetalert2";
// import ThumbUpIcon from "@material-ui/icons/ThumbUpAltOutlined";
// import ThumbDownIcon from "@material-ui/icons/ThumbDownAltOutlined";
// import Loading from "react-fullscreen-loading";
// import NoRecord from "../../components/Icons/WebNoRecord.js";
// import {
//   Grid,
//   MenuItem,
//   Paper,
//   TextField,
//   Typography,
//   Tabs,
//   Tab,
//   IconButton,
//   Button,
//   Select,
//   FormControl,
//   Checkbox,
//   List,
//   ListItem,
//   ListItemIcon,
//   ListItemSecondaryAction,
//   ListItemText,
//   Table,
//   TableBody,
//   TableCell,
//   TableHead,
//   TableRow,
//   OutlinedInput
// } from "@material-ui/core";

// const styles1 = theme => ({
//   root: {
//     margin: 0,
//     padding: theme.spacing(2)
//   },
//   closeButton: {
//     position: "absolute",
//     right: theme.spacing(1),
//     top: theme.spacing(1),
//     color: theme.palette.grey[500]
//   }
// });

// const DialogTitle = withStyles(styles1)(props => {
//   const { children, classes, onClose } = props;
//   return (
//     <MuiDialogTitle disableTypography className={classes.root}>
//       <Typography variant="h6">{children}</Typography>
//       {onClose ? (
//         <IconButton
//           aria-label="Close"
//           className={classes.closeButton}
//           onClick={onClose}
//         >
//           <CloseIcon />
//         </IconButton>
//       ) : null}
//     </MuiDialogTitle>
//   );
// });

// const DialogContent = withStyles(theme => ({
//   root: {
//     padding: theme.spacing(2)
//   }
// }))(MuiDialogContent);

// const DialogActions = withStyles(theme => ({
//   root: {
//     margin: 0,
//     padding: theme.spacing(1)
//   }
// }))(MuiDialogActions);

// const storage = new StorageHelper();
// const ITEM_HEIGHT = 48;
// class QuestionListing extends Component {
//   constructor(props) {
//     super(props);
//     this.node = React.createRef();
//     // this.state = {
//     //   city: null,
//     //   age: "",
//     //   dates2: null,
//     //   isCardView: false,
//     //   checked: false,
//     //   readMore: false,
//     //   activeTab:
//     //     storage.getValue("role_id") === 6
//     //       ? ""
//     //       : storage.getValue("role_id") === 8
//     //       ? JSON.stringify([7])
//     //       : storage.getValue("role_id") === 9
//     //       ? JSON.stringify([11])
//     //       : storage.getValue("role_id") === 7
//     //       ? JSON.stringify([3, 4])
//     //       : "",
//     //   dialogPopup: false,
//     //   QuestionList: [],
//     //   status:
//     //     storage.getValue("role_id") === 6
//     //       ? ""
//     //       : storage.getValue("role_id") === 8
//     //       ? JSON.stringify([7])
//     //       : storage.getValue("role_id") === 9
//     //       ? JSON.stringify([11])
//     //       : storage.getValue("role_id") === 7
//     //       ? JSON.stringify([3, 4])
//     //       : "",
//     //   selectedIndex: 1,
//     //   GetAllQuestions: [],
//     //   dashboard_count: [],
//     //   page: 1,
//     //   totalcount: "",
//     //   question_type: [],
//     //   question_category: [],
//     //   nos: [],
//     //   pc: [],
//     //   difficulty_level: [],
//     //   difficulty_level_id: "",
//     //   question_type_id: "",
//     //   question_category_id: "",
//     //   nos_id: "",
//     //   pc_id: "",
//     //   questionID: "",
//     //   reason: "",
//     //   open: false,
//     //   users_list: [],
//     //   users_list_id: "",
//     //   get_roles_id: 8,
//     //   allChecked: false,
//     //   view_question: [],
//     //   question_relation: [],
//     //   question_options: [],
//     //   response_content: [],
//     //   question_type_res: [],
//     //   question_category_res: [],
//     //   nos_res: [],
//     //   pc_res: [],
//     //   question_score_res: [],
//     //   question_answer_res: [],
//     //   isLoadingComplete: 0,
//     //   qid: "",
//     //   question_method_id: "",
//     //   question_method: [],
//     //   qm_res: []
//     // };
//   }

//   handleCloseDialogNew = () => {
//     this.setState({ open: false });
//   };
//   componentDidMount() {
//     this.renderMath();
//   }

//   componentDidUpdate() {
//     this.renderMath();
//   }
//   renderMath() {
//     window.MathJax.Hub.Queue([
//       "Typeset",
//       window.MathJax.Hub,
//       this.node.current
//     ]);
//   }
//   async componentWillMount() {
//     const s = this.state.status;
//     this.loadData(s);
//   }
//   async editQuestion(ev) {
//     await this.setState({ questionID: ev.currentTarget.dataset.id });
//   }
//   async viewQuestions(ev) {
//     let question_id = ev.currentTarget.dataset.id;
//     this.setState({ isLoadingComplete: 0 });
//     // this.triggerApi(
//     //   `GetIndividualQuestionView?question_id=${question_id}&language_id=1`,
//     //   "v1",
//     //   "view_question"
//     // );
//     this.dialogPopupClick();
//   }
//   // loadData(s) {
//   //   let url = [
//   //     {
//   //       url: `GetUserDashboardCount?language_id=1&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_role_id=${storage.getValue(
//   //         "user_role_id"
//   //       )}&user_id=${storage.getValue("user_id")}`,
//   //       version: "v1",
//   //       state: "dashboard_count"
//   //     },
//   //     {
//   //       url: `GetUserListBasedonRoleId?role_id=${
//   //         this.state.get_roles_id
//   //       }&user_role_id=${storage.getValue("user_role_id")}`,
//   //       version: "v1",
//   //       state: "users_list"
//   //     },
//   //     {
//   //       url: `GetDropdownMasterData?master_type=question_type&master_id=&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&user_role_id=${storage.getValue("user_role_id")}`,
//   //       version: "v1",
//   //       state: "question_type"
//   //     },
//   //     {
//   //       url: `GetDropdownMasterData?master_type=nos&master_id=&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&user_role_id=${storage.getValue("user_role_id")}`,
//   //       version: "v1",
//   //       state: "nos"
//   //     },
//   //     {
//   //       url: `GetDropdownMasterData?master_type=difficulty_level&master_id=&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&user_role_id=${storage.getValue("user_role_id")}`,
//   //       version: "v1",
//   //       state: "difficulty_level"
//   //     },
//   //     {
//   //       url: `GetUserQuestionView?status=${
//   //         this.state.status
//   //       }&language_id=1&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_role_id=${storage.getValue(
//   //         "user_role_id"
//   //       )}&user_id=${storage.getValue("user_id")}`,
//   //       version: "v1",
//   //       state: "QuestionList"
//   //     }
//   //   ];

//   //   for (let i = 0; i < url.length; i++) {
//   //     let link = url[i];
//   //     this.triggerApi(link.url, link.version, link.state);
//   //   }
//   // }
//   // async triggerApi(url, version, state) {
//   //   let requestData = {
//   //     url: url,
//   //     token: storage.getValue("token")
//   //   };
//   //   const response = await getAPI(requestData, this.props, version);

//   //   if (response) {
//   //     if (parseInt(response.status) === 200) {
//   //       if (state === "QuestionList") {
//   //         if (response.content.rows && storage.getValue("role_id") !== 6) {
//   //           let question_res = response.content.rows;
//   //           question_res.map(i => (i.isChecked = false));
//   //           this.setState({
//   //             QuestionList: response.content.rows,
//   //             totalcount: response.content.count,
//   //             isLoadingComplete: 1
//   //           });
//   //         } else {
//   //           this.setState({
//   //             QuestionList: response.content.rows,
//   //             totalcount: response.content.count,
//   //             isLoadingComplete: 1
//   //           });
//   //         }
//   //       } else if (state === "dashboard_count") {
//   //         this.setState({ [state]: response.content });
//   //       } else if (state === "users_list") {
//   //         this.setState({
//   //           [state]: response.content ? response.content : "",
//   //           isLoadingComplete: 1
//   //         });
//   //       } else if (state === "view_question") {
//   //         this.setState({
//   //           response_content: response.content ? response.content : "",
//   //           question_relation: response.content
//   //             ? response.content.QuestionTranslation
//   //             : "",
//   //           question_options: response.content.QuestionTranslation
//   //             ? response.content.QuestionTranslation.QuestionOptions
//   //             : "",
//   //           question_type_res: response.content.QuestionMaster
//   //             ? response.content.QuestionMaster.QuestionTypeEnumeration
//   //             : "",
//   //           question_category_res: response.content.QuestionMaster
//   //             ? response.content.QuestionMaster.QuestionCategory
//   //             : "",
//   //           qm_res: response.content.QuestionMaster.QM
//   //             ? response.content.QuestionMaster.QM.QmTranslation
//   //             : "",
//   //           nos_res: response.content.QuestionMaster
//   //             ? response.content.QuestionMaster.NO.NosTranslation
//   //             : "",
//   //           pc_res: response.content.QuestionMaster
//   //             ? response.content.QuestionMaster.PC.PcTranslation
//   //             : "",
//   //           question_score_res: response.content.QuestionMaster
//   //             ? response.content.QuestionMaster
//   //             : "",
//   //           question_answer_res: response.content.QuestionTranslation
//   //             ? response.content.QuestionTranslation.QuestionAnswers
//   //             : "",
//   //           isLoadingComplete: 1
//   //         });
//   //       } else {
//   //         this.setState({
//   //           [state]: response.content ? response.content.master : "",
//   //           isLoadingComplete: 1
//   //         });
//   //       }
//   //       if (
//   //         this.state.QuestionList !== "" &&
//   //         this.state.dashboard_count !== ""
//   //       ) {
//   //         this.setState({
//   //           isLoadingComplete: 1
//   //         });
//   //       }
//   //     } else if (parseInt(response.status) === 400) {
//   //       this.setState({ error: response.content.error });
//   //     }
//   //   }
//   // }
//   masterLoad(data) {
//     let master_list_array = [];
//     for (let i = 0; i < data.length; i++) {
//       master_list_array.push(
//         <MenuItem value={data[i].id} key={data[i].id}>
//           {data[i].name}
//         </MenuItem>
//       );
//     }
//     return master_list_array;
//   }
//   // handlePageChange(pageNumber) {
//   //   this.setState({ page: pageNumber, isLoadingComplete: 0 });
//   //   if (
//   //     this.state.question_type_id ||
//   //     this.state.question_category_id ||
//   //     this.state.nos_id ||
//   //     this.state.pc_id ||
//   //     this.state.difficulty_level_id
//   //   ) {
//   //     this.setState({
//   //       isLoadingComplete: 0
//   //     });
//   //     this.triggerApi(
//   //       `GetUserQuestionView?search=1&status=${
//   //         this.state.status
//   //       }&language_id=1&question_type_id=${
//   //         this.state.question_type_id
//   //       }&question_category_id=${
//   //         this.state.question_category_id
//   //       }&question_method_id=${this.state.question_method_id}&nos_id=${
//   //         this.state.nos_id
//   //       }&pc_id=${this.state.pc_id}&difficulty_level_id=${
//   //         this.state.difficulty_level_id
//   //       }&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_role_id=${storage.getValue(
//   //         "user_role_id"
//   //       )}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&page=${pageNumber}&page_size=10`,
//   //       "v1",
//   //       "QuestionList"
//   //     );
//   //   } else {
//   //     this.triggerApi(
//   //       `GetUserQuestionView?status=${
//   //         this.state.status
//   //       }&language_id=1&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_role_id=${storage.getValue(
//   //         "user_role_id"
//   //       )}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&page=${pageNumber}&page_size=10`,
//   //       "v1",
//   //       "QuestionList"
//   //     );
//   //   }
//   // }
//   handleToggle(event) {
//     this.setState({ checked: event.target.checked });
//   }

//   handleClick() {
//     alert("You clicked the Chip.");
//   }
//   readMoreClick() {
//     this.setState({
//       readMore: true
//     });
//   }
//   // handleChange(event) {
//   //   this.setState({
//   //     [event.target.name]: event.target.value
//   //   });
//   //   if (event.target.name === "question_type_id") {
//   //     this.setState({
//   //       question_category_id: "",
//   //       isLoadingComplete: 0
//   //     });
//   //     this.triggerApi(
//   //       `GetDropdownMasterData?master_type=question_category&master_id=${
//   //         event.target.value
//   //       }&role_id=${storage.getValue("role_id")}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&user_role_id=${storage.getValue("user_role_id")}`,
//   //       "v1",
//   //       "question_category"
//   //     );
//   //   }
//   //   if (event.target.name === "nos_id") {
//   //     this.setState({
//   //       pc_id: "",
//   //       isLoadingComplete: 0
//   //     });
//   //     this.triggerApi(
//   //       `GetDropdownMasterData?master_type=pc&master_id=${
//   //         event.target.value
//   //       }&role_id=${storage.getValue("role_id")}&user_id=${storage.getValue(
//   //         "user_id"
//   //       )}&user_role_id=${storage.getValue("user_role_id")}`,
//   //       "v1",
//   //       "pc"
//   //     );
//   //   }
//   //   if (
//   //     event.target.name === "question_category_id" &&
//   //     this.state.question_type_id === 1
//   //   ) {
//   //     this.setState({
//   //       question_method_id: "",
//   //       isLoadingComplete: 0
//   //     });
//   //     this.triggerApi(
//   //       `GetDropdownMasterData?master_type=qm&master_id=${event.target.value}`,
//   //       "v1",
//   //       "question_method"
//   //     );
//   //   }
//   // }
//   // async handleTabChange(event, value) {
//   //   await this.setState({
//   //     activeTab: value,
//   //     status: value,
//   //     isLoadingComplete: 0,
//   //     page: 1
//   //   });

//   //   this.triggerApi(
//   //     `GetUserQuestionView?status=${value}&language_id=1&role_id=${storage.getValue(
//   //       "role_id"
//   //     )}&user_role_id=${storage.getValue(
//   //       "user_role_id"
//   //     )}&user_id=${storage.getValue("user_id")}&page=${
//   //       this.state.page
//   //     }&page_size=10`,
//   //     "v1",
//   //     "QuestionList"
//   //   );
//   // }

//   // searchQuestions() {
//   //   if (
//   //     this.state.question_type_id ||
//   //     this.state.question_category_id ||
//   //     this.state.nos_id ||
//   //     this.state.pc_id ||
//   //     this.state.difficulty_level_id
//   //   ) {
//   //     this.setState({
//   //       isLoadingComplete: 0
//   //     });
//   //     this.triggerApi(
//   //       `GetUserQuestionView?search=1&status=${
//   //         this.state.status
//   //       }&language_id=1&question_type_id=${
//   //         this.state.question_type_id
//   //       }&question_category_id=${
//   //         this.state.question_category_id
//   //       }&question_method_id=${this.state.question_method_id}&nos_id=${
//   //         this.state.nos_id
//   //       }&pc_id=${this.state.pc_id}&difficulty_level_id=${
//   //         this.state.difficulty_level_id
//   //       }&role_id=${storage.getValue(
//   //         "role_id"
//   //       )}&user_role_id=${storage.getValue(
//   //         "user_role_id"
//   //       )}&user_id=${storage.getValue("user_id")}`,
//   //       "v1",
//   //       "QuestionList"
//   //     );
//   //   } else {
//   //     Swal.fire("Warning!", "Choose filter option", "warning");
//   //   }
//   // }
//   async resetQuestion() {
//     await this.setState({
//       question_type_id: "",
//       question_category_id: "",
//       question_method_id: "",
//       nos_id: "",
//       pc_id: "",
//       pc: [],
//       question_category: [],
//       page: 1,
//       isLoadingComplete: 0,
//       allChecked: false,
//       difficulty_level_id: ""
//     });
//     this.loadData(this.state.status);
//   }

//   selectHandleChange(event) {
//     this.setState({
//       age: event.target.value
//     });
//   }

//   handleClose() {
//     this.setState({ dialogPopup: false });
//   }

//   dialogPopupClick() {
//     this.setState({ dialogPopup: true });
//   }

//   getOptionValues() {
//     const optionArray = [];
//     for (let i = 0; i < this.state.GetAllQuestions.length; i++) {
//       optionArray.push(
//         <List style={{ marginLeft: "10%", padding: 0 }}>
//           <ListItem style={{ padding: 0 }}>
//             <ListItemText
//               disableTypography
//               primary={
//                 this.state.GetAllQuestions.QuestionTranslation.QuestionOptions[
//                   i
//                 ]
//                   ? this.state.GetAllQuestions.QuestionTranslation
//                       .QuestionOptions[i].options
//                   : ""
//               }
//             />
//           </ListItem>
//         </List>
//       );
//     }
//     return optionArray;
//   }

//   dialogContent() {
//     const questionsData = this.state.question_relation;
//     const question_options = this.state.question_options;
//     const response_content = this.state.response_content;
//     const get_question_type = this.state.question_type_res;
//     const get_category_type = this.state.question_category_res;
//     const get_nos = this.state.nos_res;
//     const get_qm = this.state.qm_res;
//     const get_pc = this.state.pc_res;
//     const question_masters = this.state.question_score_res;
//     const question_answers = this.state.question_answer_res;
//     let array = [];
//     const setter_quetion_answer = this.state.question_answer_res;
//     for (let i = 0; i < setter_quetion_answer.length; i++) {
//       let setter_questi = setter_quetion_answer[i];
//       for (let j = 0; j < question_options.length; j++) {
//         let question_op = question_options[j];
//         if (setter_questi.option_id === question_op.id) {
//           array.push(question_op.options);
//         }
//       }
//     }

//     return (
//       <div>
//         <Paper>
//           <Table>
//             <TableHead>
//               <TableRow style={{ background: "white" }}>
//                 <TableCell width="15%">
//                   <strong>Question</strong>
//                 </TableCell>
//                 <TableCell width="1%">
//                   <strong>:</strong>
//                 </TableCell>
//                 <TableCell>
//                   {questionsData ? this.ShowHtml(questionsData.questions) : ""}
//                 </TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               <TableRow>
//                 <TableCell component="th" scope="row">
//                   <strong> Question Type</strong>
//                 </TableCell>
//                 <TableCell>
//                   <strong>:</strong>
//                 </TableCell>
//                 <TableCell>
//                   {get_question_type ? get_question_type.name : ""}
//                 </TableCell>
//               </TableRow>
//               <TableRow>
//                 <TableCell component="th" scope="row">
//                   <strong> Question Category</strong>
//                 </TableCell>
//                 <TableCell>
//                   <strong>:</strong>
//                 </TableCell>
//                 <TableCell>
//                   {get_category_type ? get_category_type.name : ""}
//                 </TableCell>
//               </TableRow>
//               {question_masters.question_type_id === 1 ? (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Question Method</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>{get_qm ? get_qm.qm : "---"}</TableCell>
//                 </TableRow>
//               ) : (
//                 ""
//               )}
//               <TableRow>
//                 <TableCell component="th" scope="row">
//                   <strong> Nos</strong>
//                 </TableCell>
//                 <TableCell>
//                   <strong>:</strong>
//                 </TableCell>
//                 <TableCell> {get_nos ? get_nos.nos : ""}</TableCell>
//               </TableRow>
//               <TableRow>
//                 <TableCell component="th" scope="row">
//                   <strong> PC</strong>
//                 </TableCell>
//                 <TableCell>
//                   <strong>:</strong>
//                 </TableCell>
//                 <TableCell>{get_pc ? get_pc.pc : ""}</TableCell>
//               </TableRow>
//               {question_masters.question_type_id === 1 ? (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Options</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {question_options
//                       ? question_options.map(item => (
//                           <List style={{ padding: 0 }}>
//                             <ListItem style={{ padding: 0 }}>
//                               <ListItemText
//                                 disableTypography
//                                 primary={
//                                   item ? this.ShowHtml(item.options) : ""
//                                 }
//                               />
//                             </ListItem>
//                           </List>
//                         ))
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") === 8 ? (
//                 ""
//               ) : (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong>
//                       {" "}
//                       {question_masters.question_type_id === 1
//                         ? "Setter Correct Answers "
//                         : ""}{" "}
//                     </strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {question_masters.question_type_id === 1 ? (
//                       <List style={{ padding: 0 }}>
//                         <ListItem style={{ padding: 0 }}>
//                           <ListItemText
//                             disableTypography
//                             primary={array ? this.ShowHtml(array) : ""}
//                           />
//                         </ListItem>
//                       </List>
//                     ) : (
//                       ""
//                     )}
//                   </TableCell>
//                 </TableRow>
//               )}

//               {storage.getValue("role_id") !== 8 &&
//               JSON.stringify(this.state.status) !== JSON.stringify([7]) &&
//               question_masters.question_type_id === 2 ? (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong>
//                       {question_masters.question_type_id === 2
//                         ? "Exam Answers"
//                         : ""}
//                     </strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {question_answers
//                       ? question_answers.map(item => (
//                           <List style={{ padding: 0 }}>
//                             <ListItem style={{ padding: 0 }}>
//                               <ListItemText
//                                 disableTypography
//                                 primary={
//                                   item ? this.ShowHtml(item.exam_answer) : ""
//                                 }
//                               />
//                             </ListItem>
//                           </List>
//                         ))
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               ) : (
//                 ""
//               )}

//               {(storage.getValue("role_id") === 8 &&
//                 JSON.stringify(this.state.status) === JSON.stringify([7])) ||
//               storage.getValue("role_id") === 7 ? (
//                 ""
//               ) : (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Setter Reference</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {response_content
//                       ? this.ShowHtml(response_content.setter_reference)
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               )}

//               {(question_masters.question_type_id === 1 &&
//                 storage.getValue("role_id") === 8 &&
//                 JSON.stringify(this.state.status) === JSON.stringify([7])) ||
//               storage.getValue("role_id") === 7 ? (
//                 ""
//               ) : (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Moderator Answer</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {response_content.moderator_answer
//                       ? response_content.moderator_answer.map(item => (
//                           <List style={{ padding: 0 }}>
//                             <ListItem style={{ padding: 0 }}>
//                               <ListItemText
//                                 disableTypography
//                                 primary={
//                                   item ? this.ShowHtml(item.options) : ""
//                                 }
//                               />
//                             </ListItem>
//                           </List>
//                         ))
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               )}

//               {(storage.getValue("role_id") === 8 &&
//                 JSON.stringify(this.state.status) === JSON.stringify([7])) ||
//               storage.getValue("role_id") === 7 ? (
//                 ""
//               ) : (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Rejected Reason</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {response_content
//                       ? this.ShowHtml(response_content.rejected_reason)
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               )}

//               {(storage.getValue("role_id") === 8 &&
//                 JSON.stringify(this.state.status) === JSON.stringify([7])) ||
//               storage.getValue("role_id") === 7 ? (
//                 ""
//               ) : (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Moderator Reference</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {response_content
//                       ? this.ShowHtml(response_content.moderator_reference)
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               )}
//               {storage.getValue("role_id") === 9 ? (
//                 <TableRow>
//                   <TableCell component="th" scope="row">
//                     <strong> Moderator Comment</strong>
//                   </TableCell>
//                   <TableCell>
//                     <strong>:</strong>
//                   </TableCell>
//                   <TableCell>
//                     {response_content
//                       ? this.ShowHtml(response_content.moderator_comment)
//                       : ""}
//                   </TableCell>
//                 </TableRow>
//               ) : (
//                 ""
//               )}
//             </TableBody>
//           </Table>
//         </Paper>
//       </div>
//     );
//   }

//   primaryData(primaryText) {
//     return (
//       <div>
//         {!this.state.readMore && (
//           <p>
//             {primaryText.slice(0, 150) + "...."}
//             <span>
//               <Link onClick={this.readMoreClick.bind(this)}> Read More</Link>
//             </span>
//           </p>
//         )}
//         {this.state.readMore && <p>{primaryText}</p>}
//       </div>
//     );
//   }
//   async approveRejectQuestion(id, operationType) {
//     let dom = document.createElement("DIV");
//     dom.innerHTML = this.state.reason;
//     let plain_text = dom.textContent || dom.innerText;

//     if (plain_text.trim() === "" && operationType === 0) {
//       Swal.fire("", "Enter reason", "error");
//     } else if (plain_text.trim().length > 250) {
//       Swal.fire("", "Length should not be greater than 250", "error");
//     } else {
//       this.setState({ isLoadingComplete: 0 });
//       let requestData = {
//         url: `PostQuestionApproveReject`,
//         payload: {
//           operation: storage.getValue("role_id") === 6 ? "setter" : "flqc",
//           type: operationType === 0 ? "" + operationType : 1,
//           question_id: [id],
//           user_id: storage.getValue("user_id"),
//           user_role_id: storage.getValue("user_role_id"),
//           role_id: storage.getValue("role_id"),
//           rejected_reason: this.state.reason ? this.state.reason : ""
//         },
//         token: storage.getValue("token")
//       };

//       const response = await postAPI(requestData, this.props, "v1");

//       if (response) {
//         if (parseInt(response.status) === 200) {
//           await this.actionTrigger();
//           this.setState({
//             open: false,
//             reason: "",
//             isLoadingComplete: 1
//           });
//           Swal.fire(
//             "Success",
//             operationType === 0
//               ? "Rejected successfully"
//               : "Approved successfully",
//             "success"
//           );
//         } else {
//           Swal.fire("Failed", "Question Not Assigning.", "error");
//         }
//         this.setState({
//           isLoadingComplete: 1
//         });
//       }
//     }
//   }
//   actionTrigger() {
//     if (
//       this.state.question_type_id ||
//       this.state.question_category_id ||
//       this.state.question_method_id ||
//       this.state.nos_id ||
//       this.state.pc_id ||
//       this.state.difficulty_level_id
//     ) {
//       this.setState({
//         isLoadingComplete: 0
//       });
//       this.triggerApi(
//         `GetUserQuestionView?search=1&status=${
//           this.state.status
//         }&language_id=1&question_type_id=${
//           this.state.question_type_id
//         }&question_category_id=${
//           this.state.question_category_id
//         }&question_method_id=${this.state.question_method_id}&nos_id=${
//           this.state.nos_id
//         }&pc_id=${this.state.pc_id}&difficulty_level_id=${
//           this.state.difficulty_level_id
//         }&role_id=${storage.getValue(
//           "role_id"
//         )}&user_role_id=${storage.getValue(
//           "user_role_id"
//         )}&user_id=${storage.getValue("user_id")}&page=${
//           this.state.page
//         }&page_size=10`,
//         "v1",
//         "QuestionList"
//       );
//     } else {
//       this.triggerApi(
//         `GetUserQuestionView?status=${
//           this.state.status
//         }&language_id=1&role_id=${storage.getValue(
//           "role_id"
//         )}&user_role_id=${storage.getValue(
//           "user_role_id"
//         )}&user_id=${storage.getValue("user_id")}&page=${
//           this.state.page
//         }&page_size=10`,
//         "v1",
//         "QuestionList"
//       );
//     }

//     this.triggerApi(
//       `GetUserDashboardCount?language_id=1&role_id=${storage.getValue(
//         "role_id"
//       )}&user_role_id=${storage.getValue(
//         "user_role_id"
//       )}&user_id=${storage.getValue("user_id")}`,
//       "v1",
//       "dashboard_count"
//     );
//   }

//   handleCheckbox(e) {
//     let itemName = e.target.name;
//     let checked = e.target.checked;
//     this.setState(prevState => {
//       let { QuestionList, allChecked } = prevState;
//       if (itemName === "checkAll") {
//         allChecked = checked;
//         QuestionList = QuestionList.map(item => ({
//           ...item,
//           isChecked: checked
//         }));
//       } else {
//         QuestionList = QuestionList.map(item =>
//           "question_list" + item.question_id === itemName
//             ? { ...item, isChecked: checked }
//             : item
//         );
//         allChecked = QuestionList.every(item => item.isChecked);
//       }
//       return { QuestionList, allChecked };
//     });

//     const options = [];
//     this.state.QuestionList.map(function(item, i) {
//       if (item.isChecked === false) {
//         options.push(item.question_id);
//       }
//       return options;
//     });
//   }

//   triggerClick = () => {
//     this.setState({
//       open: true
//     });
//   };
//   handleClickOpen1(id) {
//     this.setState({
//       open: true,
//       qid: id
//     });
//   }

//   questionAction(qid, qstatus) {
//     let options = [
//       <IconButton
//         edge="end"
//         aria-label="View"
//         data-id={qid}
//         onClick={this.viewQuestions.bind(this)}
//       >
//         <img src={ViewIcon} alt="" height={30} />
//       </IconButton>
//     ];
//     if (
//       qstatus === 2 ||
//       qstatus === 1 ||
//       qstatus === 5 ||
//       (qstatus === 9 && storage.getValue("role_id") === 6) ||
//       (qstatus === 9 && (qstatus === 7 && storage.getValue("role_id") !== 8)) ||
//       storage.getValue("role_id") === 7 ||
//       (qstatus === 7 && storage.getValue("role_id") === 8) ||
//       storage.getValue("role_id") === 9
//     ) {
//       options.push(
//         <IconButton
//           size="medium"
//           edge="end"
//           aria-label="Edit"
//           data-id={qid}
//           onClick={this.editQuestion.bind(this)}
//         >
//           <img src={EditIcon} alt="" height={25} />
//         </IconButton>
//       );
//     }
//     if (
//       (qstatus === 1 && storage.getValue("role_id") === 6) ||
//       (qstatus === 3 && storage.getValue("role_id") === 7)
//     ) {
//       options.push(
//         <IconButton
//           color="primary"
//           size="medium"
//           onClick={() => {
//             Swal.fire({
//               title: "Are you sure you wish to active this question?",
//               type: "warning",
//               showCancelButton: true,
//               confirmButtonColor: "#24324d",
//               cancelButtonColor: "#d5d5d5",
//               confirmButtonText: "Confirm"
//             }).then(result => {
//               if (result.value) {
//                 this.approveRejectQuestion(qid, 1);
//               }
//             });
//           }}
//         >
//           <ThumbUpIcon />
//         </IconButton>
//       );
//     }
//     if (qstatus === 3 && storage.getValue("role_id") === 7) {
//       options.push(
//         <React.Fragment>
//           <IconButton
//             color="secondary"
//             onClick={this.handleClickOpen1.bind(this, qid)}
//             size="medium"
//             aria-label="Photo"
//           >
//             <ThumbDownIcon />
//           </IconButton>
//           <Dialog
//             disableBackdropClick
//             fullWidth={"sm"}
//             maxWidth={"sm"}
//             onClose={this.handleCloseDialogNew}
//             aria-labelledby="customized-dialog-title"
//             open={this.state.open}
//           >
//             <DialogTitle
//               id="customized-dialog-title"
//               onClose={this.handleCloseDialogNew}
//             >
//               Reject Reason
//             </DialogTitle>
//             <DialogContent dividers>
//               <DialogActions
//                 style={{
//                   width: "100%",
//                   display: "flex",
//                   justifyContent: "center",
//                   alignItems: "center",
//                   flexDirection: "column"
//                 }}
//                 margin={{ top: 5 }}
//               >
//                 <FormControl style={{ width: "100%" }}>
//                   <TextField
//                     name="reason"
//                     id="outlined-multiline-static"
//                     label="Multiline"
//                     multiline
//                     rows="6"
//                     value={this.state.reason}
//                     onChange={this.handleChange.bind(this)}
//                     margin="dense"
//                     variant="outlined"
//                     inputProps={{ maxLength: 250 }}
//                   />
//                 </FormControl>

//                 <FormControl style={{ marginTop: "20px" }}>
//                   <Button
//                     variant="contained"
//                     color="primary"
//                     onClick={this.approveRejectQuestion.bind(
//                       this,
//                       this.state.qid,
//                       0
//                     )}
//                   >
//                     Update
//                   </Button>
//                 </FormControl>
//               </DialogActions>
//             </DialogContent>
//           </Dialog>
//         </React.Fragment>
//       );
//     }
//     return <ListItemSecondaryAction>{options}</ListItemSecondaryAction>;
//   }
//   ShowHtml(props) {
//     return <div dangerouslySetInnerHTML={{ __html: props }} />;
//   }
//   QuestionListView() {
//     const question_list = this.state.QuestionList;
//     if (!question_list) {
//       return 0;
//     }
//     const { classes } = this.props;
//     let questions = [];

//     for (let i = 0; i < question_list.length; i++) {
//       let get_questions = question_list[i];
//       let check_name = "question_list" + get_questions.question_id;
//       questions.push(
//         <div className={classes.cardMargin}>
//           <Grid container spacing={1}>
//             <Grid item xs={12}>
//               <List className={classes.root}>
//                 {/* {[0, 1, 2, 3].map(value => { */}
//                 {/* const labelId = `checkbox-list-label-${value}`; */}
//                 <Paper>
//                   <ListItem>
//                     <Grid
//                       container
//                       style={{
//                         display: "flex",
//                         justifyContent: "flex-start",
//                         alignItems: "center",
//                         flexDirection: "row"
//                       }}
//                       spacing={0}
//                     >
//                       {storage.getValue("role_id") === 6 ||
//                       storage.getValue("role_id") === 8 ||
//                       storage.getValue("role_id") === 9 ? (
//                         ""
//                       ) : (
//                         <Grid item>
//                           <ListItemIcon>
//                             <Checkbox
//                               style={{ padding: "5px 0px" }}
//                               color="primary"
//                               type="checkbox"
//                               disabled={
//                                 get_questions.status === 3 ? true : false
//                               }
//                               key={get_questions.question_id}
//                               name={check_name}
//                               value={get_questions.question_id}
//                               checked={
//                                 get_questions.status === 3
//                                   ? false
//                                   : get_questions.isChecked
//                               }
//                               onChange={this.handleCheckbox.bind(this)}
//                               tabIndex={-1}
//                               disableRipple
//                               inputProps={{ "aria-labelledby": "" }}
//                             />
//                           </ListItemIcon>
//                         </Grid>
//                       )}
//                       <Grid item xs={9}>
//                         <ListItemText
//                           className="QuestionContainer"
//                           disableTypography
//                           style={{ fontSize: "0.9rem" }}
//                           primary={
//                             get_questions.QuestionTranslation
//                               ? this.ShowHtml(
//                                   get_questions.QuestionTranslation.questions
//                                 )
//                               : ""
//                           }
//                         />
//                       </Grid>
//                       <Grid item>
//                         {this.questionAction(
//                           get_questions.question_id,
//                           get_questions.status
//                         )}
//                       </Grid>
//                     </Grid>
//                   </ListItem>
//                 </Paper>
//                 {/* })} */}
//               </List>
//             </Grid>
//           </Grid>
//         </div>
//       );
//     }
//     return questions;
//   }
//   DynamicDashboardCount() {
//     let element = [];
//     let dynamic_dash_content = [];
//     for (let index = 0; index < this.state.dashboard_count.length; index++) {
//       if (storage.getValue("role_id") === 6) {
//         dynamic_dash_content = [
//           {
//             name: "Submitted Questions",
//             count: this.state.dashboard_count[index].submitted_question,
//             status: ""
//           },
//           {
//             name: "Rejected (First Level Quality Check)",
//             count: this.state.dashboard_count[index].flqc_rejected,
//             status: [5]
//           },
//           {
//             name: "Rejected (Answer Key Mismatch)",
//             count: this.state.dashboard_count[index].moderator_rejected,
//             status: [9]
//           },
//           {
//             name: "Accepted",
//             count: this.state.dashboard_count[index].accepted,
//             status: [13]
//           }
//         ];
//       }
//       if (storage.getValue("role_id") === 7) {
//         dynamic_dash_content = [
//           {
//             name: "Pending Questions",
//             count: this.state.dashboard_count[index].flqc_pending_question,
//             status: [3, 4]
//           }
//         ];
//       }
//       if (storage.getValue("role_id") === 8) {
//         dynamic_dash_content = [
//           {
//             name: "Pending Questions",
//             count: this.state.dashboard_count[index].moderator_pending_question,
//             status: [7]
//           },
//           {
//             name: "Questions Reviewed",
//             count: this.state.dashboard_count[index].question_review,
//             status: [8, 10, 11]
//           },
//           {
//             name: "Rejected(Answer key Mismatch)",
//             count: this.state.dashboard_count[index].question_rejected,
//             status: [9]
//           },
//           {
//             name: "Accepted",
//             count: this.state.dashboard_count[index].accepted_question,
//             status: [13]
//           }
//         ];
//       }
//       if (storage.getValue("role_id") === 9) {
//         dynamic_dash_content = [
//           {
//             name: "Pending Questions",
//             count: this.state.dashboard_count[index].qc_pending_questions,
//             status: [11]
//           }
//         ];
//       }
//     }

//     for (let index = 0; index < dynamic_dash_content.length; index++) {
//       element.push(
//         <Tab
//           key={index}
//           wrapped
//           value={
//             dynamic_dash_content[index].status
//               ? JSON.stringify(dynamic_dash_content[index].status)
//               : ""
//           }
//           label={
//             dynamic_dash_content[index].name +
//             "(" +
//             dynamic_dash_content[index].count +
//             ")"
//           }
//         />
//       );
//     }
//     return element;
//   }
//   async removeQuestion() {
//     await this.setState({ questionID: "", isLoadingComplete: 0 });
//     this.actionTrigger();
//   }
//   masterRoleNamesLoad(data) {
//     let master_list_names = [];
//     for (let i = 0; i < data.length; i++) {
//       master_list_names.push(
//         <MenuItem value={data[i].user_id}>
//           {data[i].name + "(" + data[i].email_address + ")"}
//         </MenuItem>
//       );
//     }
//     return master_list_names;
//   }
//   async assignQuestionFlqc() {
//     if (this.state.users_list_id === "") {
//       Swal.fire("", "Select the User.", "warning");
//       return false;
//     } else {
//       let options = [];
//       if (!this.state.QuestionList) {
//         Swal.fire("Warning!", "Select the question", "warning");
//         return false;
//       } else {
//         this.state.QuestionList.map(function(item) {
//           if (item.isChecked === true && item.status === 4) {
//             options.push(item.question_id);
//           }
//           return options;
//         });
//       }
//       if (options.length === 0) {
//         Swal.fire("Warning!", "Select the question", "warning");
//         return false;
//       } else {
//         this.setState({ isLoadingComplete: 0 });
//         const requestInput = {
//           url: "PostAssignQuestionUser",
//           token: storage.getValue("token"),
//           payload: {
//             operation: 2,
//             user_id: storage.getValue("user_id"),
//             role_id: storage.getValue("role_id"),
//             user_role_id: storage.getValue("user_role_id"),
//             question_id: options,
//             assigning_to_id: this.state.users_list_id
//           }
//         };
//         const version = "v1";
//         const response = await postAPI(requestInput, this.props, version);
//         if (response) {
//           if (parseInt(response.status) === 200) {
//             Swal.fire("Success!", "Successfully assigned", "success");
//             this.setState({ users_list_id: "", allChecked: false });
//             this.actionTrigger();
//           } else {
//             this.actionTrigger();
//             this.setState({ users_list_id: "", allChecked: false });
//             Swal.fire(
//               "Oops!! " + response.content + " Failed",
//               "Something went Wrong. Please Try again Later."
//             );
//           }
//         }
//       }
//     }
//   }
//   render() {
//     const { classes } = this.props;

//     return (
//       <div className={classes.root}>
//         {this.state.isLoadingComplete ? null : (
//           <Loading
//             loading={true}
//             background="#24324dc9"
//             loaderColor="#8fc740"
//           />
//         )}
//         {this.state.questionID ? (
//           <div>
//             {
//               <WebBackBlueIcon
//                 style={{ width: "40px", height: "40px" }}
//                 onClick={this.removeQuestion.bind(this)}
//               />
//             }

//             <CreateQuestions
//               questionID={this.state.questionID}
//               questionBack={this.removeQuestion.bind(this)}
//             />
//           </div>
//         ) : (
//           <div>
//             <BreadCrumb BreadCrumbFirst />
//             <Paper style={{ marginBottom: "20px" }} square>
//               <Tabs
//                 value={this.state.activeTab}
//                 onChange={this.handleTabChange.bind(this)}
//                 indicatorColor="secondary"
//                 textColor="primary"
//               >
//                 {this.DynamicDashboardCount()}
//               </Tabs>
//             </Paper>
//             {storage.getValue("role_id") === 7 ? (
//               <div>
//                 <Grid container>
//                   <Grid xs={8} />
//                   <Grid xs={4}>
//                     <Grid container>
//                       <Grid xs={8}>
//                         <div style={{ marginRight: "20px" }}>
//                           <FormControl
//                             style={{ width: "100%", marginBottom: "20px" }}
//                           >
//                             <Select
//                               margin="dense"
//                               PaperProps={{
//                                 style: {
//                                   maxHeight: ITEM_HEIGHT * 4.5,
//                                   width: 200
//                                 }
//                               }}
//                               value={
//                                 this.state.users_list_id
//                                   ? this.state.users_list_id
//                                   : ""
//                               }
//                               input={<OutlinedInput />}
//                               onChange={this.handleChange.bind(this)}
//                               displayEmpty
//                               name="users_list_id"
//                             >
//                               <MenuItem value="" disabled>
//                                 <em>Select Assignee</em>
//                               </MenuItem>
//                               {this.masterRoleNamesLoad(this.state.users_list)}
//                             </Select>
//                           </FormControl>
//                         </div>
//                       </Grid>
//                       <Grid xs={4}>
//                         <Button
//                           fullWidth={true}
//                           variant="contained"
//                           size="medium"
//                           color="primary"
//                           onClick={this.assignQuestionFlqc.bind(this)}
//                           style={{
//                             textTranform: "none",
//                             padding: 7
//                           }}
//                         >
//                           Assignee
//                         </Button>
//                       </Grid>
//                     </Grid>
//                   </Grid>
//                 </Grid>
//               </div>
//             ) : (
//               ""
//             )}

//             {JSON.stringify(this.state.status) ===
//               JSON.stringify(this.state.activeTab) && (
//               <TabContainer>
//                 <Grid container spacing={2}>
//                   <Grid item xs={12} md={12}>
//                     <Paper elevation={0} className={classes.topBar}>
//                       <Grid
//                         container
//                         direction="row"
//                         alignItems="center"
//                         justify="space-between"
//                         spacing={2}
//                         style={{ display: "flex" }}
//                       >
//                         <Grid
//                           style={{
//                             display: "flex",
//                             flexWrap: "wrap",
//                             alignItems: "center",
//                             justifyContent: "space-between",
//                             flexDirection: "row",
//                             width: "100%"
//                           }}
//                           item
//                         >
//                           <Grid
//                             container
//                             direction="row"
//                             alignItems="center"
//                             justify="flex-start"
//                             spacing={3}
//                           >
//                             <Grid
//                               item
//                               style={{
//                                 width: "45px",
//                                 height: "50px",
//                                 padding: "5px 4px",
//                                 borderRight: "1px solid",
//                                 borderColor: "#d2d2d2"
//                               }}
//                             >
//                               {this.state.QuestionList !== undefined &&
//                               storage.getValue("role_id") !== 6 &&
//                               storage.getValue("role_id") !== 8 &&
//                               storage.getValue("role_id") !== 9 ? (
//                                 <Checkbox
//                                   name="checkAll"
//                                   checked={this.state.allChecked}
//                                   color="primary"
//                                   onChange={this.handleCheckbox.bind(this)}
//                                 />
//                               ) : (
//                                 <WebFilterIcon
//                                   style={{
//                                     position: "relative",
//                                     height: "40px"
//                                   }}
//                                 />
//                               )}
//                             </Grid>
//                             <Grid item>
//                               <FormControl>
//                                 <Select
//                                   disableUnderline
//                                   value={
//                                     this.state.question_type_id
//                                       ? this.state.question_type_id
//                                       : ""
//                                   }
//                                   onChange={this.handleChange.bind(this)}
//                                   displayEmpty
//                                   name="question_type_id"
//                                   className={classes.topSelectBox}
//                                 >
//                                   <MenuItem value="" disabled>
//                                     <em>Question Type</em>
//                                   </MenuItem>
//                                   {this.masterLoad(this.state.question_type)}
//                                 </Select>
//                               </FormControl>
//                               <FormControl>
//                                 <Select
//                                   disableUnderline
//                                   value={
//                                     this.state.question_category_id
//                                       ? this.state.question_category_id
//                                       : ""
//                                   }
//                                   onChange={this.handleChange.bind(this)}
//                                   displayEmpty
//                                   name="question_category_id"
//                                   className={classes.topSelectBox}
//                                 >
//                                   <MenuItem value="" disabled>
//                                     <em>Question Category</em>
//                                   </MenuItem>
//                                   {this.masterLoad(
//                                     this.state.question_category
//                                   )}
//                                 </Select>
//                               </FormControl>
//                               {this.state.question_type_id === 1 &&
//                               this.state.question_category_id ? (
//                                 <FormControl>
//                                   <Select
//                                     disableUnderline
//                                     value={
//                                       this.state.question_method_id
//                                         ? this.state.question_method_id
//                                         : ""
//                                     }
//                                     onChange={this.handleChange.bind(this)}
//                                     displayEmpty
//                                     name="question_method_id"
//                                     className={classes.topSelectBox}
//                                   >
//                                     <MenuItem value="" disabled>
//                                       <em>Question Method</em>
//                                     </MenuItem>
//                                     {this.masterLoad(
//                                       this.state.question_method
//                                     )}
//                                   </Select>
//                                 </FormControl>
//                               ) : (
//                                 ""
//                               )}
//                               <FormControl>
//                                 <Select
//                                   disableUnderline
//                                   value={
//                                     this.state.nos_id ? this.state.nos_id : ""
//                                   }
//                                   onChange={this.handleChange.bind(this)}
//                                   displayEmpty
//                                   name="nos_id"
//                                   className={classes.topSelectBox}
//                                 >
//                                   <MenuItem value="" disabled>
//                                     <em>NOS</em>
//                                   </MenuItem>
//                                   {this.masterLoad(this.state.nos)}
//                                 </Select>
//                               </FormControl>
//                               <FormControl>
//                                 <Select
//                                   disableUnderline
//                                   value={
//                                     this.state.pc_id ? this.state.pc_id : ""
//                                   }
//                                   onChange={this.handleChange.bind(this)}
//                                   displayEmpty
//                                   name="pc_id"
//                                   className={classes.topSelectBox}
//                                 >
//                                   <MenuItem value="" disabled>
//                                     <em>PC</em>
//                                   </MenuItem>
//                                   {this.masterLoad(this.state.pc)}
//                                 </Select>
//                               </FormControl>
//                               <FormControl>
//                                 <Select
//                                   disableUnderline
//                                   value={
//                                     this.state.difficulty_level_id
//                                       ? this.state.difficulty_level_id
//                                       : ""
//                                   }
//                                   onChange={this.handleChange.bind(this)}
//                                   displayEmpty
//                                   name="difficulty_level_id"
//                                   className={classes.topSelectBox}
//                                 >
//                                   <MenuItem value="" disabled>
//                                     <em>Difficulty Level</em>
//                                   </MenuItem>
//                                   {this.masterLoad(this.state.difficulty_level)}
//                                 </Select>
//                               </FormControl>
//                               <IconButton
//                                 aria-label="Search"
//                                 className={`${classes.margin} ${classes.searchIcon}`}
//                                 onClick={this.searchQuestions.bind(this)}
//                               >
//                                 <DoneIcon size="medium" />
//                               </IconButton>
//                               <IconButton
//                                 aria-label="Delete"
//                                 className={`${classes.margin} ${classes.refreshIcon}`}
//                                 onClick={this.resetQuestion.bind(this)}
//                               >
//                                 <AutorenewIcon />
//                               </IconButton>
//                             </Grid>
//                           </Grid>
//                         </Grid>
//                       </Grid>
//                     </Paper>
//                   </Grid>
//                 </Grid>

//                 {this.QuestionListView() ? (
//                   this.QuestionListView()
//                 ) : (
//                   <div className={classes.cardMargin}>
//                     <Grid container spacing={1}>
//                       <Grid item xs={12}>
//                         <TabContainer>
//                           <center>
//                             <NoRecord width="80px" height="80px" />
//                             <Typography variant="h6">
//                               No Records found
//                             </Typography>
//                             <Typography variant="caption">
//                               There is no questions found
//                             </Typography>
//                           </center>
//                         </TabContainer>
//                       </Grid>
//                     </Grid>
//                   </div>
//                 )}
//                 {this.QuestionListView() !== 0 ? (
//                   <div className={classes.paginationContainer}>
//                     <div style={{ marginRight: 20 }}>
//                       <strong>
//                         Totalcount:
//                         {this.state.totalcount ? this.state.totalcount : ""}
//                       </strong>
//                     </div>
//                     <Pagination
//                       activePage={this.state.page}
//                       itemsCountPerPage={10}
//                       totalItemsCount={this.state.totalcount}
//                       pageRangeDisplayed={5}
//                       onChange={this.handlePageChange.bind(this)}
//                     />
//                   </div>
//                 ) : (
//                   ""
//                 )}
//               </TabContainer>
//             )}

//             <DialogModel
//               fullScreen
//               appBar
//               dialogTitle="Question Detail View"
//               onClose={this.handleClose.bind(this)}
//               dialogPopup={this.state.dialogPopup}
//               content={this.dialogContent()}
//             />
//           </div>
//         )}
//       </div>
//     );
//   }
// }

// QuestionListing.propTypes = {
//   classes: PropTypes.object.isRequired,
//   theme: PropTypes.object.isRequired
// };

// const styles = theme => ({
//   root: {
//     flexGrow: 1
//   },
//   closeButton: {
//     position: "absolute",
//     right: theme.spacing(1),
//     top: theme.spacing(1),
//     color: theme.palette.grey[500]
//   },
//   toolbarDense: {
//     minHeight: 45,
//     background: "#e1e1e1de"
//   },
//   filterWidth: {
//     maxWidth: 30
//   },
//   dropdownStyle: {
//     borderRadius: 50,
//     minWidth: "6.5em",
//     marginLeft: 10
//   },
//   chip: {
//     margin: "10px",
//     color: "rgba(255, 255, 255, 0.77)",
//     backgroundColor: "#3a475f"
//   },
//   margin: {
//     marginTop: 0,
//     padding: 5,
//     marginLeft: 10
//   },
//   filter: {
//     marginLeft: 0,
//     marginRight: 0,
//     color: "rgb(79, 102, 234) !important"
//   },
//   searchIcon: {
//     color: "azure",
//     borderRadius: 25,
//     background: "#8fc740"
//   },
//   refreshIcon: {
//     borderRadius: 25,
//     padding: 5,
//     background: "#616161",
//     color: "azure"
//   },

//   title: {
//     fontSize: 11
//   },
//   paginationContainer: {
//     background: "#e8e8e8",
//     border: "1px solid #d2d2d2",
//     margin: theme.spacing(2, 0, 0, 0),
//     display: "flex",
//     alignItems: "center",
//     justifyContent: "flex-end",
//     height: 50,
//     borderRadius: 2
//   },

//   formControl: {
//     margin: "8px",
//     minWidth: 120
//   },
//   menu: {
//     width: 200
//   },
//   textField: {
//     marginLeft: "8px",
//     marginRight: "8px"
//   },
//   topBar: {
//     padding: "8px 12px",
//     background: "#e5e5e5",
//     borderStyle: "solid",
//     borderWidth: "1px",
//     borderColor: "#d2d2d2",
//     borderRadius: "2px",
//     display: "flex",
//     justifyContent: "flex-start"
//   },
//   TopBarButton: {
//     textTransform: "none",
//     marginLeft: "8px",
//     minWidth: "100px",
//     borderRadius: "25px",
//     border: "1px solid",
//     borderColor: "#3159df",
//     fontSize: "16px",
//     fontWeight: "normal",
//     height: "33px",
//     lineHeight: "20px"
//   },
//   topSelectBox: {
//     border: "1px solid #3159df",
//     minWidth: "70px",
//     paddingLeft: "15px",
//     paddingRight: "0",
//     borderRadius: "20px",
//     fontSize: 16,
//     marginRight: theme.spacing(0.5)
//   },
//   selectEmpty: {
//     marginTop: "16px"
//   },
//   selectIcon: {
//     background: "#bdbdbd",
//     borderRadius: 25,
//     color: "azure"
//   },
//   selectedIcon: {
//     background: "#2066ef",
//     borderRadius: 25,
//     color: "azure"
//   },
//   questionDesign: {
//     background: "#ededed",
//     marginTop: 0,
//     boxShadow: "none"
//   }
// });

// export default withStyles(styles, { withTheme: true })(QuestionListing);
