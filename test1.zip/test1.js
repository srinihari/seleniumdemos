// import React, { Component } from "react";
// import PropTypes from "prop-types";
// import { fade, withStyles } from "@material-ui/core/styles";
// import BreadCrumb from "../../components/BreadCrumb";
// import TabContainer from "../../components/tabContainer";
// import UploadIcon from "../../images/icons/webUploadWhite.svg";
// import InfoIcon from "../../images/icons/webInfo.svg";
// import EditIcon from "../../images/icons/web-edit-blue.svg";
// import { Done as DoneIcon } from "@material-ui/icons";
// import AutorenewIcon from "@material-ui/icons/Autorenew";
// import ExpansionPanel from "@material-ui/core/ExpansionPanel";
// import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
// import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
// import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
// import CKEditor from "ckeditor4-react";
// import StorageHelper from "../../helpers/storageHelper";
// import { getAPI, postAPI, formDataGetUrl } from "../../apiBase/apiClient";
// import NoRecord from "../../components/Icons/WebNoRecord.js";
// import Pagination from "react-js-pagination";

// import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

// import WebEditBlackIcon from "../../components/Icons/WebEditBlack";
// import WebDeleteRedIcon from "../../components/Icons/WebDeleteRed";
// import WebCheckWhiteIcon from "../../components/Icons/WebCheckWhite";
// import ReorderIcon from "@material-ui/icons/Reorder";
// import Dialog from "@material-ui/core/Dialog";
// import MuiDialogTitle from "@material-ui/core/DialogTitle";
// import MuiDialogContent from "@material-ui/core/DialogContent";
// import MuiDialogActions from "@material-ui/core/DialogActions";
// import CloseIcon from "@material-ui/icons/Close";
// import Swal from "sweetalert2";
// import ImageUpload from "../../components/editorImageUpload";
// import { saveAs } from "file-saver";
// import excel from "exceljs";
// import * as moment from "moment";
// import Loading from "react-fullscreen-loading";
// import CommonHelper from "../../helpers/commonHelper";

// import {
//   Tabs,
//   Tab,
//   Grid,
//   MenuItem,
//   Paper,
//   Button,
//   Typography,
//   Divider,
//   Select,
//   FormControl,
//   InputLabel,
//   InputBase,
//   OutlinedInput,
//   Switch,
//   FormControlLabel,
//   TextField,
//   Box,
//   IconButton,
//   List,
//   ListItem,
//   ListItemSecondaryAction,
//   ListItemText,
//   Checkbox
// } from "@material-ui/core";

// // a little function to help us with reordering the result
// const reorder = (list, startIndex, endIndex) => {
//   const result = Array.from(list);
//   const [removed] = result.splice(startIndex, 1);
//   result.splice(endIndex, 0, removed);

//   return result;
// };

// const grid = 8;
// const getItemStyle = (isDragging, draggableStyle) => ({
//   // some basic styles to make the items look a bit nicer
//   userSelect: "none",
//   padding: grid * 1,
//   margin: `0 0 ${grid}px 0`,

//   // change background colour if dragging
//   background: isDragging ? "lightgreen" : "lightgrey",

//   // styles we need to apply on draggables
//   ...draggableStyle
// });

// const getListStyle = isDraggingOver => ({
//   width: "95%"
// });

// const BootstrapInput = withStyles(theme => ({
//   root: {
//     "label + &": {
//       marginTop: theme.spacing(3)
//     }
//   },
//   updateButton: {
//     background: "#24324d",
//     color: theme.palette.common.white,
//     textTransform: "none",
//     margin: theme.spacing(4, 0, 0, 0),
//     padding: theme.spacing(1.5, 1),
//     borderRadius: "0px",
//     "&:focus,&:hover,&$active": {
//       boxShadow: "#ccc 0px 2px 3px 1px",
//       background: "#24324d"
//     }
//   },
//   input: {
//     borderRadius: 0,
//     position: "relative",
//     backgroundColor: theme.palette.common.white,
//     border: "1px solid #ced4da",
//     fontSize: 16,
//     width: "335px",
//     padding: "9px 10px",
//     transition: theme.transitions.create(["border-color", "box-shadow"]),
//     // Use the system font instead of the default Roboto font.
//     fontFamily: [
//       "-apple-system",
//       "BlinkMacSystemFont",
//       '"Segoe UI"',
//       "Roboto",
//       '"Helvetica Neue"',
//       "Arial",
//       "sans-serif",
//       '"Apple Color Emoji"',
//       '"Segoe UI Emoji"',
//       '"Segoe UI Symbol"'
//     ].join(","),
//     "&:focus": {
//       boxShadow: `${fade(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
//       borderColor: theme.palette.primary.main
//     }
//   }
// }))(InputBase);
// const styles1 = theme => ({
//   root: {
//     margin: 0,
//     padding: theme.spacing(2)
//   },
//   closeButton: {
//     position: "absolute",
//     right: theme.spacing(1),
//     top: theme.spacing(1),
//     color: theme.palette.grey[500]
//   }
// });

// const DialogTitle = withStyles(styles1)(props => {
//   const { children, classes, onClose } = props;
//   return (
//     <MuiDialogTitle disableTypography className={classes.root}>
//       <Typography variant="h6">{children}</Typography>
//       {onClose ? (
//         <IconButton
//           aria-label="Close"
//           className={classes.closeButton}
//           onClick={onClose}
//         >
//           <CloseIcon />
//         </IconButton>
//       ) : null}
//     </MuiDialogTitle>
//   );
// });

// const DialogContent = withStyles(theme => ({
//   root: {
//     padding: theme.spacing(2)
//   }
// }))(MuiDialogContent);

// const DialogActions = withStyles(theme => ({
//   root: {
//     margin: 0,
//     padding: theme.spacing(1)
//   }
// }))(MuiDialogActions);

// const storage = new StorageHelper();
// const ITEM_HEIGHT = 48;
// const commonCall = new CommonHelper();

// class CreateQuestions extends Component {
//   constructor(props) {
//     super(props);
//     this.node = React.createRef();
//     this.state = {
//       activeTab: props.questionID ? "two" : "one",
//       uploadFileName: "",
//       //age: "",
//       expanded: "panel1",
//       randomizedQuestion: true,
//       radio: false,
//       question_type: [],
//       question_category: [],
//       nos: [],
//       pc: [],
//       difficulty_level: [],
//       question_type_id: "",
//       question_category_id: "",
//       nos_id: "",
//       pc_id: "",
//       language_id: "",
//       difficulty_level_id: "",
//       errors: {},
//       comprehension: "",
//       question: "",
//       options: props.questionID
//         ? []
//         : [
//             { content: "Option A", id: "0", option: "", answer: 1 },
//             { content: "Option B", id: "1", option: "", answer: 0 }
//           ],
//       option_id: 0,
//       answer: 1,
//       option: "",
//       reference: "",
//       score: "",
//       negative_score: 0,
//       question_answer: "",
//       question_id: props.questionID ? props.questionID : "",
//       moderator_reference: "",
//       moderator_comment: "",
//       moderator_answer: "",
//       moderator_option: [],
//       answer_disable: false,
//       open: false,
//       reason: "",
//       open1: false,
//       users_list_id: "",
//       get_roles_id: 9,
//       users_list: [],
//       qus_type_id: "",
//       qus_category_id: "",
//       qus_category: [],
//       qus_type: [],
//       isLoadingComplete: 0,
//       qm: [],
//       qm_id: "",
//       isFetching: false,
//       language: [],
//       defaultNosId: commonCall.nosId(),
//       /* Multi language code start */
//       vl_comprehension: "",
//       vl_question: "",
//       vl_options:
//         props.questionID && props.language_id != undefined
//           ? []
//           : [
//               { content: "Option A", id: "0", vl_option: "", vl_answer: 1 },
//               { content: "Option B", id: "1", vl_option: "", vl_answer: 0 },
//             ],
//       vl_option_id: 0,
//       vl_answer: 1,
//       vl_option: "",
//       vl_reference: "",
//       vl_score: "",
//       vl_negative_score: 0,
//       vl_question_answer: "",
//       venacular_id: "",
//       vl_create: "create",
//       vl_edit: "",
//       vl_qus_list: "vl_list",
//       vl_question_id: props.questionID ? props.questionID : "",
//       page: 1,
//       vl_datassss: [],
//       VernacularQuestions: [],
//       translation_id: "",
//       vl_question_transid: "",
//       open2:false,
//       questionoptionplatformArray: { 1: "same"},  
//       questionoptionplatform:"",
//       questionoptionChecked: false,
//       eng_option_value:"",
//     };
//   }
//   componentDidMount() {
//     this.renderMath();
//   }

//   componentDidUpdate() {
//     this.renderMath();
//   }
//   renderMath() {
//     window.MathJax.Hub.Queue([
//       "Typeset",
//       window.MathJax.Hub,
//       this.node.current
//     ]);
//   }
//   async componentWillMount() {
//     this.languageList();
//     await this.loadData();
//   }

//   onDragEnd(result) {
//     // dropped outside the list
//     if (!result.destination) {
//       return;
//     }

//     const items = reorder(
//       this.state.options,
//       result.source.index,
//       result.destination.index
//     );

//     this.setState({
//       items
//     });
//   }
//   onDragVlEnd(result) {
//     console.log(result);
//     // dropped outside the list
//     if (!result.destination) {
//       return;
//     }

//     const items = reorder(
//       this.state.vl_options,
//       result.source.index,
//       result.destination.index
//     );

//     this.setState({
//       items,
//     });
//   }
//   async languageList() {
//     let requestData = {
//       url: `GetLanguage`,
//       token: storage.getValue("token"),
//     };

//     const response = await getAPI(requestData, this.props, "v1");

//     if (response) {
//       this.setState({ language: response });
//     }
//   }
//   loadData() {
//     let url = [
//       {
//         url: `GetDropdownMasterData?master_type=question_type&master_id=&role_id=${storage.getValue(
//           "role_id"
//         )}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         version: "v1",
//         state: "question_type",
//       },
//       {
//         url: `GetDropdownMasterData?master_type=nos&master_id=&role_id=${storage.getValue(
//           "role_id"
//         )}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         version: "v1",
//         state: "nos",
//       },
//       {
//         url: `GetDropdownMasterData?master_type=difficulty_level&master_id=&role_id=${storage.getValue(
//           "role_id"
//         )}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         version: "v1",
//         state: "difficulty_level",
//       },
//     ];
//     if (this.state.question_id && this.state.question_id !== "") {
//       url.push({
//         url: `GetIndividualQuestionView?question_id=${
//           this.state.question_id
//         }&language_id=1&role_id=${storage.getValue(
//           "role_id"
//         )}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         version: "v1",
//         state: "update_question",
//       });
//     }

//     if (
//       this.state.vl_question_id &&
//       this.state.vl_question_id != "" &&
//       this.state.vl_qus_list
//     ) {
//       url.push({
//         url: `GetQmsQuestionView?question_id=${this.state.question_id}&page=${this.state.page}&page_size=10`,
//         version: "v2",
//         state: "VernacularQuestions",
//       });
//     }
//     if (storage.getValue("role_id") === 9) {
//       url.push({
//         url: `GetUserListBasedonRoleId?role_id=${
//           this.state.get_roles_id
//         }&user_role_id=${storage.getValue("user_role_id")}`,
//         version: "v1",
//         state: "users_list"
//       });
//     }

//     for (let i = 0; i < url.length; i++) {
//       let link = url[i];
//       this.triggerApi(link.url, link.version, link.state);
//     }
//   }
//   async triggerApi(url, version, state) {
//     let requestData = {
//       url: url,
//       token: storage.getValue("token")
//     };
//     const response = await getAPI(requestData, this.props, version);

//     if (response) {
//       if (parseInt(response.status) === 200) {
//         if (state === "update_question") {
//           await this.setState({
//             question: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.questions
//               : "",
//             question_type_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.question_type_id
//               : "",
//             question_category_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.question_category_id
//               : "",
//             nos_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.nos_id
//               : "",
//             pc_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.pc_id
//               : "",
//             qm_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.question_method
//               : "",
//             difficulty_level_id: response.content.QuestionMaster
//               ? response.content.QuestionMaster.difficulty_id
//               : "",
//             score: response.content.QuestionMaster
//               ? response.content.QuestionMaster.score
//               : "",
//             negative_score: response.content.QuestionMaster
//               ? response.content.QuestionMaster.negative_score
//               : "",
//             reference: response.content.setter_reference
//               ? response.content.setter_reference
//               : "",
//             question_answer: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.QuestionAnswers.length
//                 ? response.content.QuestionTranslation.QuestionAnswers[0]
//                     .exam_answer
//                 : ""
//               : "",
//             moderator_reference: response.content.moderator_reference
//               ? response.content.moderator_reference
//               : "",
//             moderator_comment: response.content.moderator_comment
//               ? response.content.moderator_comment
//               : "",
//             comprehension: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.Comprehension != null
//                 ? response.content.QuestionTranslation.Comprehension
//                 : ""
//               : "",
//             isLoadingComplete: 1,
//             isFetching: true
//           });

//           await this.editMasterUpdate(
//             "question_category",
//             response.content.QuestionMaster
//               ? response.content.QuestionMaster.question_type_id
//               : ""
//           );
//           await this.editMasterUpdate(
//             "pc",
//             response.content.QuestionMaster
//               ? response.content.QuestionMaster.nos_id
//               : ""
//           );
//           if (
//             response.content.QuestionMaster.question_type_id === 1 &&
//             response.content.QuestionMaster.question_category_id
//           ) {
//             await this.editMasterUpdate(
//               "qm",
//               response.content.QuestionMaster
//                 ? response.content.QuestionMaster.question_category_id
//                 : ""
//             );
//           }

//           if (
//             response.content.QuestionMaster &&
//             response.content.QuestionMaster.question_type_id === 1
//           ) {
//             let new_opt = [];
//             let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//             for (
//               let index = 0;
//               index <
//               response.content.QuestionTranslation.QuestionOptions.length;
//               index++
//             ) {
//               let answer = 0;
//               for (
//                 let j = 0;
//                 j < response.content.QuestionTranslation.QuestionAnswers.length;
//                 j++
//               ) {
//                 if (
//                   response.content.QuestionTranslation.QuestionAnswers[j]
//                     .option_id ===
//                   response.content.QuestionTranslation.QuestionOptions[index].id
//                 ) {
//                   answer = 1;
//                 }
//               }

//               new_opt.push({
//                 content: "Option " + letters.charAt(index),
//                 option:
//                   response.content.QuestionTranslation.QuestionOptions[index]
//                     .options,
//                 id: "" + index,
//                 answer: storage.getValue("role_id") === 8 ? 0 : answer,
//                 option_id:
//                   response.content.QuestionTranslation.QuestionOptions[index].id
//               });
//             }
//             await this.setState({
//               options: new_opt,
//               moderator_option: new_opt,
//               option_id: "" + 0,
//               option: response.content.QuestionTranslation
//                 ? response.content.QuestionTranslation.QuestionOptions[0]
//                     .options
//                 : "",
//               answer: storage.getValue("role_id") === 8 ? 0 : 1,

//               isLoadingComplete: 1
//             });
//           }
//         } else if (state === "users_list") {
//           await this.setState({
//             [state]: response.content ? response.content : "",
//             isLoadingComplete: 1
//           });
//         } else if (state === "vl_update_question") {
//           await this.setState({
//             open: true,
//             // translation_id: response.content.QuestionTranslation
//             //   ? response.content.QuestionTranslation.id
//             //   : "",
//             language_id: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.language_id
//               : "",
//             // vl_question: response.content.QuestionTranslation
//             //   ? response.content.QuestionTranslation.questions
//             //   : "",
//             vl_question_transid: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.id
//               : "",
//             vl_question_answer: response.content.QuestionTranslation
//               ? response.content.QuestionTranslation.QuestionAnswers.length
//                 ? response.content.QuestionTranslation.QuestionAnswers[0]
//                     .exam_answer
//                 : ""
//               : "",
//           });
//           if (
//             response.content.QuestionMaster &&
//             response.content.QuestionMaster.question_type_id === 1
//           ) {
//             let new_opt = [];
//             let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//             for (
//               let index = 0;
//               index <
//               response.content.QuestionTranslation.QuestionOptions.length;
//               index++
//             ) {
//               let answer = 0;
//               for (
//                 let j = 0;
//                 j < response.content.QuestionTranslation.QuestionAnswers.length;
//                 j++
//               ) {
//                 if (
//                   response.content.QuestionTranslation.QuestionAnswers[j]
//                     .option_id ===
//                   response.content.QuestionTranslation.QuestionOptions[index].id
//                 ) {
//                   answer = 1;
//                 }
//               }

//               new_opt.push({
//                 content: "Option " + letters.charAt(index),
//                 vl_option:
//                   response.content.QuestionTranslation.QuestionOptions[index]
//                     .options,
//                 id: "" + index,
//                 vl_answer: storage.getValue("role_id") === 8 ? 0 : answer,
//                 vl_option_id:
//                   response.content.QuestionTranslation.QuestionOptions[index]
//                     .id,
//               });
//             }
//             await this.setState({
//               vl_options: new_opt,
//               vl_option_id: "" + 0,
//               vl_option: response.content.QuestionTranslation
//                 ? response.content.QuestionTranslation.QuestionOptions[0]
//                     .options
//                 : "",
//               vl_answer: storage.getValue("role_id") === 8 ? 0 : 1,

//               isLoadingComplete: 1,
//             });
//           }
//         } else if (state === "VernacularQuestions") {
//           await this.setState({ VernacularQuestions: response.content.rows });
//         } else {
//           await this.setState({
//             [state]: response.content ? response.content.master : "",
//             isLoadingComplete: 1,
//           });
//         }
//       } else if (parseInt(response.status) === 400) {
//         await this.setState({
//           error: response.content.error,
//           isLoadingComplete: 1,
//         });
//       }
//     }
//   }
//   masterLoad(data, dropdown_type) {
//     let master_list_array = [];
//     for (let i = 0; i < data.length; i++) {
//       if (dropdown_type == "question_type") {
//         if (data[i].id != 3) {
//           master_list_array.push(
//             <MenuItem value={data[i].id}>{data[i].name}</MenuItem>
//           );
//         }
//       } else if (dropdown_type == "nos") {
//         if (data[i].id != this.state.defaultNosId) {
//           master_list_array.push(
//             <MenuItem value={data[i].id}>{data[i].name}</MenuItem>
//           );
//         }
//       } else {
//         master_list_array.push(
//           <MenuItem value={data[i].id}>{data[i].name}</MenuItem>
//         );
//       }
//     }
//     return master_list_array;
//   }

//   handleChange(event, value) {
//     this.setState({ uploadFileName: "" });
//     this.setState({ activeTab: value });
//   }

//   radioHandleChange(event) {
//     this.setState({
//       radio: event.target.value,
//     });
//   }

//   upload(event) {
//     this.setState({
//       uploadFileName: event.target.value,
//     });
//     event.persist();
//   }
//    uploadBulkQuestions(event) {
//     if (
//       event.target.files[0] !== undefined &&
//       event.target.files[0] !== "undefined"
//     ) {
//       this.setState({
//         uploadFile: event.target.files,
//         uploadFileName: event.target.files[0].name
//       });
//     } else {
//       this.setState({
//         uploadFile: "",
//         uploadFileName: ""
//       });
//     }
//   }
//   /*Bulk Upload Code*/
//   async downloadTemplate() {
//     let workbook = new excel.Workbook();
//     workbook.views = [
//       {
//         x: 0,
//         y: 0,
//         width: 10000,
//         height: 20000,
//         firstSheet: 0,
//         activeTab: 1,
//         visibility: "visible"
//       }
//     ];
//     let worksheet = workbook.addWorksheet("Sheet1");
//     worksheet.columns = [
//       { header: "Sno", key: "Sno" },
//       { header: "QuestionType", key: "QuestionType" },
//       { header: "QuestionCategory", key: "QuestionCategory" },
//       { header: "QuestionMethod", key: "QuestionMethod" },
//       { header: "NOS", key: "NOS" },
//       { header: "PC", key: "PC" },
//       { header: "QuestionLevel", key: "QuestionLevel" },
//       { header: "comprehension", key: "comprehension" },
//       { header: "question", key: "question" },
//       { header: "OptionA", key: "OptionA" },
//       { header: "OptionB", key: "OptionB" },
//       { header: "OptionC", key: "OptionC" },
//       { header: "OptionD", key: "OptionD" },
//       { header: "OptionE", key: "OptionE" },
//       { header: "OptionF", key: "OptionF" },
//       { header: "OptionG", key: "OptionG" },
//       { header: "OptionH", key: "OptionH" },
//       { header: "ExamAnswer", key: "ExamAnswer" },
//       { header: "CorrectAnswer", key: "CorrectAnswer" },
//       { header: "Score", key: "Score" },
//       { header: "NegativeScore", key: "NegativeScore" },
//       { header: "reference", key: "reference" }
//     ];
//     const sample_question = [
//       {
//         Sno: "1",
//         QuestionType: "MCQ",
//         QuestionCategory: "theory",
//         QuestionMethod: "new qm2",
//         NOS: "test nos 44",
//         PC: "test pc",
//         QuestionLevel: "Medium",
//         comprehension: "example comprehension",
//         question:
//           "A certain amount earns simple interest of Rs. 1750 after 7 years. Had the interest been 2% more, how much more interest would it have earned?1",
//         OptionA: "85",
//         OptionB: "95",
//         OptionC: "72",
//         OptionD: "73",
//         OptionE: "",
//         OptionF: "",
//         OptionG: "",
//         OptionH: "",
//         ExamAnswer: "",
//         CorrectAnswer: "a",
//         Score: 1,
//         NegativeScore: 0.25,
//         reference: "56 is divisible by 7. So, it is not a prime number"
//       },
//       {
//         Sno: "2",
//         QuestionType: "MCQ",
//         QuestionCategory: "theory",
//         QuestionMethod: "new qm2",
//         NOS: "test nos 44",
//         PC: "test pc",
//         QuestionLevel: "Medium",
//         comprehension: "comprehension content data",
//         question:
//           "A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?",
//         OptionA: "120 metres",
//         OptionB: "180 metres",
//         OptionC: "324 metres",
//         OptionD: "150 metres",
//         OptionE: "",
//         OptionF: "",
//         OptionG: "",
//         OptionH: "",
//         ExamAnswer: "",
//         CorrectAnswer: "d",
//         Score: 1,
//         NegativeScore: 0.25,
//         reference: "57 is divisible by 7. So, it is not a prime number."
//       },
//       {
//         Sno: "3",
//         QuestionType: "Subjective",
//         QuestionCategory: "practical",
//         NOS: "test nos 44",
//         PC: "test pc",
//         QuestionLevel: "Easy",
//         comprehension: "comprehension content test",
//         question:
//           "A train 125 m long passes a man, running at 5 km/hr in the same direction in which the train is going, in 10 seconds. The speed of the train is",
//         OptionA: "",
//         OptionB: "",
//         OptionC: "",
//         OptionD: "",
//         OptionE: "",
//         OptionF: "",
//         OptionG: "",
//         OptionH: "",
//         ExamAnswer: "subjective answer",
//         CorrectAnswer: "",
//         Score: 1,
//         NegativeScore: 0.25,
//         reference:
//           "In each number except 427, the middle digit is the sum of other two."
//       }
//     ];
//     for (let i = 0; i < sample_question.length; i++) {
//       worksheet.addRow({
//         Sno: i,
//         QuestionType: sample_question[i].QuestionType,
//         QuestionCategory: sample_question[i].QuestionCategory,
//         QuestionMethod: sample_question[i].QuestionMethod,
//         NOS: sample_question[i].NOS,
//         PC: sample_question[i].PC,
//         QuestionLevel: sample_question[i].QuestionLevel,
//         comprehension: sample_question[i].comprehension,
//         question: sample_question[i].question,
//         OptionA: sample_question[i].OptionA,
//         OptionB: sample_question[i].OptionB,
//         OptionC: sample_question[i].OptionC,
//         OptionD: sample_question[i].OptionD,
//         OptionE: sample_question[i].OptionE,
//         OptionF: sample_question[i].OptionF,
//         OptionG: sample_question[i].OptionG,
//         OptionH: sample_question[i].OptionH,
//         ExamAnswer: sample_question[i].ExamAnswer,
//         CorrectAnswer: sample_question[i].CorrectAnswer,
//         Score: sample_question[i].Score,
//         NegativeScore: sample_question[i].NegativeScore,
//         reference: sample_question[i].reference
//       });
//     }

//     let fileName = "Questions.xlsx";
//     workbook.xlsx.writeBuffer().then(function(data) {
//       let blob = new Blob([data], {
//         type:
//           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//       });
//       saveAs(blob, fileName);
//     });
//   }
//   async uploadQuestions() {
//     this.setState({ isLoadingComplete: 0 });
//     let MAX_SIZE = 2097152;
//     let get_id = document.getElementById("qus-bulk-upload");
//     let fileupload_path = get_id.value;
//     if (fileupload_path === "") {
//       Swal.fire("", "Upload a Excel File", "warning");
//       this.setState({ isLoadingComplete: 1 });
//       return false;
//     } else {
//       var Extension = fileupload_path
//         .substring(fileupload_path.lastIndexOf(".") + 1)
//         .toLowerCase();
//       if (Extension === "xlsx") {
//         if (get_id.files && get_id.files[0]) {
//           var size = get_id.files[0].size;
//           if (size > MAX_SIZE) {
//             Swal.fire("", "Maximum File Size exceeds", "warning");
//             this.setState({ isLoadingComplete: 1 });
//             return false;
//           } else {
//             let data = new FormData();
//             data.append("file", this.state.uploadFile[0]);
//             data.append("user_role_id", storage.getValue("user_role_id"));
//             data.append("user_id", storage.getValue("user_id"));
//             data.append("question_type", this.state.qus_type_id);
//             data.append("language_id", 1);
//             data.append("question_category", this.state.qus_category_id);
//             /* fetch("http://172.18.1.1:8106/api/v1/PostQuestionBulkUpload", {*/

//             fetch(await formDataGetUrl("v1", "PostQuestionBulkUpload"), {
//               method: "POST",
//               body: data,
//               headers: {
//                 Authorization: "Bearer " + storage.getValue("token")
//               },
//               responseType: "application/json"
//             }).then(response => {
//               if (parseInt(response.status) === 200) {
//                 response.json().then(res => {
//                   if (
//                     parseInt(res.status) !== 500 &&
//                     parseInt(res.status) !== 400
//                   ) {
//                     let bulk_question = res.content;
//                     let workbook = new excel.Workbook();
//                     workbook.views = [
//                       {
//                         x: 0,
//                         y: 0,
//                         width: 10000,
//                         height: 20000,
//                         firstSheet: 0,
//                         activeTab: 1,
//                         visibility: "visible"
//                       }
//                     ];
//                     var worksheet = workbook.addWorksheet("Questions");
//                     worksheet.columns = [
//                       { header: "Sno", key: "Sno" },
//                       { header: "QuestionType", key: "QuestionType" },
//                       { header: "QuestionCategory", key: "QuestionCategory" },
//                       { header: "QuestionMethod", key: "QuestionMethod" },
//                       { header: "NOS", key: "NOS" },
//                       { header: "PC", key: "PC" },
//                       { header: "QuestionLevel", key: "QuestionLevel" },
//                       { header: "comprehension", key: "comprehension" },
//                       { header: "question", key: "question" },
//                       { header: "OptionA", key: "OptionA" },
//                       { header: "OptionB", key: "OptionB" },
//                       { header: "OptionC", key: "OptionC" },
//                       { header: "OptionD", key: "OptionD" },
//                       { header: "OptionE", key: "OptionE" },
//                       { header: "OptionF", key: "OptionF" },
//                       { header: "OptionG", key: "OptionG" },
//                       { header: "OptionH", key: "OptionH" },
//                       { header: "ExamAnswer", key: "ExamAnswer" },
//                       { header: "CorrectAnswer", key: "CorrectAnswer" },
//                       { header: "Score", key: "Score" },
//                       { header: "NegativeScore", key: "NegativeScore" },
//                       { header: "reference", key: "reference" },
//                       { header: "message", key: "message" }
//                     ];
//                     for (let i = 0; i < bulk_question.length; i++) {
//                       worksheet.addRow({
//                         Sno: i,
//                         QuestionType: bulk_question[i].QuestionType,
//                         QuestionCategory: bulk_question[i].QuestionCategory,
//                         QuestionMethod: bulk_question[i].QuestionMethod,
//                         NOS: bulk_question[i].NOS,
//                         PC: bulk_question[i].PC,
//                         QuestionLevel: bulk_question[i].QuestionLevel,
//                         comprehension: bulk_question[i].comprehension,
//                         question: bulk_question[i].question,
//                         OptionA: bulk_question[i].OptionA,
//                         OptionB: bulk_question[i].OptionB,
//                         OptionC: bulk_question[i].OptionC,
//                         OptionD: bulk_question[i].OptionD,
//                         OptionE: bulk_question[i].OptionE,
//                         OptionF: bulk_question[i].OptionF,
//                         OptionG: bulk_question[i].OptionG,
//                         OptionH: bulk_question[i].OptionH,
//                         ExamAnswer: bulk_question[i].ExamAnswer,
//                         CorrectAnswer: bulk_question[i].CorrectAnswer,
//                         Score: bulk_question[i].Score,
//                         NegativeScore: bulk_question[i].NegativeScore,
//                         reference: bulk_question[i].reference,
//                         message: bulk_question[i].message
//                       });
//                     }
//                     let filename =
//                       "BulkQuestionReport_" +
//                       moment().format("YYYY-MM-DD HH:mm:ss") +
//                       ".xlsx";

//                     workbook.xlsx.writeBuffer().then(function(data) {
//                       let blob = new Blob([data], {
//                         type:
//                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
//                       });
//                       saveAs(blob, filename);
//                     });
//                   } else {
//                     Swal.fire("Oops", "Something Went Wrong", "warning");
//                     this.setState({ isLoadingComplete: 1 });
//                   }
//                 });
//                 Swal.fire("", "Successfully Upload Refer Excel", "success");
//                 this.setState({ isLoadingComplete: 1 });
//               } else {
//                 response.json().then(res => {
//                   Swal.fire("Oops...", res.message, "warning");
//                 });
//                 this.setState({ isLoadingComplete: 1 });
//               }
//             });
//           }
//         }
//       } else {
//         Swal.fire("", "xlsx type file only allowed", "warning");
//         this.setState({ isLoadingComplete: 1 });
//       }
//     }
//   }
//   dependencyDropDownChange(event) {
//     this.setState({
//       [event.target.name]: event.target.value
//     });
//     if (event.target.name === "qus_type_id") {
//       this.setState({
//         qus_category_id: ""
//       });

//       this.triggerApi(
//         `GetDropdownMasterData?master_type=question_category&master_id=${event.target.value}`,
//         "v1",
//         "qus_category"
//       );
//     }
//   }

//   /*BulkUpload Question End*/

//   selectHandleChange(event) {
//     this.setState({
//       age: event.target.value
//     });
//   }
//   async updateAnswerKey(event) {
//     await this.setState({
//       options: {
//         ...this.state.options,
//         [this.state.option_id]: {
//           ...this.state.options[this.state.option_id],
//           answer: event.target.checked ? 1 : 0,
//         },
//       },
//       answer: event.target.checked ? 1 : 0,
//     });
//   }
//   async updateMultiLanguageAnswerKey(event) {
//     await this.setState({
//       vl_options: {
//         ...this.state.vl_options,
//         [this.state.vl_option_id]: {
//           ...this.state.vl_options[this.state.vl_option_id],
//           vl_answer: event.target.checked ? 1 : 0,
//         },
//       },
//       vl_answer: event.target.checked ? 1 : 0,
//     });
//   }
//   async valueChange(event) {
//     await this.setState({
//       activeTab: "two",
//       [event.target.name]: event.target.value,
//     });
//     this.handleValidation();
//   }
//   async editMasterUpdate(type, master_id) {
//     await this.triggerApi(
//       `GetDropdownMasterData?master_type=${type}&master_id=${master_id}&role_id=${storage.getValue(
//         "role_id"
//       )}&user_id=${storage.getValue("user_id")}&user_role_id=${storage.getValue(
//         "user_role_id"
//       )}`,
//       "v1",
//       type
//     );
//   }
//   async openModel() {
//     this.setState({
//       open: true,
//     });
//     await this.setState({
//       language_id: "",
//       vl_question: "",
//       vl_comprehension: "",
//       vl_option: "",
//       vl_options:
//         this.state.questionID && this.state.language_id != undefined
//           ? []
//           : [
//               { content: "Option A", id: "0", vl_option: "", vl_answer: 1 },
//               { content: "Option B", id: "1", vl_option: "", vl_answer: 0 },
//             ],
//       //vl_options: "",
//       // vl_option_id: ""
//     });
//   }
//     async openRejectedModel() {
//     this.setState({
//       open: true,
//     });
//   }

//   async masterChange(event) {
//     await this.setState({
//       activeTab: "two",
//       [event.target.name]: event.target.value,
//     });
//     if (event.target.name === "question_type_id") {
//       if (this.state.questionID !== "" && event.target.value === 1) {
//         let array = [];
//         array.push(
//           { content: "Option A", id: "0", option: "", answer: 1 },
//           { content: "Option B", id: "1", option: "", answer: 0 }
//         );
//         await this.setState({ options: array });
//       }
//       this.setState({
//         question_category_id: ""
//       });
//       this.triggerApi(
//         `GetDropdownMasterData?master_type=question_category&master_id=${
//           event.target.value
//         }&role_id=${storage.getValue("role_id")}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         "v1",
//         "question_category"
//       );
//     }
//     if (event.target.name === "nos_id") {
//       this.setState({
//         pc_id: ""
//       });
//       this.triggerApi(
//         `GetDropdownMasterData?master_type=pc&master_id=${
//           event.target.value
//         }&role_id=${storage.getValue("role_id")}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         "v1",
//         "pc"
//       );
//     }
//     if (
//       event.target.name === "question_category_id" &&
//       this.state.question_type_id === 1
//     ) {
//       this.setState({
//         qm_id: ""
//       });
//       this.triggerApi(
//         `GetDropdownMasterData?master_type=qm&master_id=${
//           event.target.value
//         }&role_id=${storage.getValue("role_id")}&user_id=${storage.getValue(
//           "user_id"
//         )}&user_role_id=${storage.getValue("user_role_id")}`,
//         "v1",
//         "qm"
//       );
//     }
//     this.handleValidation();
//   }

//   getClickDrag(event) {
//     if (event.currentTarget.dataset.check !== "") {
//       this.setState({
//         answer_disable: true,
//         option_id: event.currentTarget.dataset.id,
//         answer: this.state.options[event.currentTarget.dataset.id]["answer"],
//         option: this.state.options[event.currentTarget.dataset.id]["option"]
//       });
//     } else {
//       this.setState({
//         answer_disable: false,
//         option_id: event.currentTarget.dataset.id,
//         answer: this.state.moderator_option[event.currentTarget.dataset.id][
//           "answer"
//         ],
//         option: this.state.moderator_option[event.currentTarget.dataset.id][
//           "option"
//         ],
//       });
//     }
//   }
//   getVernacularClickDrag(event) {
//     if (event.currentTarget.dataset.check !== "") {
//       this.setState({
//         answer_disable: true,
//         vl_option_id: event.currentTarget.dataset.id,
//         vl_answer: this.state.vl_options[event.currentTarget.dataset.id][
//           "vl_answer"
//         ],
//         vl_option: this.state.vl_options[event.currentTarget.dataset.id][
//           "vl_option"
//         ],
//       });
//     }else {
//       this.setState({
//         answer_disable: false,
//         option_id: event.currentTarget.dataset.id,
//         answer: this.state.moderator_option[event.currentTarget.dataset.id][
//           "vl_answer"
//         ],
//         option: this.state.moderator_option[event.currentTarget.dataset.id][
//           "vl_option"
//         ],
//       });
//     }
//   }

//   handleValidation() {
//     let errors = {};
//     let formIsValid = true;

//     if (!this.state.question_type_id || this.state.question_type_id === "") {
//       formIsValid = false;
//       errors["question_type_id"] = "Please select question type";
//     }
//     if (
//       !this.state.question_category_id ||
//       this.state.question_category_id === ""
//     ) {
//       formIsValid = false;
//       errors["question_category_id"] = "Please select question category";
//     }

//     if (this.state.question_type_id === 1 && !this.state.qm_id) {
//       formIsValid = false;
//       errors["qm_id"] = "Please select question method";
//     }

//     if (!this.state.nos_id || this.state.nos_id === "") {
//       formIsValid = false;
//       errors["nos_id"] = "Please select nos";
//     }

//     if (!this.state.pc_id || this.state.pc_id === "") {
//       formIsValid = false;
//       errors["pc_id"] = "Please select pc";
//     }
//     if (
//       !this.state.difficulty_level_id ||
//       this.state.difficulty_level_id === ""
//     ) {
//       formIsValid = false;
//       errors["difficulty_level_id"] = "Please select difficulty level";
//     }
//     if (!this.state.reference || this.state.reference === "") {
//       formIsValid = false;
//       errors["reference"] = "Please enter reference";
//     } else {
//       if (this.state.reference.length > 3000) {
//         errors["reference"] = "Reference possible 3000 characters only allowed";
//         formIsValid = false;
//       }
//     }
//     if (this.state.comprehension.length > 4000) {
//       errors["comprehension"] =
//         "Reference possible 4000 characters only allowed";
//       formIsValid = false;
//     }
//     if (!this.state.question || this.state.question === "") {
//       formIsValid = false;
//       errors["question"] = "Please enter question";
//     } else {
//       if (this.state.question.length > 6000) {
//         errors["question"] = "Question possible 6000 characters only allowed";
//         formIsValid = false;
//       }
//     }
//     if (parseInt(this.state.question_type_id) !== 2) {
//       let items;
//       items = Object.values(this.state.options);
//       for (let index = 0; index < items.length; index++) {
//         if (items[index]["option"] === "") {
//           formIsValid = false;
//           errors["mcq_answer"] = "Please enter option";
//         } else {
//           if (items[index]["option"].length > 2000) {
//             formIsValid = false;
//             errors["mcq_answer"] =
//               "Option possible 2000 characters only allowed";
//           }
//         }
//       }
//     }

//     if (this.state.question_type_id === 2 && !this.state.question_answer) {
//       formIsValid = false;
//       errors["subjective_answer"] = "Please enter answer";
//     }
//     if (
//       this.state.question_type_id &&
//       parseInt(this.state.question_type_id) === 2 &&
//       this.state.score === ""
//     ) {
//       formIsValid = false;
//       errors["score"] = "Please enter score";
//     }
//     if (this.state.score === "" && this.state.negative_score !== 0) {
//       formIsValid = false;
//       errors["score"] = "Please enter score";
//     } else {
//       if (
//         this.state.score &&
//         Math.abs(this.state.negative_score) > this.state.score
//       ) {
//         formIsValid = false;
//         errors["negative_score"] = "Should not be greater than score";
//       }
//     }
//     if (
//       (storage.getValue("role_id") === 8 &&
//         this.state.moderator_reference === "") ||
//       (storage.getValue("role_id") === 9 &&
//         this.state.moderator_reference === "")
//     ) {
//       formIsValid = false;
//       errors["moderator_reference"] = "please enter moderator reference";
//     }
//     if (parseInt(this.state.question_type_id) !== 2) {
//       let vl_optionss = "";
//       let options_value = "";

//       options_value = Object.values(this.state.options);
//       for (let index = 0; index < options_value.length; index++) {
//         if (options_value[index]["answer"] === 1) {
//           vl_optionss += options_value[index]["option_id"] + ",";
//         }
//       }

//       if (vl_optionss === "") {
//         formIsValid = false;
//         errors["mcq_answer"] = "Please choose answer";
//       }
//     }

//     this.setState({ errors: errors });
//     return formIsValid;
//   }
//   handleVernacularQuestionValidation() {
//     let errors = {};
//     let formIsValid = true;
//     if (!this.state.language_id || this.state.language_id === "") {
//       formIsValid = false;
//       errors["vl_language_error"] = "Please select Language";
//     }
//     if (this.state.comprehension.length > 4000) {
//       errors["vl_comprehension"] =
//         "Reference possible 4000 characters only allowed";
//       formIsValid = false;
//     }
//     if (!this.state.vl_question || this.state.vl_question === "") {
//       formIsValid = false;
//       errors["vl_question"] = "Please enter question";
//     } else {
//       if (this.state.vl_question.length > 6000) {
//         errors["vl_question"] =
//           "Question possible 6000 characters only allowed";
//         formIsValid = false;
//       }
//     }
//     if (parseInt(this.state.question_type_id) !== 2) {
//       let items;
//       if(this.state.questionoptionplatform === 1){
//         items = Object.values(this.state.options);
//       }else{
//          items = Object.values(this.state.vl_options);
//       }
//       for (let index = 0; index < items.length; index++) {
//           if(this.state.questionoptionplatform !==1){
//             if (items[index]["vl_option"] === "") {
//               formIsValid = false;
//               if(this.state.questionoptionplatform !== 1){
//                 errors["vl_mcq_answer"] = "Please enter option";
//             }
//           } else {
//               if (items[index]["vl_option"].length > 2000) {
//               formIsValid = false;
//                 errors["vl_mcq_answer"] =
//                   "Option possible 2000 characters only allowed";
//               }
//           }
//         }else{
//           if (items[index]["option"] === "") {
//             formIsValid = false;
//             errors["vl_mcq_answer"] = "Please enter option";
//           } else {
//             if (items[index]["option"].length > 2000) {
//               formIsValid = false;
//               errors["vl_mcq_answer"] =
//                 "Option possible 2000 characters only allowed";
//             }
//           }
//         }
//       }
//     }
//     if (this.state.question_type_id === 2 && !this.state.vl_question_answer) {
//       formIsValid = false;
//       errors["vl_subjective_answer"] = "Please enter answer";
//     }

//     if (parseInt(this.state.question_type_id) !== 2) {
//       let vl_optionss = "";
//       let vl_options_value = "";
//       vl_options_value = Object.values(this.state.vl_options);
//       for (let index = 0; index < vl_options_value.length; index++) {
//         if (vl_options_value[index]["vl_answer"] === 1) {
//           vl_optionss += vl_options_value[index]["vl_option_id"] + ",";
//         }
//       }

//       if (vl_optionss === "") {
//         formIsValid = false;
//         errors["vl_mcq_answer"] = "Please choose answer";
//       }
//     }
//     this.setState({ errors: errors ? errors : "" });
//     return formIsValid;
//   }

//   async questionSubmit(e) {
//     e.preventDefault();
//     if (this.handleValidation()) {
//       this.questionUpdate();
//     }
//   }
//  loadQuestionOptionCheckbox() {
//     let question_option_platform = this.state.questionoptionplatformArray;
//     let question_option_array = [];
//     let platform = "";
//     //for (let index = 1; index <= 3; index++) {
//     //platform = assessment_platform[index];
//     //assessment_platform_array.push(platform);
//     question_option_array.push(
//       <div>
//         Same As English:
//         <Checkbox
//           name={"same"}
//           type="checkbox"
//           color="primary"
//           value={1}
//           checked={this.state.translation_id && this.state.eng_option_value !==null  ? true : this.state.questionoptionChecked}
//           onChange={this.onCheckBoxCheck.bind(this)}
//         />
//       </div>
//     );
//     //}

//     return question_option_array;
//   }
//   onCheckBoxCheck(e) {
//     console.log("value", e.target.value);
//     console.log("checked", e.target.checked);
//     if (e.target.checked === true) {
//       console.log('hi')
//       this.setState({
//         questionoptionChecked:e.target.checked,
//         questionoptionplatform:1,
//         // vl_option:""
//       });
//     } else if(e.target.checked === false) {
//       console.log('hi1')
//       this.setState({
//         questionoptionplatform:"",
//         questionoptionChecked:false,
//          vl_options:
//         this.props.questionID && this.props.language_id != undefined
//           ? []
//           : [
//               { content: "Option A", id: "0", vl_option: "", vl_answer: 1 },
//               { content: "Option B", id: "1", vl_option: "", vl_answer: 0 },
//             ],
//       })
//     }
//   }

//   async vernacularQuestionSubmit(e) {
//     e.preventDefault();
//     if (e.currentTarget.name === "vl_create") {
//       this.setState({ vl_create: e.currentTarget.name });
//     } else {
//       this.setState({ vl_edit: "edit" });
//     }
//     if (this.handleVernacularQuestionValidation()) {
//       this.vernacularQuestionCreate(e);
//     }
//   }
//   async vernacularQuestionCreate(e) {
//     let options_val;
//     let eng_same_option;
//     let eng_opt_val;
//     let is_eng_opt;
//     if(this.state.questionoptionplatform === 1){
//       eng_same_option=1;
//       is_eng_opt=1;
//     }else{
//       eng_same_option=2;
//       is_eng_opt=2;
//     }
//     this.setState({ vl_edit: "edit" });
//     let dynamic_multilanguage_option = [];
//     if (this.state.question_type_id === 1) {
//       if(this.state.questionoptionplatform === 1){
//         options_val = Object.values(this.state.options);
//       }else{
//         options_val = Object.values(this.state.vl_options);
//       }
//       for (let index = 0; index < options_val.length; index++) {  
//         if(this.state.questionoptionplatform === 1){
//           dynamic_multilanguage_option.push({
//             option: options_val[index]["option"],
//             answer: options_val[index]["answer"]
//           });
//         }else{
//           dynamic_multilanguage_option.push({
//             vl_option: options_val[index]["vl_option"],
//             vl_answer: options_val[index]["vl_answer"],
//           });
//         }
       
//       }
//     }
//     let requestData = {
//       url: `Postvernacularcreateorupdate`,
//       payload: {
//         question_id: this.state.question_id,
//         operation: this.state.translation_id
//           ? "FLQC_edit"
//           : storage.getValue("role_id") == 9
//           ? "QC_edit"
//           : "FLQC_create",
//         language_id: this.state.language_id,
//         question_type: this.state.question_type_id,
//         question_category: this.state.question_category_id,
//         question_method: this.state.qm_id,
//         nos_id: this.state.nos_id,
//         pc_id: this.state.pc_id,
//         difficulty_level_id: this.state.difficulty_level_id,
//         question: this.state.vl_question,
//         option: dynamic_multilanguage_option,
//         user_id: storage.getValue("user_id"),
//         user_role_id: storage.getValue("user_role_id"),
//         role_id: storage.getValue("role_id"),
//         translation_id: this.state.translation_id,
//         vl_answer: this.state.vl_question_answer,
//         english_option_value:eng_same_option,
//         is_english_option:is_eng_opt
//       },
//       token: storage.getValue("token"),
//     };

//     const response = await postAPI(requestData, this.props, "v2");

//     if (response) {
//       if (parseInt(response.status) === 200) {
//           if(this.state.questionoptionplatform === 1){
//             eng_opt_val=1;
//           }else{
//             eng_opt_val="";
//           }
//         this.setState({
//           isLoadingComplete: 1,
//           open: false,
//           vl_question: "",
//           vl_option: "",
//           vl_comprehension: "",
//           translation_id: "",
//         });
//         Swal.fire("", response.content, "success");
//         this.loadData();
//       } else {
//         this.setState({ isLoadingComplete: 1 });
//         let errors = {};
//         if (response.content.question) {
//           errors["vl_question"] = response.content.question;
//         }
//         if (response.content.option) {
//           errors["vl_mcq_answer"] = response.content.option;
//         }
//         if (response.content.answer) {
//           errors["vl_subjective_answer"] = response.content.answer;
//         }
//         await this.setState({ errors: errors });
//       }
//     }
//   }

//  async questionUpdate() {
//     this.setState({ isLoadingComplete: 0 });
//     let dynamic_dash_content = [];
//     if (this.state.question_type_id === 1) {
//       let options_value =
//         storage.getValue("role_id") === 9
//           ? Object.values(this.state.moderator_option)
//           : Object.values(this.state.options);
//       let optionss = "";
//       for (let index = 0; index < options_value.length; index++) {
//         if (storage.getValue("role_id") === 8) {
//           if (options_value[index]["answer"] === 1) {
//             optionss += options_value[index]["option_id"] + ",";
//           }
//         } else {
//           dynamic_dash_content.push({
//             option: options_value[index]["option"],
//             answer: options_value[index]["answer"]
//           });
//         }
//         if (optionss !== "" && storage.getValue("role_id") === 8) {
//           await this.setState({ moderator_answer: "" + optionss });
//         }
//       }
//     }

//     let requestData = {
//       url: `PostQuestionCreateUpdate`,
//       payload: {
//         operation: this.state.question_id
//           ? storage.getValue("role_id") === 6
//             ? "setter_edit"
//             : storage.getValue("role_id") === 8
//             ? "moderator_answer"
//             : storage.getValue("role_id") === 7
//             ? "flqc_edit"
//             : storage.getValue("role_id") === 3
//             ? "admin_edit"
//             : "qc_edit"
//           : "setter_create",
//         question_type: this.state.question_type_id,
//         question_category: this.state.question_category_id,
//         question_method_id: this.state.qm_id,
//         nos_id: this.state.nos_id,
//         pc_id: this.state.pc_id,
//         difficulty_level_id: this.state.difficulty_level_id,
//         question: this.state.question,
//         score: this.state.score,
//         negative_score: this.state.negative_score,
//         option: dynamic_dash_content,
//         user_id: storage.getValue("user_id"),
//         user_role_id: storage.getValue("user_role_id"),
//         language_id: 1,
//         reference: this.state.reference,
//         role_id: storage.getValue("role_id"),
//         answer: this.state.question_answer,
//         question_id: this.state.question_id,
//         option_id: this.state.moderator_answer.replace(/,\s*$/, ""),
//         moderator_comment: this.state.moderator_comment,
//         moderator_reference: this.state.moderator_reference,
//         comprehension: this.state.comprehension
//       },
//       token: storage.getValue("token")
//     };

//     const response = await postAPI(requestData, this.props, "v1");

//     if (response) {
//       if (parseInt(response.status) === 200) {
//         Swal.fire("", response.content, "success");
//         if (storage.getValue("role_id") === 3) {
//           this.setState({ isLoadingComplete: 1 });
//           setTimeout(
//             function() {
//               window.location.replace("/question-manager/disabled-questions");
//               /* eslint-disable-next-line*/
//             }.bind(this),
//             3000
//           );
//         } else {
//           this.setState({ isLoadingComplete: 1 });

//           if (this.state.question_id) {
//             this.props.questionBack();
//           } else {
//             setTimeout(
//               function() {
//                 window.location.replace("/qms-dashboard");
//                 /* eslint-disable-next-line*/
//               }.bind(this),
//               3000
//             );
//           }
//         }
//       } else {
//         this.setState({ isLoadingComplete: 1 });
//         let errors = {};
//         if (response.content.question_type) {
//           errors["question_type_id"] = response.content.question_type;
//         }
//         if (response.content.question_category) {
//           errors["question_category_id"] = response.content.question_category;
//         }
//         if (response.content.nos_id) {
//           errors["nos_id"] = response.content.nos_id;
//         }
//         if (response.content.pc_id) {
//           errors["pc_id"] = response.content.pc_id;
//         }
//         if (response.content.difficulty_level_id) {
//           errors["difficulty_level_id"] = response.content.difficulty_level_id;
//         }
//         if (response.content.question) {
//           errors["question"] = response.content.question;
//         }
//         if (response.content.reference) {
//           errors["reference"] = response.content.reference;
//         }
//         if (response.content.option) {
//           errors["mcq_answer"] = response.content.option;
//         }
//         if (response.content.answer) {
//           errors["subjective_answer"] = response.content.answer;
//         }

//         await this.setState({ errors: errors });
//       }
//     }
//   }
//   deleteOptions(id) {
//     var array = Object.values(this.state.options); // make a separate copy of the array
//     var index = array.indexOf(id);
//     if (index === -1) {
//       array.splice(index, 1);
//       this.setState({
//         options: array,
//         option_id: array.length - 1,
//         option: array[array.length - 1].option,
//         answer: array[array.length - 1].answer,
//       });
//     }
//   }
//   deleteVlOptions(id) {
//     var array = Object.values(this.state.vl_options); // make a separate copy of the array
//     var index = array.indexOf(id);
//     if (index === -1) {
//       array.splice(index, 1);
//       this.setState({
//         vl_options: array,
//         vl_option_id: array.length - 1,
//         vl_option: array[array.length - 1].vl_option,
//         vl_answer: array[array.length - 1].vl_answer,
//       });
//     }
//   }
//   checkCondition(id, answer, check) {
//     return (
//       <div>
//         {answer ? (
//           <WebCheckWhiteIcon
//             style={{
//               height: "25px",
//               width: "25px",
//               background: "#8cc842",
//               padding: "4px",
//               marginTop: "3px",
//               marginRight: "3px",
//               borderRadius: "50%",
//               cursor: "pointer"
//             }}
//           />
//         ) : (
//           ""
//         )}

//         <WebEditBlackIcon
//           data-id={id}
//           data-check={check}
//           style={{ height: "30px", cursor: "pointer" }}
//           onClick={this.getClickDrag.bind(this)}
//         />
//         {id !== "0" && id !== "1" && storage.getValue("role_id") === 6 ? (
//           <WebDeleteRedIcon
//             style={{ height: "30px", cursor: "pointer" }}
//             data-id={id}
//             onClick={() => {
//               Swal.fire({
//                 title: "Are you sure you wish to delete this item?",
//                 type: "warning",
//                 showCancelButton: true,
//                 confirmButtonColor: "#24324d",
//                 cancelButtonColor: "#d5d5d5",
//                 confirmButtonText: "Confirm",
//               }).then((result) => {
//                 if (result.value) {
//                   this.deleteOptions(id);
//                 }
//               });
//             }}
//           />
//         ) : (
//           ""
//         )}
//       </div>
//     );
//   }
//   checkVlCondition(id, answer, check) {
//     console.log(id);
//     return (
//       <div>
//         {answer ? (
//           <WebCheckWhiteIcon
//             style={{
//               height: "25px",
//               width: "25px",
//               background: "#8cc842",
//               padding: "4px",
//               marginTop: "3px",
//               marginRight: "3px",
//               borderRadius: "50%",
//               cursor: "pointer"
//             }}
//           />
//         ) : (
//           ""
//         )}

//         <WebEditBlackIcon
//           data-id={id}
//           data-check={check}
//           style={{ height: "30px", cursor: "pointer" }}
//           onClick={this.state.questionoptionplatform === 1 ? (
//             this.getClickDrag.bind(this)
//           ):(
//               this.getVernacularClickDrag.bind(this)
//           )}
//         />
//         {id !== "0" && id !== "1" && storage.getValue("role_id") === 7 ? (
//           <WebDeleteRedIcon
//             style={{ height: "30px", cursor: "pointer" }}
//             data-id={id}
//             onClick={() => {
//               Swal.fire({
//                 title: "Are you sure you wish to delete this item?",
//                 type: "warning",
//                 showCancelButton: true,
//                 confirmButtonColor: "#24324d",
//                 cancelButtonColor: "#d5d5d5",
//                 confirmButtonText: "Confirm"
//               }).then(result => {
//                 if (result.value) {
//                   this.deleteOptions(id);
//                 }
//               });
//             }}
//           />
//         ) : (
//           ""
//         )}
//       </div>
//     );
//   }

//   handleClickOpen = () => {
//     this.setState({
//       open: true,
//     });
//   };
//   handleClickOpen1 = () => {
//     this.setState({
//       open1: true,
//     });
//   };
//    handleClickRejectOpen = () => {
//     this.setState({
//       open2: true,
//     });
//   };

//   handleClickOpen2 = () => {
//     this.setState({
//       open: true,
//     });
//   };

//   handleCloseDialogVl = () => {
//     this.setState({ open: false, errors: "", translation_id: "",questionoptionChecked:false,questionoptionplatform:"",eng_option_value:"" });
//   };

//   handleCloseDialogNew = () => {
//     this.setState({ open: false });
//   };
//   handleCloseDialogNew1 = () => {
//     this.setState({ open1: false });
//   };
//    handleCloseDialogNew2 = () => {
//     this.setState({ open2: false });
//   };
//   optionComponent(opt, check) {
//     const items = Object.values(opt);
//     return (
//       <div style={{ padding: "16px 0" }}>
//         <DragDropContext onDragEnd={this.onDragEnd.bind(this)}>
//           <Droppable droppableId="droppable">
//             {(provided, snapshot) => (
//               <div
//                 {...provided.droppableProps}
//                 ref={provided.innerRef}
//                 style={getListStyle(snapshot.isDraggingOver)}
//               >
//                 {items.map((item, index) => (
//                   <Draggable key={item.id} draggableId={item.id} index={index}>
//                     {(provided, snapshot) => (
//                       <div
//                         ref={provided.innerRef}
//                         {...provided.draggableProps}
//                         {...provided.dragHandleProps}
//                         style={getItemStyle(
//                           snapshot.isDragging,
//                           provided.draggableProps.style
//                         )}
//                       >
//                         <Grid container>
//                           <Grid
//                             item
//                             xs={9}
//                             style={{
//                               display: "flex",
//                               justifyContent: "flex-start"
//                             }}
//                           >
//                             <ReorderIcon style={{ marginRight: 4 }} />
//                             {item.content}
//                           </Grid>
//                           <Grid
//                             item
//                             xs={3}
//                             style={{
//                               display: "flex",
//                               justifyContent: "flex-end"
//                             }}
//                           >
//                             {this.checkCondition(item.id, item.answer, check)}
//                           </Grid>
//                         </Grid>
//                       </div>
//                     )}
//                   </Draggable>
//                 ))}
//                 {provided.placeholder}
//               </div>
//             )}
//           </Droppable>
//         </DragDropContext>
//       </div>
//     );
//   }
//   optionVernacularComponent(opt, check) {
//     const items = Object.values(opt);
//     return (
//       <div style={{ padding: "16px 0" }}>
//         <DragDropContext onDragVlEnd={this.onDragVlEnd.bind(this)}>
//           <Droppable droppableId="droppable">
//             {(provided, snapshot) => (
//               <div
//                 {...provided.droppableProps}
//                 ref={provided.innerRef}
//                 style={getListStyle(snapshot.isDraggingOver)}
//               >
//                 {items.map((item, index) => (
//                   <Draggable key={item.id} draggableId={item.id} index={index}>
//                     {(provided, snapshot) => (
//                       <div
//                         ref={provided.innerRef}
//                         {...provided.draggableProps}
//                         {...provided.dragHandleProps}
//                         style={getItemStyle(
//                           snapshot.isDragging,
//                           provided.draggableProps.style
//                         )}
//                       >
//                         <Grid container>
//                           <Grid
//                             item
//                             xs={9}
//                             style={{
//                               display: "flex",
//                               justifyContent: "flex-start",
//                             }}
//                           >
//                             <ReorderIcon style={{ marginRight: 4 }} />
//                             {item.content}
//                           </Grid>
//                           <Grid
//                             item
//                             xs={3}
//                             style={{
//                               display: "flex",
//                               justifyContent: "flex-end",
//                             }}
//                           >
//                             {this.checkVlCondition(
//                               item.id,
//                               item.vl_answer,
//                               check
//                             )}
//                           </Grid>
//                         </Grid>
//                       </div>
//                     )}
//                   </Draggable>
//                 ))}
//                 {provided.placeholder}
//               </div>
//             )}
//           </Droppable>
//         </DragDropContext>
//       </div>
//     );
//   }
//   updateOptions() {
//     let validation = true;
//     let errors = {};
//     let items1 = 0;

//     let items = Object.values(this.state.options);
//     for (let index = 0; index < items.length; index++) {
//       const check = items[index]["option"];
//       if (check === "") {
//         validation = false;
//       }
//     }

//     if (validation) {
//       if (items.length === 10) {
//         errors["add_more_options"] = "Limit is exceed for options";
//       } else {
//         let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//         let dynamic_option_content = {
//           content: "Option " + letters.charAt(items.length),
//           id: items.length,
//           option: "",
//           answer: 0
//         };
//         items.push(dynamic_option_content);
//         this.setState({
//           options: items,
//           option_id: items.length - 1,
//           answer: 0,
//           option: "",
//         });
//         errors["add_more_options"] = "";
//       }
//     } else {
//       errors["add_more_options"] = "Option should not be empty";
//     }
//     this.setState({ errors: errors });
//   }
//   updateVlOptions() {
//     let validation = true;
//     let errors = {};
//     let items = Object.values(this.state.vl_options);
//     for (let index = 0; index < items.length; index++) {
//       const check = items[index]["vl_option"];
//       if (check === "") {
//         validation = false;
//       }
//     }

//     if (validation) {
//       if (items.length === 10) {
//         errors["add_more_options"] = "Limit is exceed for options";
//       } else {
//         let letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//         let dynamic_option_content = {
//           content: "Option " + letters.charAt(items.length),
//           id: items.length,
//           vl_option: "",
//           vl_answer: 0,
//         };
//         items.push(dynamic_option_content);
//         this.setState({
//           vl_options: items,
//           vl_option_id: items.length - 1,
//           vl_answer: 0,
//           vl_option: "",
//         });
//         errors["add_more_options"] = "";
//       }
//     } else {
//       errors["add_more_options"] = "Option should not be empty";
//     }
//     this.setState({ errors: errors });
//   }
//   async approveRejectQuestion(id) {
//     if (this.state.reason === "") {
//       Swal.fire("", "Enter reason", "warning");
//     } else {
//       this.setState({ isLoadingComplete: 0 });
//       let requestData = {
//         url: `PostQuestionApproveReject`,
//         payload: {
//           operation: "qc",
//           type: "0",
//           question_id: [id],
//           user_id: storage.getValue("user_id"),
//           user_role_id: storage.getValue("user_role_id"),
//           role_id: storage.getValue("role_id"),
//           rejected_reason: this.state.reason ? this.state.reason : ""
//         },
//         token: storage.getValue("token")
//       };

//       const response = await postAPI(requestData, this.props, "v1");

//       if (response) {
//         if (parseInt(response.status) === 200) {
//           this.setState({ isLoadingComplete: 1 });
//           Swal.fire("", "updated successfully", "success");
//           if (this.state.question_id) {
//             this.props.questionBack();
//           }
//         } else {
//           Swal.fire("", "fail", "error");
//         }
//       }
//     }
//   }
//   masterRoleNamesLoad(data) {
//     let master_list_names = [];
//     for (let i = 0; i < data.length; i++) {
//       master_list_names.push(
//         <MenuItem value={data[i].user_id}>
//           {data[i].name + "(" + data[i].email_address + ")"}
//         </MenuItem>
//       );
//     }
//     return master_list_names;
//   }
//   async assignQuestionFlqc() {
//     if (this.state.users_list_id === "") {
//       Swal.fire("Warning!", "Select the User", "warning");
//       return false;
//     } else if (!this.state.question_id) {
//       Swal.fire("Warning!", "Select the Question", "warning");
//     } else {
//       this.setState({ isLoadingComplete: 0 });
//       const requestInput = {
//         url: "PostAssignQuestionUser",
//         token: storage.getValue("token"),
//         payload: {
//           operation: "3",
//           user_id: storage.getValue("user_id"),
//           role_id: storage.getValue("role_id"),
//           user_role_id: storage.getValue("user_role_id"),
//           question_id: [this.state.question_id],
//           assigning_to_id: this.state.users_list_id,
//         },
//       };
//       const version = "v1";
//       const response = await postAPI(requestInput, this.props, version);
//       if (response) {
//         if (parseInt(response.status) === 200) {
//           this.setState({ isLoadingComplete: 1 });
//           Swal.fire("Success!", "Successfully assigned", "success");
//           if (this.state.question_id) {
//             this.props.questionBack();
//           }
//         } else {
//           this.setState({ isLoadingComplete: 1 });
//           Swal.fire(
//             "Oops!! " + response.content + " Failed",
//             "Something went Wrong. Please Try again Later."
//           );
//         }
//       }
//     }
//   }
//   ShowHtml(props) {
//     return <div dangerouslySetInnerHTML={{ __html: props }} />;
//   }
//   async editVlQuestion(question_id, language_id, questions, options, trans_id) {
//     let eng_value;
//     let value = [];
//     let same_opt_value=[];
//     for (let index = 0; index < options.length; index++) {
//       value[index] = options[index].options;
//       same_opt_value=options[index].is_english_option;
//     }
//     console.log("4444", value);
//     this.setState({
//       open: true,
//       vl_question: questions,
//       vl_option: value[0],
//       vl_edit: "edit",
//       translation_id: trans_id,
//       eng_option_value:same_opt_value,
//     });
//     await this.setState({ vl_question_id: question_id });
//     this.triggerApi(
//       `GetIndividualQuestionView?question_id=${question_id}&language_id=${language_id}`,
//       "v1",
//       "vl_update_question"
//     );
//   }
//   vernacularQuestionList() {
//     const vernacular_question = this.state.VernacularQuestions;
//     let new_opt = [];
//     let datas = [];
//     let lang;
//     //let qus = [];
//     for (let index = 0; index < vernacular_question.length; index++) {
//       datas = vernacular_question[index]["QuestionTranslations"];
//     }
//     if (!vernacular_question) {
//       return 0;
//     }
//     const { classes } = this.props;
//     for (let index = 0; index < datas.length; index++) {
//       let question_list = datas[index];

//       // console.log("qus", question_list.QuestionOptions);
//       if (question_list.language_id === 1) {
//         lang = "English";
//       } else if (question_list.language_id === 2) {
//         lang = "Tamil";
//       } else if (question_list.language_id === 3) {
//         lang = "Kannada";
//       }else if (question_list.language_id === 3) {
//         lang = "Kannada";
//       }else if (question_list.language_id === 4) {
//         lang = "Hindi";
//       }else if (question_list.language_id === 5) {
//         lang = "Malayalam";
//       }else if (question_list.language_id === 6) {
//         lang = "Punjabi";
//       }

//       new_opt.push(
//         <div className={classes.cardMargin} key={index}>
//           <Grid container spacing={1}>
//             <Grid item xs={12}>
//               {question_list.language_id !== 1 ? (
//                 <List className={classes.root}>
//                   <Paper>
//                     <ListItem>
//                       <Grid container spacing={0}>
//                         {/* <Grid xs={1}>
//                       </Grid> */}

//                         <Grid xs={11} item>
//                           <ListItemText
//                             disableTypography
//                             style={{ fontSize: "0.9rem" }}
//                             className="QuestionContainer"
//                             //id={labelId}
//                             primary={this.ShowHtml(
//                               "Language Name : " +
//                                 "" +
//                                 lang +
//                                 " " +
//                                 question_list.questions
//                             )}
//                           />
//                         </Grid>
//                         <Grid xs={1} item>
//                           <ListItemSecondaryAction>
//                             <IconButton
//                               edge="end"
//                               aria-label="View"
//                               data-id={question_list.question_id}
//                             ></IconButton>
//                             <IconButton
//                               edge="end"
//                               aria-label="Edit"
//                               data-id={question_list.id}
//                               onClick={this.editVlQuestion.bind(
//                                 this,
//                                 question_list.question_id,
//                                 question_list.language_id,
//                                 question_list.questions,
//                                 question_list.QuestionOptions,
//                                 question_list.id
//                               )}
//                             >
//                               <img src={EditIcon} alt="" height={25} />
//                             </IconButton>
//                             <IconButton
//                               edge="end"
//                               variant="contained"
//                               data-id={question_list.id}
//                               style={{
//                                 textTranform: "none",
//                                 padding: 10,
//                                 marginLeft: 10,
//                               }}
//                             ></IconButton>
//                           </ListItemSecondaryAction>
//                         </Grid>
//                       </Grid>
//                     </ListItem>
//                   </Paper>
//                   {/* })} */}
//                 </List>
//               ) : (
//                 ""
//               )}
//             </Grid>
//           </Grid>
//         </div>
//       );
//     }
//     return new_opt;
//   }
//   searchQuestions() {
//     if (this.state.language_id) {
//       this.setState({
//         isLoadingComplete: 0,
//       });
//       this.triggerApi(
//         `GetUserQuestionView?search=1&status=${
//           this.state.status
//         }&language_id=1&question_type_id=${
//           this.state.question_type_id
//         }&question_category_id=${
//           this.state.question_category_id
//         }&question_method_id=${this.state.question_method_id}&nos_id=${
//           this.state.nos_id
//         }&pc_id=${this.state.pc_id}&difficulty_level_id=${
//           this.state.difficulty_level_id
//         }&role_id=${storage.getValue(
//           "role_id"
//         )}&user_role_id=${storage.getValue(
//           "user_role_id"
//         )}&user_id=${storage.getValue("user_id")}`,
//         "v1",
//         "QuestionList"
//       );
//     } else {
//       Swal.fire("Warning!", "Choose filter option", "warning");
//     }
//   }
//   addImage(source, url) {
//     let content = this.state[source];
//     let imgElement = `<img src=${url}>`;
//     if (content) {
//       this.setState({ [source]: content + imgElement });
//     } else {
//       this.setState({ [source]: imgElement });
//     }
//   }

//   render() {
//     const { classes } = this.props;
//     const stateVar = this.state;

//     return (
//       <div>
//         {this.state.isLoadingComplete ? null : (
//           <Loading
//             loading={true}
//             background="#24324dc9"
//             loaderColor="#8fc740"
//           />
//         )}
//         {this.state.question_id ? (
//           ""
//         ) : (
//           <div>
//             <BreadCrumb
//               BreadCrumbFirst
//               BreadCrumbSecond="QB Manager"
//               BreadCrumbThree="Create Questions"
//             />
//             <div
//               style={{
//                 textAlign: "right",
//                 width: "100%",
//                 marginBottom: "15px"
//               }}
//             >
//               {this.state.activeTab === "one" && (
//                 <Button
//                   variant="contained"
//                   color="primary"
//                   component="span"
//                   onClick={this.downloadTemplate.bind(this)}
//                 >
//                   Download Template
//                 </Button>
//               )}
//             </div>

//             <Paper elevation={0} className={classes.tabToolbar}>
//               <Grid container>
//                 <Grid xs={9}>
//                   <div position="static">
//                     <Tabs
//                       value={this.state.activeTab}
//                       onChange={this.handleChange.bind(this)}
//                       indicatorColor="secondary"
//                     >
//                       <Tab value="one" label="Bulk Upload" />
//                       <Tab value="two" label="Single Question" />
//                     </Tabs>
//                   </div>
//                 </Grid>
//               </Grid>
//             </Paper>
//           </div>
//         )}

//         {this.state.activeTab === "one" && (
//           <TabContainer>
//             <Grid container>
//               <Grid xs={9} style={{ height: "100%" }}>
//                 <Grid
//                   container
//                   style={{
//                     marginTop: "25px",
//                     display: "flex",
//                     alignItems: "center",
//                     flexDirection: "row"
//                   }}
//                 >
//                   <Grid>
//                     <img
//                       alt=""
//                       src={InfoIcon}
//                       style={{ width: "60px", marginTop: "10px" }}
//                     />
//                     {/* <InfoIcon style={{ fontSize: 50, verticalAlign: "middle" }} /> */}
//                   </Grid>
//                   <Grid xs={9} style={{ marginLeft: 10 }}>
//                     <Typography
//                       variant={"h6"}
//                       component={"p"}
//                       style={{ color: "#616161", lineHeight: "22px" }}
//                     >
//                       Failure questions messages are return into the excel{" "}
//                       <br />
//                       Report Remaining Questions are Uploaded Successfully
//                     </Typography>
//                   </Grid>
//                 </Grid>
//                 <div style={{ marginTop: 30 }}>
//                   <input
//                     className={classes.input}
//                     id="qus-bulk-upload"
//                     type="file"
//                     accept=".xlsx, .xls, .csv"
//                     onChange={this.uploadBulkQuestions.bind(this)}
//                   />
//                   <FormControl className={classes.margin}>
//                     <BootstrapInput
//                       id="bootstrap-input"
//                       placeholder="No files selected"
//                       value={this.state.uploadFileName}
//                     />
//                   </FormControl>
//                   <label htmlFor="qus-bulk-upload">
//                     <Button
//                       variant="contained"
//                       color="primary"
//                       component="span"
//                       className={classes.browseButton}
//                     >
//                       Browse Excel File
//                     </Button>
//                   </label>
//                 </div>

//                 <div style={{ marginTop: "20px" }}>
//                   <Button
//                     variant="contained"
//                     size="medium"
//                     color="primary"
//                     className={classes.uploadButton}
//                     onClick={this.uploadQuestions.bind(this)}
//                   >
//                     <img alt="" src={UploadIcon} style={{ width: "35px" }} />
//                     Upload Questions
//                   </Button>
//                 </div>
//               </Grid>
//             </Grid>
//           </TabContainer>
//         )}
//         {this.state.activeTab === "two" && (
//           <TabContainer>
//             <form
//               className="form-horizontal"
//               name="myForm"
//               style={{
//                 display: "flex",
//                 flexDirection: "column",
//                 height: "100%",
//                 justifyContent: "space-between"
//               }}
//               onSubmit={this.questionSubmit.bind(this)}
//             >
//               <Grid container spacing={2} style={{ marginTop: "10px" }}>
//                 <Grid item xs={3}>
//                   <FormControl style={{ width: "100%" }}>
//                     <InputLabel
//                       style={{
//                         position: "relative",
//                         marginBottom: "0px"
//                       }}
//                       shrink
//                       htmlFor="bootstrap-input"
//                     >
//                       <Typography variant="h6">Question Type</Typography>
//                     </InputLabel>
//                     <Select
//                       disabled={
//                         storage.getValue("role_id") === 8 ||
//                         storage.getValue("role_id") === 7 ||
//                         storage.getValue("role_id") === 9
//                           ? true
//                           : false
//                       }
//                       style={{ height: "46px" }}
//                       value={this.state.question_type_id}
//                       onChange={this.masterChange.bind(this)}
//                       displayEmpty
//                       input={
//                         <OutlinedInput
//                           name="question_type_id"
//                           id="bootstrap-input"
//                         />
//                       }
//                     >
//                       <MenuItem value="" disabled>
//                         <em>Question Type</em>
//                       </MenuItem>
//                       {this.masterLoad(
//                         this.state.question_type,
//                         "question_type"
//                       )}
//                     </Select>
//                     <span style={{ color: "red" }}>
//                       {this.state.errors["question_type_id"]}
//                     </span>
//                   </FormControl>
//                 </Grid>
//                 <Grid item xs={3}>
//                   <FormControl style={{ width: "100%" }}>
//                     <InputLabel
//                       style={{
//                         position: "relative",
//                         marginBottom: "0px"
//                       }}
//                       shrink
//                       htmlFor="bootstrap-input"
//                     >
//                       <Typography variant="h6">Question Category</Typography>
//                     </InputLabel>
//                     <Select
//                       disabled={
//                         storage.getValue("role_id") === 8 ? true : false
//                       }
//                       style={{ height: "46px" }}
//                       value={this.state.question_category_id}
//                       onChange={this.masterChange.bind(this)}
//                       displayEmpty
//                       input={
//                         <OutlinedInput
//                           name="question_category_id"
//                           id="bootstrap-input"
//                         />
//                       }
//                     >
//                       <MenuItem value="">
//                         <em>Question Category</em>
//                       </MenuItem>
//                       {this.masterLoad(
//                         this.state.question_category,
//                         "question_category"
//                       )}
//                     </Select>
//                     <span style={{ color: "red" }}>
//                       {this.state.errors["question_category_id"]}
//                     </span>
//                   </FormControl>
//                 </Grid>
//                 {this.state.question_type_id === 1 ? (
//                   <Grid item xs={3}>
//                     <FormControl style={{ width: "100%" }}>
//                       <InputLabel
//                         style={{
//                           position: "relative",
//                           marginBottom: "0px"
//                         }}
//                         shrink
//                         htmlFor="bootstrap-input"
//                       >
//                         <Typography variant="h6">Question Method</Typography>
//                       </InputLabel>
//                       <Select
//                         disabled={
//                           storage.getValue("role_id") === 8 ? true : false
//                         }
//                         style={{ height: "46px" }}
//                         value={this.state.qm_id ? this.state.qm_id : ""}
//                         onChange={this.masterChange.bind(this)}
//                         displayEmpty
//                         input={
//                           <OutlinedInput name="qm_id" id="bootstrap-input" />
//                         }
//                       >
//                         <MenuItem value="" disabled>
//                           <em>Question Method</em>
//                         </MenuItem>
//                         {this.masterLoad(this.state.qm, "qms")}
//                       </Select>
//                       <span style={{ color: "red" }}>
//                         {this.state.errors["qm_id"]}
//                       </span>
//                     </FormControl>
//                   </Grid>
//                 ) : (
//                   ""
//                 )}

//                 <Grid item xs={2}>
//                   <FormControl style={{ width: "100%" }}>
//                     <InputLabel
//                       style={{
//                         position: "relative",
//                         marginBottom: "0px"
//                       }}
//                       shrink
//                       htmlFor="bootstrap-input"
//                     >
//                       <Typography variant="h6">NOS</Typography>
//                     </InputLabel>
//                     <Select
//                       disabled={
//                         storage.getValue("role_id") === 8 ? true : false
//                       }
//                       style={{ height: "46px" }}
//                       value={this.state.nos_id}
//                       onChange={this.masterChange.bind(this)}
//                       displayEmpty
//                       input={
//                         <OutlinedInput name="nos_id" id="bootstrap-input" />
//                       }
//                     >
//                       <MenuItem value="">
//                         <em>Nos</em>
//                       </MenuItem>
//                       {this.masterLoad(this.state.nos, "nos")}
//                     </Select>
//                     <span style={{ color: "red" }}>
//                       {this.state.errors["nos_id"]}
//                     </span>
//                   </FormControl>
//                 </Grid>
//                 <Grid item xs={2}>
//                   <FormControl style={{ width: "100%" }}>
//                     <InputLabel
//                       style={{
//                         position: "relative",
//                         marginBottom: "0px"
//                       }}
//                       shrink
//                       htmlFor="bootstrap-input"
//                     >
//                       <Typography variant="h6">PC</Typography>
//                     </InputLabel>
//                     <Select
//                       disabled={
//                         storage.getValue("role_id") === 8 ? true : false
//                       }
//                       style={{ height: "46px" }}
//                       value={this.state.pc_id}
//                       onChange={this.masterChange.bind(this)}
//                       displayEmpty
//                       input={
//                         <OutlinedInput name="pc_id" id="bootstrap-input" />
//                       }
//                     >
//                       <MenuItem value="">
//                         <em>PC</em>
//                       </MenuItem>
//                       {this.masterLoad(this.state.pc, "pc")}
//                     </Select>
//                     <span style={{ color: "red" }}>
//                       {this.state.errors["pc_id"]}
//                     </span>
//                   </FormControl>
//                 </Grid>
//                 <Grid item xs={2}>
//                   <FormControl style={{ width: "100%" }}>
//                     <InputLabel
//                       style={{
//                         position: "relative",
//                         marginBottom: "0px"
//                       }}
//                       shrink
//                       htmlFor="bootstrap-input"
//                     >
//                       <Typography variant="h6">Difficult Level</Typography>
//                     </InputLabel>
//                     <Select
//                       disabled={
//                         storage.getValue("role_id") === 8 ? true : false
//                       }
//                       style={{ height: "46px" }}
//                       value={this.state.difficulty_level_id}
//                       onChange={this.masterChange.bind(this)}
//                       displayEmpty
//                       input={
//                         <OutlinedInput
//                           name="difficulty_level_id"
//                           id="bootstrap-input"
//                         />
//                       }
//                     >
//                       <MenuItem value="">
//                         <em>Difficulty Level</em>
//                       </MenuItem>
//                       {this.masterLoad(
//                         this.state.difficulty_level,
//                         "difficulty_level"
//                       )}
//                     </Select>
//                     <span style={{ color: "red" }}>
//                       {this.state.errors["difficulty_level_id"]}
//                     </span>
//                   </FormControl>
//                 </Grid>
//                 <Grid item xs={2} />
//               </Grid>
//               {this.state.question_type_id === 1 &&
//               storage.getValue("role_id") == 7 ||
//               storage.getValue("role_id") == 3 ||
//               storage.getValue("role_id") == 9 ? (
//                 <ExpansionPanel
//                   style={{
//                     background: "#f8f9eb",
//                     marginTop: "20px",
//                   }}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1a-content"
//                     id="panel1a-header"
//                   >
//                     <Grid container className={classes.QuestionContainer}>
//                       <Grid item xs={3}>
//                           <Typography className={classes.heading}>
//                             {storage.getValue('role_id') === 7 ? (
//                                 "Add Vernacular Questions"
//                             ): (
//                                 "Vernacular Questions"
//                             )}
//                         </Typography>
//                         <Grid item></Grid>
//                       </Grid>
//                       <Grid
//                         xs={9}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between",
//                         }}
//                       >
//                         {storage.getValue("role_id") == 7 ? (
//                           <Button
//                             style={{ marginLeft: "auto" }}
//                             type="button"
//                             variant="contained"
//                             color="primary"
//                             input={
//                               <OutlinedInput
//                                 name="venacular_id"
//                                 id="bootstrap-input"
//                               />
//                             }
//                             value={this.state.question_type_id}
//                             onClick={this.openModel.bind(this)}
//                           >
//                             Create Vernacular Questions
//                           </Button>
//                         ) : (
//                           ""
//                         )}
//                       </Grid>

//                       {this.vernacularQuestionList()
//                         ? this.vernacularQuestionList()
//                         : ""}
//                     </Grid>
//                   </ExpansionPanelSummary>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}
//               <Dialog
//                 disableBackdropClick
//                 fullWidth={"lg"}
//                 maxWidth={"lg"}
//                 onClose={this.handleCloseDialogNew}
//                 aria-labelledby="customized-dialog-title"
//                 open={this.state.open}
//               >
//                 <DialogTitle
//                   id="customized-dialog-title"
//                   onClose={this.handleCloseDialogVl}
//                 ></DialogTitle>
//                 <DialogContent dividers>
//                   <DialogActions
//                     style={{
//                       width: "100%",
//                       display: "flex",
//                       justifyContent: "center",
//                       alignItems: "center",
//                       flexDirection: "column",
//                     }}
//                     margin={{ top: 5 }}
//                   ></DialogActions>
//                   {storage.getValue("role_id") == 7 ||
//                   storage.getValue("role_id") == 9 ||
//                   storage.getValue("role_id") == 3 ? (
//                     <div>
//                       <Grid item xs={7}>
//                         <FormControl style={{ width: "100%" }}>
//                           <InputLabel
//                             style={{
//                               position: "relative",
//                               marginBottom: "0px",
//                             }}
//                             shrink
//                             htmlFor="bootstrap-input"
//                           >
//                             <Typography
//                               variant="h6"
//                               style={{ padding: "20px 4px" }}
//                             >
//                               Language
//                             </Typography>
//                             <span style={{ color: "red", padding: "10px 4px" }}>
//                               Note:Already created language's question is
//                               changed that language question is update only
//                             </span>
//                           </InputLabel>
//                         </FormControl>
//                       </Grid>
//                       <Grid item xs={2}>
//                         <FormControl style={{ width: "100%" }}>
//                           <Select
//                             disabled={this.state.translation_id ? true : false}
//                             style={{ height: "46px" }}
//                             value={this.state.language_id}
//                             onChange={this.masterChange.bind(this)}
//                             displayEmpty
//                             input={
//                               <OutlinedInput
//                                 name="language_id"
//                                 id="bootstrap-input"
//                               />
//                             }
//                           >
//                             <MenuItem value="">
//                               <em>Select Preferred Language</em>
//                             </MenuItem>

//                             {stateVar.language.length
//                               ? stateVar.language.map((option) =>
//                                   option.id !== 1 ? (
//                                     <MenuItem key={option.id} value={option.id}>
//                                       {option.name}
//                                     </MenuItem>
//                                   ) : (
//                                     ""
//                                   )
//                                 )
//                               : ""}
//                           </Select>
//                           <span style={{ color: "red" }}>
//                             {this.state.errors["vl_language_error"]}
//                           </span>
//                         </FormControl>
//                       </Grid>
//                     </div>
//                   ) : (
//                     ""
//                   )}
//                   <ExpansionPanel
//                     style={{
//                       background: "#f8f9eb",
//                       marginTop: "20px",
//                     }}
//                   >
//                     <ExpansionPanelSummary
//                       expandIcon={<ExpandMoreIcon />}
//                       aria-controls="panel1a-content"
//                       id="panel1a-header"
//                     >
//                       <Grid container>
//                         <Grid item xs={3}>
//                           <Typography className={classes.heading}>
//                             Comprehension
//                           </Typography>
//                         </Grid>
//                         <Grid
//                           xs={9}
//                           item
//                           style={{
//                             display: "flex",
//                             justifyContent: "space-between",
//                           }}
//                         >
//                           <Typography className={classes.heading}>
//                             [OPTIONAL]
//                           </Typography>
//                           <Typography style={{ color: "red" }}>
//                             {this.state.errors["vl_comprehension"]}
//                           </Typography>
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelSummary>

//                     <ExpansionPanelDetails style={{ padding: "0px" }}>
//                       <Grid container>
//                         <Grid item xs={12}>
//                           <CKEditor
//                             readOnly={
//                               this.state.translation_id !== "" &&
//                               storage.getValue("role_id") == 7
//                                 ? true
//                                 : false
//                             }
//                             config={{
//                               readOnly:
//                                 this.state.translation_id !== "" &&
//                                 storage.getValue("role_id") == 7
//                                   ? true
//                                   : false,
//                               extraPlugins: "mathjax",
//                               removePlugins: "image",
//                               removeButtons: "Source",
//                               filebrowserImageBrowseUrl: "",
//                               filebrowserFlashBrowseUrl: "",
//                               filebrowserBrowseUrl: "",
//                               mathJaxLib:
//                                 "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML",
//                             }}
//                             type="classic"
//                             data={this.state.vl_comprehension}
//                             onChange={(event) => {
//                               let html = event.editor.getSnapshot();
//                               let dom = document.createElement("DIV");
//                               dom.innerHTML = html;
//                               let plain_text = dom.textContent || dom.innerText;
//                               if (
//                                 // eslint-disable-next-line
//                                 plain_text.trim() != "" &&
//                                 plain_text.trim() !== ""
//                               ) {
//                                 this.setState({
//                                   vl_comprehension: event.editor.getData(),
//                                 });
//                               } else {
//                                 this.setState({
//                                   vl_comprehension: "",
//                                 });
//                               }
//                               this.handleValidation();
//                             }}
//                           />
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelDetails>
//                   </ExpansionPanel>
//                   <ExpansionPanel
//                     style={{
//                       background: "#f8f9eb",
//                       marginTop: "10px",
//                       marginBottom: "10px",
//                     }}
//                     expanded={true}
//                   >
//                     <ExpansionPanelSummary
//                       expandIcon={<ExpandMoreIcon />}
//                       aria-controls="panel2a-content"
//                       id="panel2a-header"
//                     >
//                       <Grid container>
//                         <Grid item xs={3}>
//                           <Typography className={classes.heading}>
//                             Question
//                           </Typography>
//                         </Grid>
//                         <Grid
//                           xs={9}
//                           item
//                           style={{
//                             display: "flex",
//                             justifyContent: "space-between",
//                           }}
//                         >
//                           <Typography className={classes.heading}>
//                             [REQUIRED]
//                           </Typography>
//                           <Typography style={{ color: "red" }}>
//                             {this.state.errors["vl_question"]}
//                           </Typography>
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelSummary>
//                     <ExpansionPanelDetails style={{ padding: "0px" }}>
//                       <Grid container>
//                         <Grid item xs={12}>
//                           {storage.getValue("role_id") == 7 || storage.getValue("role_id") == 9 || storage.getValue("role_id") == 3 ? (
//                             <ImageUpload
//                               addImage={this.addImage.bind(this, "vl_question")}
//                               top={69}
//                               left={302}
//                             />
//                           ) : (
//                             ""
//                           )}

//                           {this.state.isFetching || !this.props.questionID ? (
//                             <CKEditor
//                               // readOnly={
//                               //   this.state.translation_id !== "" &&
//                               //   storage.getValue("role_id") == 7
//                               //     ? true
//                               //     : false
//                               // }
//                               config={{
//                                 readOnly:
//                                   this.state.translation_id !== "" &&
//                                   storage.getValue("role_id") == 7
//                                     ? true
//                                     : false,
//                                 extraPlugins: "mathjax",
//                                 removePlugins: "image",
//                                 removeButtons: "Source",
//                                 filebrowserImageBrowseUrl: "",
//                                 filebrowserFlashBrowseUrl: "",
//                                 filebrowserBrowseUrl: "",
//                                 mathJaxLib:
//                                   "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML",
//                               }}
//                               id="editor"
//                               type="classic"
//                               data={this.state.vl_question}
//                               value={this.state.vl_question}
//                               onChange={(event) => {
//                                 let html = event.editor.getSnapshot();
//                                 let dom = document.createElement("DIV");
//                                 dom.innerHTML = html;
//                                 let plain_text =
//                                   dom.textContent || dom.innerText;
//                                 if (
//                                   /* eslint-disable-next-line*/
//                                   plain_text.trim() != "" &&
//                                   plain_text.trim() !== ""
//                                 ) {
//                                   this.setState({
//                                     vl_question: event.editor.getData(),
//                                   });
//                                 } else {
//                                   this.setState({
//                                     vl_question: "",
//                                   });
//                                 }
//                                 this.handleValidation();
//                               }}
//                             />
//                           ) : (
//                             ""
//                           )}
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelDetails>
//                   </ExpansionPanel>
//                   <Grid container style={{ marginTop: "10px" }} spacing={4}>
//                 <Grid item xs={6} md={6}>
//                   {this.loadQuestionOptionCheckbox()}
//                 </Grid>
//               </Grid>

//                   {this.state.question_type_id === 1 ? (
//                     <ExpansionPanel
//                       style={{ background: "#f8f9eb", marginBottom: "10px" }}
//                       expanded={true}
//                     >
//                       <ExpansionPanelSummary
//                         expandIcon={<ExpandMoreIcon />}
//                         aria-controls="panel2a-content"
//                         id="panel2a-header"
//                       >
//                         <Grid container>
//                           <Grid
//                             xs={3}
//                             item
//                             style={{
//                               display: "flex",
//                               justifyContent: "space-between",
//                             }}
//                           >
//                             <Typography className={classes.heading}>
//                               Answer
//                             </Typography>
//                           </Grid>
//                           <Grid
//                             item
//                             xs={9}
//                             style={{
//                               display: "flex",
//                               justifyContent: "space-between",
//                             }}
//                           >
//                             <Typography className={classes.heading}>
//                               [REQUIRED]
//                             </Typography>
//                             <Typography style={{ color: "red" }}>
//                               {this.state.errors["vl_mcq_answer"]}
//                             </Typography>
//                           </Grid>
//                         </Grid>
//                       </ExpansionPanelSummary>
//                       <Divider />
//                       <ExpansionPanelDetails style={{ padding: "0px" }}>
//                         <Grid
//                           container
//                           style={{
//                             display: "flex",

//                             flexDirection: "row",
//                           }}
//                         >
//                           <Grid
//                             item
//                             xs={6}
//                             style={{
//                               padding: "20px",
//                               borderRight: "1px solid #ccc",
//                             }}
//                           >
//                             <Typography variant="h5">
//                               Add option for the Question
//                             </Typography>

//                             <Box mb={2} mt={2}>
//                               {storage.getValue("role_id") == 7 || storage.getValue("role_id") == 9 || storage.getValue("role_id") == 3  ? (
//                                 <ImageUpload
//                                   addImage={this.addImage.bind(
//                                     this,
//                                     "vl_option"
//                                   )}
//                                   top={133}
//                                   left={322}
//                                 />
//                               ) : (
//                                 ""
//                               )}
//                               <CKEditor
//                                 // readOnly={
//                                 //   this.state.translation_id !== "" &&
//                                 //   storage.getValue("role_id") == 7
//                                 //     ? true
//                                 //     : false
//                                 // }
//                                 config={{
//                                   readOnly:
//                                     this.state.translation_id !== "" &&
//                                     storage.getValue("role_id") == 7
//                                       ? true
//                                       : false,
//                                   extraPlugins: "mathjax",
//                                   removePlugins: "image",
//                                   removeButtons: "Source",
//                                   filebrowserImageBrowseUrl: "",
//                                   filebrowserFlashBrowseUrl: "",
//                                   filebrowserBrowseUrl: "",
//                                   mathJaxLib:
//                                     "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML",
//                                 }}
//                                 type="classic"
//                                 data={this.state.questionoptionplatform == 1 ? (
//                                   this.state.option
//                                 ):(
//                                   this.state.vl_option
//                                 )}
//                                 // data={this.state.vl_option}
//                                 onChange={(event) => {
//                                   let html = event.editor.getSnapshot();
//                                   let dom = document.createElement("DIV");
//                                   dom.innerHTML = html;
//                                   let plain_text =
//                                     dom.textContent || dom.innerText;
//                                   if(this.state.questionoptionplatform === 1){
//                                           if (
//                                         /* eslint-disable-next-line*/
//                                         plain_text.trim() != "" &&
//                                         plain_text.trim() !== ""
//                                       ) {
//                                         this.setState({
//                                           options: {
//                                             ...this.state.options,
//                                             [this.state.option_id]: {
//                                               ...this.state.options[
//                                                 this.state.option_id
//                                               ],
//                                               option: event.editor.getData()
//                                             }
//                                           },
//                                           option: event.editor.getData()
//                                         });
//                                       } else {
//                                         this.setState({
//                                           options: {
//                                             ...this.state.options,
//                                             [this.state.option_id]: {
//                                               ...this.state.options[
//                                                 this.state.option_id
//                                               ],
//                                               option: ""
//                                             }
//                                           },
//                                           option: ""
//                                         });
//                                       }
//                                   }else{
//                                      if (
//                                     /* eslint-disable-next-line*/
//                                     plain_text.trim() !== "" &&
//                                     plain_text.trim() !== ""
//                                   ) {
//                                     this.setState({
//                                       vl_options: {
//                                         ...this.state.vl_options,
//                                         [this.state.vl_option_id]: {
//                                           ...this.state.vl_options[
//                                             this.state.vl_option_id
//                                           ],
//                                           vl_option: event.editor.getData(),
//                                         },
//                                       },
//                                       vl_option: event.editor.getData(),
//                                     });
//                                   } else {
//                                     this.setState({
//                                       vl_options: {
//                                         ...this.state.vl_options,
//                                         [this.state.vl_option_id]: {
//                                           ...this.state.vl_options[
//                                             this.state.vl_option_id
//                                           ],
//                                           vl_option: "",
//                                         },
//                                       },
//                                       vl_option: "",
//                                     });
//                                   }
//                                   }  
                                 
//                                   this.handleVernacularQuestionValidation();
//                                 }}
//                               />
//                             </Box>

//                             <Grid container spacing={1}>
//                               <Grid item xs={6}>
//                                 <InputLabel
//                                   style={{
//                                     position: "relative",
//                                     marginBottom: "0px",
//                                   }}
//                                   shrink
//                                   htmlFor="bootstrap-input"
//                                 >
//                                   <Typography variant="h5">
//                                     Is Correct Option
//                                   </Typography>
//                                 </InputLabel>
//                               </Grid>
//                               <Grid item xs={6}>
//                                 <FormControlLabel
//                                   control={
//                                     <Switch
//                                       color="primary"
//                                       checked={
//                                         this.state.questionoptionplatform === 1 ? ( 
//                                           this.state.answer ? true : false
//                                         ):(
//                                            this.state.vl_answer ? true : false
//                                         )}
//                                       onChange={this.updateMultiLanguageAnswerKey.bind(
//                                         this
//                                       )}
//                                       value={this.state.questionoptionplatform === 1 ? (
//                                         this.state.answer
//                                       ):(
//                                             this.state.vl_answer
//                                       )}
//                                     />
//                                   }
//                                   label={this.state.questionoptionplatform === 1 ? (
//                                     this.state.answer ? "ON" : "OFF"
//                                     ):(
//                                       this.state.vl_answer ? "ON" : "OFF"
//                                     )}
//                                 />
//                               </Grid>
//                             </Grid>
//                           </Grid>
//                           <Grid item xs={6} style={{ padding: "20px" }}>
//                             <Typography variant="h5">Answer</Typography>
//                             <Typography variant="h6" style={{ color: "red" }}>
//                               {this.state.errors["add_more_options"]}
//                             </Typography>
//                             {this.state.questionoptionplatform === 1 ? (
//                               this.optionComponent(this.state.options)
//                             ):(
//                               this.optionVernacularComponent(
//                               this.state.vl_options
//                             )
//                             )}
//                             {storage.getValue("role_id") == 7 &&
//                             this.state.translation_id === "" ? (
//                               <Button
//                                 variant="contained"
//                                 color="primary"
//                                 onClick={this.updateVlOptions.bind(this)}
//                               >
//                                 Add More
//                               </Button>
//                             ) : (
//                               ""
//                             )}
//                             <Grid
//                               container
//                               style={{
//                                 marginBottom: "15px",
//                                 display: "flex",
//                                 alignItems: "center",
//                               }}
//                             >
//                               <Grid>
//                                 <img
//                                   alt=""
//                                   src={InfoIcon}
//                                   style={{ width: "30px" }}
//                                 />
//                               </Grid>
//                               <Grid xs={9} style={{ marginLeft: 10 }} item>
//                                 <Typography
//                                   variant={"caption"}
//                                   component={"p"}
//                                   style={{ color: "#616161" }}
//                                 >
//                                   Drag and arrange the Options the sequence you
//                                   wanted to apper while taking test for Answers
//                                 </Typography>
//                               </Grid>
//                             </Grid>
//                             <Grid container style={{ marginBottom: "15px" }}>
//                               <Grid>
//                                 <WebCheckWhiteIcon
//                                   style={{
//                                     height: "20px",
//                                     width: "20px",
//                                     background: "#8cc842",
//                                     padding: "4px",
//                                     margin: "0 5px",
//                                     borderRadius: "50%",
//                                   }}
//                                 />
//                               </Grid>
//                               <Grid xs={9} style={{ marginLeft: 10 }} item>
//                                 <Typography
//                                   variant={"caption"}
//                                   component={"p"}
//                                   style={{ color: "#616161" }}
//                                 >
//                                   Indicated the Correct option for the Question
//                                 </Typography>
//                               </Grid>
//                             </Grid>
//                           </Grid>
//                         </Grid>
//                       </ExpansionPanelDetails>
//                     </ExpansionPanel>
//                   ) : (
//                     ""
//                   )}
//                   {this.state.question_type_id === 2 ? (
//                     <ExpansionPanel
//                       style={{
//                         background: "#f8f9eb",
//                       }}
//                       expanded={true}
//                     >
//                       <ExpansionPanelSummary
//                         expandIcon={<ExpandMoreIcon />}
//                         aria-controls="panel1a-content"
//                         id="panel1a-header"
//                       >
//                         <Grid container>
//                           <Grid item xs={3}>
//                             <Typography className={classes.heading}>
//                               Answer
//                             </Typography>
//                           </Grid>
//                           <Grid
//                             xs={9}
//                             item
//                             style={{
//                               display: "flex",
//                               justifyContent: "space-between",
//                             }}
//                           >
//                             <Typography className={classes.heading}>
//                               [REQUIRED]
//                             </Typography>
//                             <Typography style={{ color: "red" }}>
//                               {this.state.errors["vl_subjective_answer"]}
//                             </Typography>
//                           </Grid>
//                         </Grid>
//                       </ExpansionPanelSummary>

//                       <ExpansionPanelDetails style={{ padding: "0px" }}>
//                         <Grid container>
//                           <Grid item xs={12}>
//                             <CKEditor
//                               // readOnly={
//                               //   this.state.translation_id !== "" &&
//                               //   storage.getValue("role_id") == 7
//                               //     ? true
//                               //     : false
//                               // }
//                               config={{
//                                 readOnly:
//                                   this.state.translation_id !== "" &&
//                                   storage.getValue("role_id") == 7
//                                     ? true
//                                     : false,
//                                 extraPlugins: "mathjax",
//                                 removePlugins: "image",
//                                 removeButtons: "Source",
//                                 filebrowserImageBrowseUrl: "",
//                                 filebrowserFlashBrowseUrl: "",
//                                 filebrowserBrowseUrl: "",
//                                 mathJaxLib:
//                                   "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML",
//                               }}
//                               type="classic"
//                               data={this.state.vl_question_answer}
//                               value={this.state.vl_question_answer}
//                               onChange={(event) => {
//                                 let html = event.editor.getSnapshot();
//                                 let dom = document.createElement("DIV");
//                                 dom.innerHTML = html;
//                                 let plain_text =
//                                   dom.textContent || dom.innerText;
//                                 if (
//                                   /* eslint-disable-next-line*/
//                                   plain_text.trim() != "" &&
//                                   plain_text.trim() !== ""
//                                 ) {
//                                   this.setState({
//                                     vl_question_answer: event.editor.getData(),
//                                   });
//                                 } else {
//                                   this.setState({
//                                     vl_question_answer: "",
//                                   });
//                                 }

//                                 this.handleVernacularQuestionValidation();
//                               }}
//                             />
//                           </Grid>
//                         </Grid>
//                       </ExpansionPanelDetails>
//                     </ExpansionPanel>
//                   ) : (
//                     ""
//                   )}
//                   {storage.getValue("role_id") == 7 ||
//                   storage.getValue("role_id") == 9 ||
//                   storage.getValue("role_id") == 3 ? (
//                     <Button
//                       type="button"
//                       variant="contained"
//                       size="medium"
//                       color="primary"
//                       className={classes.uploadButton}
//                       id="testings"
//                       onClick={this.vernacularQuestionSubmit.bind(this)}
//                       name="vl_create"
//                     >
//                       {this.state.translation_id === ""
//                         ? "Add Question"
//                         : "Update Question"}
//                     </Button>
//                   ) : (
//                     ""
//                   )}
//                 </DialogContent>
//               </Dialog>

//               <ExpansionPanel
//                 style={{
//                   background: "#f8f9eb",
//                   marginTop: "20px"
//                 }}
//               >
//                 <ExpansionPanelSummary
//                   expandIcon={<ExpandMoreIcon />}
//                   aria-controls="panel1a-content"
//                   id="panel1a-header"
//                 >
//                   <Grid container>
//                     <Grid item xs={3}>
//                       <Typography className={classes.heading}>
//                         Comprehension
//                       </Typography>
//                     </Grid>
//                     <Grid
//                       xs={9}
//                       item
//                       style={{
//                         display: "flex",
//                         justifyContent: "space-between"
//                       }}
//                     >
//                       <Typography className={classes.heading}>
//                         [OPTIONAL]
//                       </Typography>
//                       <Typography style={{ color: "red" }}>
//                         {this.state.errors["comprehension"]}
//                       </Typography>
//                     </Grid>
//                   </Grid>
//                 </ExpansionPanelSummary>

//                 <ExpansionPanelDetails style={{ padding: "0px" }}>
//                   <Grid container>
//                     <Grid item xs={12}>
//                       <CKEditor
//                         readOnly={
//                           storage.getValue("role_id") === 8 ? true : false
//                         }
//                         config={{
//                           extraPlugins: "mathjax",
//                           removePlugins: "image",
//                           removeButtons: "Source",
//                           filebrowserImageBrowseUrl: "",
//                           filebrowserFlashBrowseUrl: "",
//                           filebrowserBrowseUrl: "",
//                           mathJaxLib:
//                             "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                         }}
//                         type="classic"
//                         data={this.state.comprehension}
//                         onChange={event => {
//                           let html = event.editor.getSnapshot();
//                           let dom = document.createElement("DIV");
//                           dom.innerHTML = html;
//                           let plain_text = dom.textContent || dom.innerText;
//                           if (
//                             // eslint-disable-next-line
//                             plain_text.trim() != "" &&
//                             plain_text.trim() !== ""
//                           ) {
//                             this.setState({
//                               comprehension: event.editor.getData()
//                             });
//                           } else {
//                             this.setState({
//                               comprehension: ""
//                             });
//                           }
//                           this.handleValidation();
//                         }}
//                       />
//                     </Grid>
//                   </Grid>
//                 </ExpansionPanelDetails>
//               </ExpansionPanel>

//               <ExpansionPanel
//                 style={{
//                   background: "#f8f9eb",
//                   marginTop: "10px",
//                   marginBottom: "10px"
//                 }}
//                 expanded={true}
//               >
//                 <ExpansionPanelSummary
//                   expandIcon={<ExpandMoreIcon />}
//                   aria-controls="panel2a-content"
//                   id="panel2a-header"
//                 >
//                   <Grid container>
//                     <Grid item xs={3}>
//                       <Typography className={classes.heading}>
//                         Question
//                       </Typography>
//                     </Grid>
//                     <Grid
//                       xs={9}
//                       item
//                       style={{
//                         display: "flex",
//                         justifyContent: "space-between"
//                       }}
//                     >
//                       <Typography className={classes.heading}>
//                         [REQUIRED]
//                       </Typography>
//                       <Typography style={{ color: "red" }}>
//                         {this.state.errors["question"]}
//                       </Typography>
//                     </Grid>
//                   </Grid>
//                 </ExpansionPanelSummary>
//                 <ExpansionPanelDetails style={{ padding: "0px" }}>
//                   <Grid container>
//                     <Grid item xs={12}>
//                       {storage.getValue("role_id") !== 8 ? (
//                         <ImageUpload
//                           addImage={this.addImage.bind(this, "question")}
//                           top={69}
//                           left={302}
//                         />
//                       ) : (
//                         ""
//                       )}
//                       {this.state.isFetching || !this.props.questionID ? (
//                         <CKEditor
//                           readOnly={
//                             storage.getValue("role_id") === 8 ? true : false
//                           }
//                           config={{
//                             extraPlugins: "mathjax",
//                             removePlugins: "image",
//                             removeButtons: "Source",
//                             filebrowserImageBrowseUrl: "",
//                             filebrowserFlashBrowseUrl: "",
//                             filebrowserBrowseUrl: "",
//                             mathJaxLib:
//                               "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                           }}
//                           id="editor"
//                           type="classic"
//                           data={this.state.question}
//                           onChange={event => {
//                             let html = event.editor.getSnapshot();
//                             let dom = document.createElement("DIV");
//                             dom.innerHTML = html;
//                             let plain_text = dom.textContent || dom.innerText;
//                             if (
//                               /* eslint-disable-next-line*/
//                               plain_text.trim() != "" &&
//                               plain_text.trim() !== ""
//                             ) {
//                               this.setState({
//                                 question: event.editor.getData()
//                               });
//                             } else {
//                               this.setState({
//                                 question: ""
//                               });
//                             }
//                             this.handleValidation();
//                           }}
//                         />
//                       ) : (
//                         ""
//                       )}
//                     </Grid>
//                   </Grid>
//                 </ExpansionPanelDetails>
//               </ExpansionPanel>
//               {this.state.question_type_id === 1 &&
//               storage.getValue("role_id") === 9 ? (
//                 <ExpansionPanel
//                   style={{ background: "#f8f9eb", marginBottom: "10px" }}
//                   expanded={true}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel2a-content"
//                     id="panel2a-header"
//                   >
//                     <Grid container>
//                       <Grid
//                         xs={3}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           Answer
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         item
//                         xs={9}
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           [REQUIRED]
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["mcq_answer"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>
//                   <Divider />
//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid
//                       container
//                       style={{
//                         display: "flex",

//                         flexDirection: "row"
//                       }}
//                     >
//                       <Grid
//                         item
//                         xs={12}
//                         style={{
//                           padding: "20px",
//                           borderRight: "1px solid #ccc"
//                         }}
//                       >
//                         <Typography variant="h5">
//                           Option for the Question
//                         </Typography>

//                         <Box mb={2} mt={2}>
//                           {storage.getValue("role_id") !== 8 ? (
//                             <ImageUpload
//                               addImage={this.addImage.bind(
//                                 this,
//                                 "question_answer"
//                               )}
//                               top={70}
//                               left={454}
//                             />
//                           ) : (
//                             ""
//                           )}

//                           <CKEditor
//                             readOnly={
//                               storage.getValue("role_id") === 8 ||
//                               this.state.answer_disable
//                                 ? true
//                                 : false
//                             }
//                             config={{
//                               extraPlugins: "mathjax",
//                               removePlugins: "image",
//                               removeButtons: "Source",
//                               filebrowserImageBrowseUrl: "",
//                               filebrowserFlashBrowseUrl: "",
//                               filebrowserBrowseUrl: "",
//                               mathJaxLib:
//                                 "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                             }}
//                             type="classic"
//                             data={this.state.option}
//                             onChange={event => {
//                               let html = event.editor.getSnapshot();
//                               let dom = document.createElement("DIV");
//                               dom.innerHTML = html;
//                               let plain_text = dom.textContent || dom.innerText;
//                               if (this.state.answer_disable) {
//                                 if (
//                                   /* eslint-disable-next-line*/
//                                   plain_text.trim() != "" &&
//                                   plain_text.trim() !== ""
//                                 ) {
//                                   this.setState({
//                                     options: {
//                                       ...this.state.options,
//                                       [this.state.option_id]: {
//                                         ...this.state.options[
//                                           this.state.option_id
//                                         ],
//                                         option: event.editor.getData()
//                                       }
//                                     },
//                                     option: event.editor.getData()
//                                   });
//                                 } else {
//                                   this.setState({
//                                     options: {
//                                       ...this.state.options,
//                                       [this.state.option_id]: {
//                                         ...this.state.options[
//                                           this.state.option_id
//                                         ],
//                                         option: ""
//                                       }
//                                     },
//                                     option: ""
//                                   });
//                                 }
//                               } else {
//                                 if (
//                                   /* eslint-disable-next-line*/
//                                   plain_text.trim() != "" &&
//                                   plain_text.trim() !== ""
//                                 ) {
//                                   this.setState({
//                                     moderator_option: {
//                                       ...this.state.moderator_option,
//                                       [this.state.option_id]: {
//                                         ...this.state.moderator_option[
//                                           this.state.option_id
//                                         ],
//                                         option: event.editor.getData()
//                                       }
//                                     },
//                                     option: event.editor.getData()
//                                   });
//                                 } else {
//                                   this.setState({
//                                     moderator_option: {
//                                       ...this.state.moderator_option,
//                                       [this.state.option_id]: {
//                                         ...this.state.moderator_option[
//                                           this.state.option_id
//                                         ],
//                                         option: ""
//                                       }
//                                     },
//                                     option: ""
//                                   });
//                                 }
//                               }
//                               this.handleValidation();
//                             }}
//                           />
//                         </Box>
//                       </Grid>
//                       <Grid item xs={6} style={{ padding: "20px" }}>
//                         <Typography variant="h5">Answer Options</Typography>
//                         <Typography variant="h6" style={{ color: "red" }}>
//                           {this.state.errors["add_more_options"]}
//                         </Typography>

//                         {this.optionComponent(
//                           this.state.moderator_option,
//                           "moderator"
//                         )}
//                       </Grid>
//                       <Grid item xs={6} style={{ padding: "20px" }}>
//                         <Typography variant="h5">
//                           Moderator Answer Options
//                         </Typography>
//                         <Typography variant="h6" style={{ color: "red" }}>
//                           {this.state.errors["add_more_options"]}
//                         </Typography>
//                         {this.optionComponent(this.state.options, "")}
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}
//               {this.state.question_type_id === 2 &&
//               storage.getValue("role_id") !== "" ? (
//                 <ExpansionPanel
//                   style={{
//                     background: "#f8f9eb"
//                   }}
//                   expanded={true}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1a-content"
//                     id="panel1a-header"
//                   >
//                     <Grid container>
//                       <Grid item xs={3}>
//                         <Typography className={classes.heading}>
//                           Answer
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         xs={9}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           [REQUIRED]
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["subjective_answer"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>

//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid container>
//                       <Grid item xs={12}>
//                         <CKEditor
//                           readOnly={
//                             storage.getValue("role_id") === 8 ? true : false
//                           }
//                           config={{
//                             extraPlugins: "mathjax",
//                             removePlugins: "image",
//                             removeButtons: "Source",
//                             filebrowserImageBrowseUrl: "",
//                             filebrowserFlashBrowseUrl: "",
//                             filebrowserBrowseUrl: "",
//                             mathJaxLib:
//                               "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                           }}
//                           type="classic"
//                           data={this.state.question_answer}
//                           onChange={event => {
//                             let html = event.editor.getSnapshot();
//                             let dom = document.createElement("DIV");
//                             dom.innerHTML = html;
//                             let plain_text = dom.textContent || dom.innerText;
//                             if (
//                               /* eslint-disable-next-line*/
//                               plain_text.trim() != "" &&
//                               plain_text.trim() !== ""
//                             ) {
//                               this.setState({
//                                 question_answer: event.editor.getData()
//                               });
//                             } else {
//                               this.setState({
//                                 question_answer: ""
//                               });
//                             }

//                             this.handleValidation();
//                           }}
//                         />
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : storage.getValue("role_id") !== 9 ? (
//                 <ExpansionPanel
//                   style={{ background: "#f8f9eb", marginBottom: "10px" }}
//                   expanded={true}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel2a-content"
//                     id="panel2a-header"
//                   >
//                     <Grid container>
//                       <Grid
//                         xs={3}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           Answer
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         item
//                         xs={9}
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           [REQUIRED]
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["mcq_answer"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>
//                   <Divider />
//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid
//                       container
//                       style={{
//                         display: "flex",

//                         flexDirection: "row"
//                       }}
//                     >
//                       <Grid
//                         item
//                         xs={6}
//                         style={{
//                           padding: "20px",
//                           borderRight: "1px solid #ccc"
//                         }}
//                       >
//                         <Typography variant="h5">
//                           Add option for the Question
//                         </Typography>

//                         <Box mb={2} mt={2}>
//                           {storage.getValue("role_id") !== 8 ? (
//                             <ImageUpload
//                               addImage={this.addImage.bind(this, "option")}
//                               top={133}
//                               left={322}
//                             />
//                           ) : (
//                             ""
//                           )}

//                           <CKEditor
//                             readOnly={
//                               storage.getValue("role_id") === 8 ? true : false
//                             }
//                             config={{
//                               extraPlugins: "mathjax",
//                               removePlugins: "image",
//                               removeButtons: "Source",
//                               filebrowserImageBrowseUrl: "",
//                               filebrowserFlashBrowseUrl: "",
//                               filebrowserBrowseUrl: "",
//                               mathJaxLib:
//                                 "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                             }}
//                             type="classic"
//                             data={this.state.option}
//                             onChange={event => {
//                               let html = event.editor.getSnapshot();
//                               let dom = document.createElement("DIV");
//                               dom.innerHTML = html;
//                               let plain_text = dom.textContent || dom.innerText;
//                               if (
//                                 /* eslint-disable-next-line*/
//                                 plain_text.trim() !== "" &&
//                                 plain_text.trim() !== ""
//                               ) {
//                                 this.setState({
//                                   options: {
//                                     ...this.state.options,
//                                     [this.state.option_id]: {
//                                       ...this.state.options[
//                                         this.state.option_id
//                                       ],
//                                       option: event.editor.getData()
//                                     }
//                                   },
//                                   option: event.editor.getData()
//                                 });
//                               } else {
//                                 this.setState({
//                                   options: {
//                                     ...this.state.options,
//                                     [this.state.option_id]: {
//                                       ...this.state.options[
//                                         this.state.option_id
//                                       ],
//                                       option: ""
//                                     }
//                                   },
//                                   option: ""
//                                 });
//                               }
//                               this.handleValidation();
//                             }}
//                           />
//                         </Box>
//                         <Grid container spacing={1}>
//                           <Grid item xs={6}>
//                             <InputLabel
//                               style={{
//                                 position: "relative",
//                                 marginBottom: "0px"
//                               }}
//                               shrink
//                               htmlFor="bootstrap-input"
//                             >
//                               <Typography variant="h5">
//                                 Is Correct Option
//                               </Typography>
//                             </InputLabel>
//                           </Grid>
//                           <Grid item xs={6}>
//                             <FormControlLabel
//                               control={
//                                 <Switch
//                                   color="primary"
//                                   checked={this.state.answer ? true : false}
//                                   onChange={this.updateAnswerKey.bind(this)}
//                                   value={this.state.answer}
//                                 />
//                               }
//                               label={this.state.answer ? "ON" : "OFF"}
//                             />
//                           </Grid>
//                         </Grid>
//                       </Grid>
//                       <Grid item xs={6} style={{ padding: "20px" }}>
//                         <Typography variant="h5">Answer Options</Typography>
//                         <Typography variant="h6" style={{ color: "red" }}>
//                           {this.state.errors["add_more_options"]}
//                         </Typography>
//                         {this.optionComponent(this.state.options)}

//                         {storage.getValue("role_id") === 6 ? (
//                           <Button
//                             variant="contained"
//                             color="primary"
//                             onClick={this.updateOptions.bind(this)}
//                           >
//                             Add More
//                           </Button>
//                         ) : (
//                           ""
//                         )}

//                         <Grid
//                           container
//                           style={{
//                             marginBottom: "15px",
//                             display: "flex",
//                             alignItems: "center"
//                           }}
//                         >
//                           <Grid>
//                             <img
//                               alt=""
//                               src={InfoIcon}
//                               style={{ width: "30px" }}
//                             />
//                           </Grid>
//                           <Grid xs={9} style={{ marginLeft: 10 }} item>
//                             <Typography
//                               variant={"caption"}
//                               component={"p"}
//                               style={{ color: "#616161" }}
//                             >
//                               Drag and arrange the Options the sequence you
//                               wanted to apper while taking test for Answers
//                             </Typography>
//                           </Grid>
//                         </Grid>
//                         <Grid container style={{ marginBottom: "15px" }}>
//                           <Grid>
//                             <WebCheckWhiteIcon
//                               style={{
//                                 height: "20px",
//                                 width: "20px",
//                                 background: "#8cc842",
//                                 padding: "4px",
//                                 margin: "0 5px",
//                                 borderRadius: "50%"
//                               }}
//                             />
//                           </Grid>
//                           <Grid xs={9} style={{ marginLeft: 10 }} item>
//                             <Typography
//                               variant={"caption"}
//                               component={"p"}
//                               style={{ color: "#616161" }}
//                             >
//                               Indicated the Correct option for the Question
//                             </Typography>
//                           </Grid>
//                         </Grid>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}

//               {storage.getValue("role_id") !== 9 ? (
//                 <ExpansionPanel
//                   style={{ background: "#f8f9eb", marginBottom: "10px" }}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel2a-content"
//                     id="panel2a-header"
//                   >
//                     <Grid container>
//                       <Grid item xs={3}>
//                         <Typography className={classes.heading}>
//                           Question Settings
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         xs={9}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           {this.state.question_type_id === 2
//                             ? "[REQUIRED]"
//                             : "[OPTIONAL]"}
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["score"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>
//                   <ExpansionPanelDetails>
//                     <Grid container spacing={1}>
//                       <Grid item xs={6}>
//                         <FormControl style={{ width: "60%" }}>
//                           <InputLabel
//                             style={{
//                               position: "relative",
//                               marginBottom: "0px"
//                             }}
//                             shrink
//                             htmlFor="bootstrap-input"
//                           >
//                             <Typography variant="h6">Answer Score</Typography>
//                           </InputLabel>
//                           <TextField
//                             disabled={
//                               storage.getValue("role_id") === 8 ? true : false
//                             }
//                             name="score"
//                             id="outlined-password-input"
//                             label="Score for Answers"
//                             className={classes.textField}
//                             type="number"
//                             value={this.state.score}
//                             onChange={this.valueChange.bind(this)}
//                             inputProps={{ min: "1", max: "99", step: "1" }}
//                           />
//                           {/* <span style={{ color: "red" }}>
//                             {this.state.errors["score"]}
//                           </span> */}
//                         </FormControl>
//                       </Grid>
//                       <Grid item xs={6}>
//                         <FormControl style={{ width: "60%" }}>
//                           <InputLabel
//                             style={{
//                               position: "relative",
//                               marginBottom: "0px"
//                             }}
//                             shrink
//                             htmlFor="bootstrap-input"
//                           >
//                             <Typography variant="h6">
//                               Negative Marking
//                             </Typography>
//                           </InputLabel>
//                           <TextField
//                             disabled={
//                               storage.getValue("role_id") === 8 ? true : false
//                             }
//                             id="outlined-password-input"
//                             label="Negative Marking"
//                             name="negative_score"
//                             className={classes.textField}
//                             type="number"
//                             value={this.state.negative_score}
//                             onChange={this.valueChange.bind(this)}
//                             inputProps={{ min: "0", max: "99", step: "0.01" }}
//                           />
//                           <span style={{ color: "red" }}>
//                             {this.state.errors["negative_score"]}
//                           </span>
//                         </FormControl>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") === 8 ? (
//                 <ExpansionPanel
//                   style={{
//                     background: "#f8f9eb",
//                     marginTop: "10px"
//                   }}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1a-content"
//                     id="panel1a-header"
//                   >
//                     <Grid container>
//                       <Grid item xs={3}>
//                         <Typography className={classes.heading}>
//                           Moderator Reference
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         xs={9}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           [REQUIRED]
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["moderator_reference"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>

//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid container>
//                       <Grid item xs={12}>
//                         <CKEditor
//                           type="classic"
//                           data={this.state.moderator_reference}
//                           onChange={event => {
//                             let html = event.editor.getSnapshot();
//                             let dom = document.createElement("DIV");
//                             dom.innerHTML = html;
//                             let plain_text = dom.textContent || dom.innerText;
//                             if (
//                               /* eslint-disable-next-line*/
//                               plain_text.trim() != "" &&
//                               plain_text.trim() !== ""
//                             ) {
//                               this.setState({
//                                 moderator_reference: event.editor.getData()
//                               });
//                             } else {
//                               this.setState({
//                                 moderator_reference: ""
//                               });
//                             }
//                             this.handleValidation();
//                           }}
//                         />
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : storage.getValue("role_id") === 9 ? (
//                 <ExpansionPanel
//                   style={{
//                     background: "#f8f9eb",
//                     marginTop: "10px"
//                   }}
//                   expanded={true}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1a-content"
//                     id="panel1a-header"
//                   >
//                     <Grid container spacing={7}>
//                       <Grid item xs={6}>
//                         <Typography className={classes.heading}>
//                           Reference
//                         </Typography>
//                       </Grid>
//                       <Grid item xs={6}>
//                         <Typography className={classes.heading}>
//                           Reference
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["moderator_reference"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>

//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid container spacing={2}>
//                       <Grid item xs={`6`}>
//                         {this.state.isFetching || !this.props.questionID ? (
//                           <CKEditor
//                             readOnly={true}
//                             config={{
//                               extraPlugins: "mathjax",
//                               removePlugins: "image",
//                               removeButtons: "Source",
//                               filebrowserImageBrowseUrl: "",
//                               filebrowserFlashBrowseUrl: "",
//                               filebrowserBrowseUrl: "",
//                               mathJaxLib:
//                                 "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                             }}
//                             type="classic"
//                             data={this.state.reference}
//                             onChange={event => {
//                               let html = event.editor.getSnapshot();
//                               let dom = document.createElement("DIV");
//                               dom.innerHTML = html;
//                               let plain_text = dom.textContent || dom.innerText;
//                               if (
//                                 /* eslint-disable-next-line*/
//                                 plain_text.trim() != "" &&
//                                 plain_text.trim() !== ""
//                               ) {
//                                 this.setState({
//                                   reference: event.editor.getData()
//                                 });
//                               } else {
//                                 this.setState({
//                                   reference: ""
//                                 });
//                               }

//                               this.handleValidation();
//                             }}
//                           />
//                         ) : (
//                           ""
//                         )}
//                       </Grid>
//                       <Grid item xs={`6`}>
//                         <CKEditor
//                           type="classic"
//                           data={this.state.moderator_reference}
//                           onChange={event => {
//                             let html = event.editor.getSnapshot();
//                             let dom = document.createElement("DIV");
//                             dom.innerHTML = html;
//                             let plain_text = dom.textContent || dom.innerText;
//                             if (
//                               /* eslint-disable-next-line*/
//                               plain_text.trim() != "" &&
//                               plain_text.trim() !== ""
//                             ) {
//                               this.setState({
//                                 moderator_reference: event.editor.getData()
//                               });
//                             } else {
//                               this.setState({
//                                 moderator_reference: ""
//                               });
//                             }
//                             this.handleValidation();
//                           }}
//                         />
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") === 8 ||
//               storage.getValue("role_id") === 9 ? (
//                 <div>
//                   <ExpansionPanel
//                     style={{
//                       background: "#f8f9eb",
//                       marginTop: "10px"
//                     }}
//                   >
//                     <ExpansionPanelSummary
//                       expandIcon={<ExpandMoreIcon />}
//                       aria-controls="panel1a-content"
//                       id="panel1a-header"
//                     >
//                       <Grid container>
//                         <Grid item xs={3}>
//                           <Typography className={classes.heading}>
//                             Moderator Comment
//                           </Typography>
//                         </Grid>
//                         <Grid
//                           xs={9}
//                           item
//                           style={{
//                             display: "flex",
//                             justifyContent: "space-between"
//                           }}
//                         >
//                           <Typography className={classes.heading}>
//                             [OPTIONAL]
//                           </Typography>
//                           <Typography style={{ color: "red" }}>
//                             {this.state.errors["moderator_comment"]}
//                           </Typography>
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelSummary>

//                     <ExpansionPanelDetails style={{ padding: "0px" }}>
//                       <Grid container>
//                         <Grid item xs={12}>
//                           <CKEditor
//                             type="classic"
//                             data={this.state.moderator_comment}
//                             onChange={event => {
//                               let html = event.editor.getSnapshot();
//                               let dom = document.createElement("DIV");
//                               dom.innerHTML = html;
//                               let plain_text = dom.textContent || dom.innerText;
//                               if (
//                                 /* eslint-disable-next-line*/
//                                 plain_text.trim() != "" &&
//                                 plain_text.trim() !== ""
//                               ) {
//                                 this.setState({
//                                   moderator_comment: event.editor.getData()
//                                 });
//                               } else {
//                                 this.setState({
//                                   moderator_comment: ""
//                                 });
//                               }

//                               this.handleValidation();
//                             }}
//                           />
//                         </Grid>
//                       </Grid>
//                     </ExpansionPanelDetails>
//                   </ExpansionPanel>
//                 </div>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") !== 9 ? (
//                 <ExpansionPanel
//                   style={{
//                     background: "#f8f9eb",
//                     marginTop: "10px",
//                     marginBottom: "10px"
//                   }}
//                 >
//                   <ExpansionPanelSummary
//                     expandIcon={<ExpandMoreIcon />}
//                     aria-controls="panel1a-content"
//                     id="panel1a-header"
//                   >
//                     <Grid container>
//                       <Grid item xs={3}>
//                         <Typography className={classes.heading}>
//                           Reference
//                         </Typography>
//                       </Grid>
//                       <Grid
//                         xs={9}
//                         item
//                         style={{
//                           display: "flex",
//                           justifyContent: "space-between"
//                         }}
//                       >
//                         <Typography className={classes.heading}>
//                           [REQUIRED]
//                         </Typography>
//                         <Typography style={{ color: "red" }}>
//                           {this.state.errors["reference"]}
//                         </Typography>
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelSummary>

//                   <ExpansionPanelDetails style={{ padding: "0px" }}>
//                     <Grid container>
//                       <Grid item xs={12}>
//                         <CKEditor
//                           readOnly={
//                             storage.getValue("role_id") === 8 ? true : false
//                           }
//                           config={{
//                             extraPlugins: "mathjax",
//                             removePlugins: "image",
//                             removeButtons: "Source",
//                             filebrowserImageBrowseUrl: "",
//                             filebrowserFlashBrowseUrl: "",
//                             filebrowserBrowseUrl: "",
//                             mathJaxLib:
//                               "//cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=TeX-AMS_HTML"
//                           }}
//                           type="classic"
//                           data={this.state.reference}
//                           onChange={event => {
//                             let html = event.editor.getSnapshot();
//                             let dom = document.createElement("DIV");
//                             dom.innerHTML = html;
//                             let plain_text = dom.textContent || dom.innerText;
//                             if (
//                               /* eslint-disable-next-line*/
//                               plain_text.trim() != "" &&
//                               plain_text.trim() !== ""
//                             ) {
//                               this.setState({
//                                 reference: event.editor.getData()
//                               });
//                               this.handleValidation();
//                             } else {
//                               this.setState({
//                                 reference: ""
//                               });
//                             }
//                             this.handleValidation();
//                           }}
//                         />
//                       </Grid>
//                     </Grid>
//                   </ExpansionPanelDetails>
//                 </ExpansionPanel>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") !== 9 ? (
//                 <Button
//                   type="submit"
//                   variant="contained"
//                   size="medium"
//                   color="primary"
//                   className={classes.uploadButton}
//                 >
//                   {this.state.question_id
//                     ? storage.getValue("role_id") === 9
//                       ? "Approve"
//                       : "Update Question"
//                     : "Add Question"}
//                 </Button>
//               ) : (
//                 ""
//               )}
//               {storage.getValue("role_id") === 9 ? (
//                 <div
//                   style={{
//                     display: "flex",
//                     marginTop: "20px",
//                     justifyContent: "center",
//                     flexDirection: "row"
//                   }}
//                 >
//                   <React.Fragment
//                     style={{
//                       display: "flex",
//                       justifyContent: "center",
//                       flexDirection: "row"
//                     }}
//                   >
//                     <Button
//                       type="submit"
//                       variant="contained"
//                       size="medium"
//                       color="primary"
//                       className={classes.uploadButton}
//                     >
//                       Approve
//                     </Button>
//                     <Button
//                       onClick={this.handleClickRejectOpen}
//                       variant="contained"
//                       size="medium"
//                       color="secondary"
//                       className={classes.uploadButton}
//                     >
//                       Reject
//                     </Button>

//                     <Dialog
//                       disableBackdropClick
//                       fullWidth={"sm"}
//                       maxWidth={"sm"}
//                       onClose={this.handleCloseDialogNew2}
//                       open={this.state.open2}
//                     >
//                       <DialogTitle
//                         id="customized-dialog-title"
//                         onClose={this.handleCloseDialogNew2}
//                       >
//                         Reject Reason
//                       </DialogTitle>
//                       <DialogContent dividers>
//                         <DialogActions
//                           style={{
//                             width: "100%",
//                             display: "flex",
//                             justifyContent: "center",
//                             alignItems: "center",
//                             flexDirection: "column"
//                           }}
//                           margin={{ top: 5 }}
//                         >
//                           <FormControl style={{ width: "100%" }}>
//                             <TextField
//                               name="reason"
//                               id="outlined-multiline-static"
//                               label="Multiline"
//                               multiline
//                               rows="6"
//                               value={this.state.reason}
//                               onChange={this.valueChange.bind(this)}
//                               margin="dense"
//                               variant="outlined"
//                               inputProps={{ maxLength: 250 }}
//                             />
//                           </FormControl>

//                           <FormControl style={{ marginTop: "20px" }}>
//                             <Button
//                               variant="contained"
//                               color="primary"
//                               onClick={this.approveRejectQuestion.bind(
//                                 this,
//                                 this.state.question_id
//                               )}
//                             >
//                               Update
//                             </Button>
//                           </FormControl>
//                         </DialogActions>
//                       </DialogContent>
//                     </Dialog>
//                   </React.Fragment>
//                   <React.Fragment>
//                     <Button
//                       onClick={this.handleClickOpen1}
//                       variant="contained"
//                       size="medium"
//                       color="success"
//                     >
//                       Move to Qc
//                     </Button>
//                     <Dialog
//                       disableBackdropClick
//                       fullWidth={"sm"}
//                       maxWidth={"sm"}
//                       onClose={this.handleCloseDialogNew1}
//                       aria-labelledby="customized-dialog-title"
//                       open={this.state.open1}
//                     >
//                       <DialogTitle
//                         id="customized-dialog-title"
//                         onClose={this.handleCloseDialogNew1}
//                       >
//                         Move to Qc
//                       </DialogTitle>
//                       <DialogContent dividers>
//                         <DialogActions
//                           style={{
//                             width: "100%",
//                             display: "flex",
//                             justifyContent: "center",
//                             alignItems: "center",
//                             flexDirection: "column"
//                           }}
//                           margin={{ top: 5 }}
//                         >
//                           <FormControl
//                             style={{ width: "100%", marginBottom: "20px" }}
//                           >
//                             <Select
//                               style={{ height: "46px" }}
//                               PaperProps={{
//                                 style: {
//                                   maxHeight: ITEM_HEIGHT * 4.5,
//                                   width: 200
//                                 }
//                               }}
//                               value={
//                                 this.state.users_list_id
//                                   ? this.state.users_list_id
//                                   : ""
//                               }
//                               onChange={this.valueChange.bind(this)}
//                               displayEmpty
//                               name="users_list_id"
//                             >
//                               <MenuItem value="" disabled>
//                                 <em>Select Assignee</em>
//                               </MenuItem>
//                               {this.masterRoleNamesLoad(this.state.users_list)}
//                             </Select>
//                           </FormControl>

//                           <FormControl style={{ marginTop: "20px" }}>
//                             <Button
//                               variant="contained"
//                               color="primary"
//                               onClick={this.assignQuestionFlqc.bind(this)}
//                             >
//                               Update
//                             </Button>
//                           </FormControl>
//                         </DialogActions>
//                       </DialogContent>
//                     </Dialog>
//                   </React.Fragment>
//                 </div>
//               ) : (
//                 ""
//               )}
//             </form>
//           </TabContainer>
//         )}
//       </div>
//     );
//   }
// }
// CreateQuestions.propTypes = {
//   classes: PropTypes.object.isRequired,
//   theme: PropTypes.object.isRequired
// };

// const useStyles = theme => ({
//   root: {
//     flexGrow: 1,
//     backgroundColor: theme.palette.background.paper
//   },
//   tabToolbar: {
//     background: "rgba(165, 165, 165, 0.1)",
//     padding: 0
//   },
//   input: {
//     display: "none"
//   },
//   margin: {
//     color: "#616161"
//   },
//   button: {
//     borderRadius: 0
//   },
//   browseButton: {
//     borderRadius: 0,
//     background: "hsl(231, 54%, 50%)",
//     textTransform: "none",
//     fontSize: 17,
//     padding: "5px 12px"
//   },
//   uploadButton: {
//     marginRight: "10px",
//     textTransform: "none",
//     fontSize: 17
//   },
//   topSelectBox: {
//     background: "#3159df",
//     color: "#ffffff",
//     minWidth: "120px",
//     paddingLeft: theme.spacing(2),
//     paddingRight: theme.spacing(1),
//     borderRadius: "20px",
//     borderBottom: "none"
//   },
//   selectEmpty: {
//     marginTop: theme.spacing(2)
//   },
//   verticalLine: {
//     borderLeft: "4px solid #8fc740",
//     height: 500,
//     marginRight: 5
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(16),
//     fontWeight: theme.typography.fontWeightRegular
//   }
// });

// export default withStyles(useStyles, { withTheme: true })(CreateQuestions);
