package DriverInitiate;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import ExcelConfig.excelConfig;
import Login.LoginAuthenticationTestcase;
import PropertyFile.PropertyFileConfig;

public class TestDriverInitial {
	PropertyFileConfig fileconfig;
	LoginAuthenticationTestcase testcase;
	
	public String browsr_name;
	WebDriver driver;
	WebDriverWait wait;
	
	@BeforeTest
	@Parameters("browser")
	public void startDriver(String browsr_name) throws Exception{
		fileconfig=new PropertyFileConfig();
		if(browsr_name.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");	
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().deleteAllCookies();
		}
	}
	
	@Test(priority=0)
	public void orderHomePage() throws Exception{
		testcase=new LoginAuthenticationTestcase(driver);
		try {
			testcase.homePages();
		}catch(Exception e) {
			throw(e);
		}
	}
	@Test(priority=1)
	public void orderLoginPage() throws Exception{
		testcase=new LoginAuthenticationTestcase(driver);
		try {
			testcase.login();
		}catch(Exception e) {
			throw(e);
		}
	}
	
	@Test(priority=2)
	public void orderdDashboardPage() throws Exception{
		testcase=new LoginAuthenticationTestcase(driver);
		try {
			testcase.dashboard();
		}catch(Exception e) {
			throw(e);
		}
	}
//	public static void ExplicitWait(WebDriver driver,WebElement locater) throws Exception
//	{	
//
//		(new WebDriverWait(driver,30)).until(ExpectedConditions
//				.elementToBeClickable(locater));
//
//	}
//	

	
	
}


