package PropertyFile;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class PropertyFileConfig {
	
	Properties pro;
	public PropertyFileConfig() throws Exception{
		try {
			File src=new File("./Configuration/config.property");
			FileInputStream file=new FileInputStream(src);
			pro=new Properties();
			pro.load(file);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
		
		public String getChromeDriver()
		{
			String Chromepath=pro.getProperty("Chrome_Driver");
			return Chromepath;
		}
		
		public String getUrl() {
			String url=pro.getProperty("Candidate_url");
			return url;
		}
		public String getUserName() {
			String usernname=pro.getProperty("Candidate_Username");
			return usernname;
		}
		public String getPassword() {
			String password=pro.getProperty("Candidate_Password");
			return password;
		}
		
		
		
	}


