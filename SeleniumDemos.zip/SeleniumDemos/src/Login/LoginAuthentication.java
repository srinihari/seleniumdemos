/**
 * 
 */
package Login;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ExcelConfig.excelConfig;
import PropertyFile.PropertyFileConfig;
import PropertyFile.PropertyFileConfig;
import org.testng.annotations.Test;


public class LoginAuthentication {

	@FindBy(how=How.XPATH,using="(/html/body/div[1]/div[1]/header/div[2]/div/div/nav/div[1]/a") 
	public WebElement HomePage;
	
	@FindBy(how=How.ID,using="email") 
	public WebElement email;
	
	@FindBy(how=How.ID,using="passwd")
	public WebElement password;
	
	@FindBy(how=How.ID,using="SubmitLogin")
	public WebElement submit;
	
	@FindBy(how=How.LINK_TEXT,using="Order history and details")
	public WebElement orderdetils;
	
	WebDriver driver;
	PropertyFileConfig config;
	excelConfig excel=new excelConfig();
	
	public LoginAuthentication(WebDriver dri) {
		this.driver=dri;
		PageFactory.initElements(dri, this);
	}
	
	@Test
	public void  homePage() throws Exception{
		String Testcase_ID = excel.excelReadData(1, 1, 0);
		String Expected_resul=excel.excelReadData(1, 1, 7);
		try {
			config=new PropertyFileConfig();
			driver.get(config.getUrl());
			excel.writeExcelData(1, 1, 11);
		}catch(Exception e) {
			excel.writeFailData(1, 1, 11);
			throw(e);
		}
	}
	
	@Test
	public void loginPage() throws Exception{
	String Testcase_ID = excel.excelReadData(1, 3, 0);
	String Expected_resul=excel.excelReadData(1, 3, 7);
	try {
		HomePage.click();
		config=new PropertyFileConfig();
		email.sendKeys(config.getUserName());
		password.sendKeys(config.getPassword());
		submit.click();
		excel.writeExcelData(1, 2, 11);
		excel.writeExcelData(1, 3, 11);
		Thread.sleep(3000);

	}catch(Exception e) {
		excel.writeFailData(1, 2, 11);
		excel.writeFailData(1, 3, 11);
		throw(e);
	}
	}
	@Test
	public void dshbordPage() throws Exception{
	String Testcase_ID = excel.excelReadData(1, 4, 0);
	String Expected_resul=excel.excelReadData(1, 4, 7);
	try {
		//ExplicitWait(driver,orderdetils);
		orderdetils.click();
		excel.writeExcelData(1, 4, 11);

	}catch(Exception e) {
		//Exceptionalert("OrderForm Failed", driver);
		driver.switchTo().alert().accept();
		excel.writeFailData(1, 4, 11);
		throw(e);
	}
	
	
	}
	
//	public static void Exceptionalert(String message,WebDriver driver) throws Exception
//	{	
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		js.executeScript("alert('"+message+"')");
//	}	
//	
//	public static void ExplicitWait(WebDriver driver,WebElement locater) throws Exception
//	{	
//
//		(new WebDriverWait(driver,30)).until(ExpectedConditions
//				.elementToBeClickable(locater));
//
//	}
	
	
	
	
	
	
	
	
	
}
	
	
	
	
	
	

	


