import { Component, OnInit,TemplateRef } from '@angular/core';
import Swal from 'sweetalert2';
import * as SecureLS from 'secure-ls';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GlobalService } from '../global.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  submitted=false;
  login_res:Response;
  login_message:any;
  login_user_id:any;
  login_role_id:any;
  otpForm:FormGroup
  constructor( public router:Router,
    public fb:FormBuilder,
    public globalservice:GlobalService,
    public dialog: MatDialog
    ) { }
    private ls=new SecureLS({encodingType:"aes"}) 
  ngOnInit(): void {
    this.loginForm=this.fb.group({
      email:["",[Validators.required]],
      password:["",[Validators.required]],
    });
    this.otpForm=this.fb.group({
      otp:["",Validators.required]
    })
  }

  get f(){
    return this.loginForm.controls;
  }

  get forms(){
    return this.otpForm.controls;
  }

  loginUser(template:TemplateRef<any>,form:FormGroup){
    this.submitted=true;
    if(this.loginForm.invalid){
      return ; 
    }
    let inputData={
      email:form.value.email,
      password:form.value.password
    }
    this.globalservice.userLogin(inputData).subscribe(res =>{
      let resdata=res["content"];
      if(res['status'] == 200){
        this.login_message=res['message'];
        this.login_user_id=res['content'].user_id;
        this.login_role_id=res['content'].role_id;
        this.dialog.open(template,{
          width: '500px',
          height:"500px",
        });  
      }
      if(res['status'] == 422 || res['status'] == 400){
        if(res['status'] == 422 || res['content'].password){
          Swal.fire('Error',res['message'],'error');
        }
        this.submitted=true;
      }
    })
   
  }
  otpSubmit(form:FormGroup){
    this.submitted=true;
    if(this.otpForm.invalid){
      return;
    }
    let input={
      user_id:this.login_user_id,
      role_id:this.login_role_id,
      otp:form.value.otp
    }
    this.globalservice.verifyOtp(input).subscribe((res)=>{
      let otpres=res['content'];
      if(res['status'] == 200){
        this.dialog.closeAll();
        localStorage.setItem('token',otpres.token);
        localStorage.setItem('role', otpres.role_id);
        localStorage.setItem('company_id', otpres.company_id);
        localStorage.setItem('mobile_number', otpres.mobile_number);
        localStorage.setItem('email_address', otpres.email_address);
        localStorage.setItem('createdBy', otpres.id);
        localStorage.setItem('branch_id', otpres.branch_id);
        localStorage.setItem('timezone', otpres.timezone);
        if (otpres.role_id == 1) {
          this.router.navigateByUrl('/user');
        } else if (otpres.role_id == 2 || otpres.role_id == 4) {
          this.router.navigateByUrl('/user');
        }
      }
    })
  }

}
