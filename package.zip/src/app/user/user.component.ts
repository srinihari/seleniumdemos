import { Component, OnInit,ViewChild,ElementRef  } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GlobalService } from '../global.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import timezonesource from "../config/timezone";
import {MatPaginatorModule, PageEvent} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import {CommonService} from "../common.service";
export interface PeriodicElement {
  name: string;
  email: number;
  mobile: number;
  edit: string;
  popover:string;
}
// const ELEMENT_DATA: PeriodicElement[] = [
//   {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
//   {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
//   {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
//   {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
//   {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
//   {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
//   {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
//   {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
//   {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
//   {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
// ];
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})

export class UserComponent implements OnInit {
  displayedColumns: string[] = ['select','id', 'name', 'email', 'mobile','edit','popover'];
  @ViewChild('UploadFileInput') uploadFileInput: ElementRef;
  myfilename = 'Select File';

company_id=localStorage.getItem("company_id");
role_id=localStorage.getItem("role");
user_id=localStorage.getItem("user_id");
emailaddress='';
state:any;
stateList:any;
districtList:any;
district:any;
role=[];
userList:any=[];
submitted=false;
page=1;
city=[];
company:any;
companyList:any;
branch_list:any;
brch:any;
cmpList:any;
userForm: FormGroup;
 timezoneList: any;
 pageSize=10;
 usercount:any;
 cmp_id_edit:any;
alphaPattern = '[a-zA-Z ]*';
addressPattern = '^[#.0-9a-zA-Z ,-/]+$';
numberPattern = '^[0-9]*$';
emailPattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
citys=[];
selection = new SelectionModel<PeriodicElement>(true, []);;
selectedFiles:FileList;
dataSource:any;
  constructor(
    private fb:FormBuilder,
    private globalservice:GlobalService,
    private commonservice:CommonService
  ) { }

  ngOnInit(): void {
    this.timezoneList = timezonesource;
    this.userForm=this.fb.group({
      id:[''],
      company_id:['',this.role_id === "1" ? [Validators.required] : ''],
      branch_id:['',Validators.required],
      name:['',[Validators.required,Validators.pattern(this.alphaPattern)]],
      email:['',[Validators.required,Validators.email]],
      password:[''],
      mobile_number:['',Validators.required],
      city_id:['',Validators.required],
      state_id:['',Validators.required],
      timezone:['',Validators.required],
      // logo:['',Validata]
    })
    this.getState();
    this.getUsers(this.page);
     this.getCompanyList(this.role_id,this.company_id) 
  }
  get f(){
    console.log('sdfsdf222222')

    return this.userForm.controls;
  }

  getState(){
    this.globalservice.getState().subscribe((res)=>{
      this.state=res['content'];
    })
  }
  getDistrict(id){
    this.globalservice.getDistrict(id).subscribe((res)=>{
      this.district=res['content'];
      console.log(this.district);
      // this.districtList=this.district['content'];
    })
  }
  selectState(e){
    this.getDistrict(e.value);
  }

  getCompanyList(role_id,company_id){
    this.globalservice.getCompanyMaster(role_id,company_id).subscribe((res)=>{
      this.companyList=res['body'];
      this.cmpList=this.companyList['content']
      console.log('dfsd fsdf',this.cmpList);
      this.company=this.cmpList[0].company_name;  
    })
  }
   getCompanyBasedBranch(company_id = null, default_branch = null) {
     console.log('sdfsdfsdf',company_id);
    let company = (company_id) ? company_id : this.userForm.value.company_id;
    let filter = {
      company_id : company
    }
    this.globalservice
      .getCompanyBasedBranchs(filter)
      .subscribe((res) => {
        this.branch_list = res['body'];
        this.brch=this.branch_list['content'];
        setTimeout(() => {
          console.log(default_branch);
          this.userForm.controls['branch_id'].setValue(default_branch);
        }, 300);
      });
  }
  getDistrictByState(id, default_city = null) {
    this.globalservice.getDistrict(id).subscribe((res) => {
      this.district = res['content'];
      setTimeout(() => {
        if (default_city) {
          console.log("erwer 333",default_city);
          this.userForm.controls['city_id'].setValue(default_city);
        }
      }, 300);
    });
  }

  createUser(form:FormGroup){
    this.submitted=true;
    if(this.userForm.invalid){
      console.log('sdfsdf')
      return;
    }
    let inputData=form.value;
    // inputData['role_id']=4;
    this.globalservice.createUpdateUser(inputData).subscribe((res)=>{
      const datas=res['body'];
      console.log(datas);
      if(res.body?.['status'] == 200){
        Swal.fire('Success!',res.body?.['content'], 'success');
        this.submitted = false;
        this.reset();
        this.page = 1;
        this.clear();
      }
    })
  }
  getUsers(page){
    this.globalservice.getUsers(this.role_id,page).subscribe((res)=>{
      console.log('sdfsdfsdf',page);
      if (res.body?.['status'] == 200){
        this.userList=res.body?.['content']['rows'];
        this.dataSource = this.userList;
        this.usercount=res.body?.['count'];
        console.log('tses',this.usercount);
        console.log('sdfsdf 3ee',this.userList);
      }
    })
  }
  public changePage(event: PageEvent) {
    let pages = event.pageIndex;
    this.getUsers(pages);
  }
  reset() {
    this.submitted = false;
    this.userForm.reset();
  }
  clear() {
    this.getUsers(this.page);
  }
  editUser(id){
    // Swal.fire({  title: '<strong>HTML <u>example</u></strong>',  icon: 'info',  html:    'You can use <b>bold text</b>, ' +    '<a href="//sweetalert2.github.io">links</a> ' +    'and other HTML tags',  showCloseButton: true,  showCancelButton: true,  focusConfirm: false,  confirmButtonText:    '<i class="fa fa-thumbs-up"></i> Great!',  confirmButtonAriaLabel: 'Thumbs up, great!',  cancelButtonText:    '<i class="fa fa-thumbs-down"></i>',  cancelButtonAriaLabel: 'Thumbs down'})
    // Swal.fire({
    //   title: "Are you sure?",
    //   text: "Aru you Sure want to edit",
    //   type: 'warning',
    //   showConfirmButton: true,
    //   showCancelButton: true     
    // })
    // .then((result) => {

    //   if (result.value) {  
        this.globalservice.getUserById(id).subscribe((res)=>{
          let userData = res.body?.['content'];
          
           if(res['status'] == 200){
            this.getCompanyBasedBranch(userData.content.company_id, userData.content.branch_id);
            this.getDistrictByState(userData.content.state,userData.content.city);
            this.userForm.controls['id'].setValue(userData.content.id);
            this.userForm.controls['name'].setValue(userData.content.name);
             this.userForm.controls['company_id'].setValue(userData.content.company_id);
            // this.cmp_id_edit=80;
            // console.log('sdfsdfsdf',this.cmp_id_edit);
            this.userForm.controls['email'].setValue(userData.content.email);
            this.userForm.controls['mobile_number'].setValue(userData.content.mobile_number);
            this.userForm.controls['state_id'].setValue(userData.content.state);
             this.userForm.controls['city_id'].setValue(userData.content.city);
             this.userForm.controls['timezone'].setValue(userData.content.timezone);
           }
        })
      // }else{
      //   // swal("Fail");
      //   }
    // });
  }

  isAllSelected() {
    console.log('erere rer');
    const numSelected = this.selection.selected.length;
    console.log('sdfsd fsd f',this.selection.selected);
    const numRows = this.dataSource.length;
    return numSelected === numRows;
  }
  masterToggle() {
    console.log('sdfs dfsdf sdf 4r34r4r34 34444');
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.forEach(row => this.selection.select(row));
  }
  logSelection() {
    this.selection.selected.forEach(s => console.log(s['id']));
  }
  fileChangeEvent(event) {
    let files;
    this.selectedFiles=event.target.files;
    console.log('d df df',this.selectedFiles);
    if(this.selectedFiles !=null){
      const file=this.selectedFiles.item(0);
      if(file){
        if(file.size > 1048576){
          Swal.fire('warning','Please Upload logo size lessthan 1 mb');
          // return false;
        }else if( file.type == 'image/jpeg' ||
        file.type == 'image/png' ||
        file.type == 'image/jpg' ||
        file.type == 'image/PNG' ||
        file.type == 'image/JPG' ||
        file.type == 'image/JPEG'){
          files=new Date().getTime() + '_test' +file.name;
          this.commonservice.uploadfile(files, 'image', file.size, file);
        }
      }
    }
    // if (fileInput.target.files && fileInput.target.files[0]) {


    //   this.myfilename = '';
    //   Array.from(fileInput.target.files).forEach((file: File) => {
    //     console.log(file);
    //     this.myfilename += file.name + ',';
    //   });

    //   const reader = new FileReader();
    //   reader.onload = (e: any) => {
    //     const image = new Image();
    //     image.src = e.target.result;
    //     image.onload = rs => {

    //       // Return Base64 Data URL
    //       const imgBase64Path = e.target.result;

    //     };
    //   };
    //   reader.readAsDataURL(fileInput.target.files[0]);

    //   // Reset File Input to Selct Same file again
    //   this.uploadFileInput.nativeElement.value = "";
    // } else {
    //   this.myfilename = 'Select File';
    // }
    // }
  }
}
