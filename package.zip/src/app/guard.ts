import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class CommonguardGuard implements CanActivate {
  constructor(private routes: Router) {}
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    //   if (localStorage.getItem('token') != null) {
    //     if(parseInt(localStorage.getItem('role')) == 2 || parseInt(localStorage.getItem('role')) == 4) {
    //       return true;
    //     } else {
    //       localStorage.removeItem('token');
    //       localStorage.removeItem('role');
    //       localStorage.removeItem('company_id');
    //       localStorage.removeItem('mobile_number');
    //       localStorage.removeItem('email_address');
    //       localStorage.removeItem('state_id');
    //       localStorage.removeItem('district_id');
    //       localStorage.removeItem('state');
    //       localStorage.removeItem('createdBy');
    //       localStorage.removeItem('district');
    //       Swal.fire(
    //         'Expired!',
    //         'Your login token is expired! or Unauthorized to access this page',
    //         'error'
    //       );
    //       this.routes.navigate(['/']);
    //       return false;
    //     }
        
    //   } else {
    //     Swal.fire(
    //       'Expired!',
    //       'Your login token is expired! or Unauthorized to access this page',
    //       'error'
    //     );
    //     this.routes.navigate(['/']);
    //     return false;
    //   }
    
    return true;
  }
  
}
