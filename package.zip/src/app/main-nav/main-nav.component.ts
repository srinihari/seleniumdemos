import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.scss']
})
export class MainNavComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver,public router:Router) {}
  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('company_id');
    localStorage.removeItem('mobile_number');
    localStorage.removeItem('email_address');
    localStorage.removeItem('state_id');
    localStorage.removeItem('district_id');
    localStorage.removeItem('state');
    localStorage.removeItem('createdBy');
    localStorage.removeItem('district');
    this.router.navigateByUrl('/login');
  }
}
