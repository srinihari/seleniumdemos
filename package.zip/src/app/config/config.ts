export const Config={
    baseUrl:"http://localhost:/api/v1/"
}