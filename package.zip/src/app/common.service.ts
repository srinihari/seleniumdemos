// import { Injectable } from '@angular/core';
// import * as S3 from 'aws-sdk/clients/s3';
// import { s3details } from './config/s3config';
// import * as AWS from 'aws-sdk';

// @Injectable({
//   providedIn: 'root',
// })
// export class CommonService {
//   FOLDER = 'company-logo/';
//   constructor() {}

//   uploadfile(file, extern, size, files) {
//     let response;
//     const filterExt = {
//       image: 'jpeg,png,jpg,PNG,JPG,JPEG',
//       excel: 'xls,xlsx',
//       document: 'doc,docx',
//       pdf: 'pdf',
//     };

//     let extensions_validate;
//     let filters = extern.split('|');
//     const bucket = new S3({
//       accessKeyId: s3details.accessKeyId,
//       secretAccessKey: s3details.secretAccessKey,
//       region: s3details.region,
//     });

//     for (let i = 0; i < filters.length; i++) {
//       let filter = filters[i];
//       if (!extensions_validate) {
//         extensions_validate = filterExt[filter];
//       } else {
//         extensions_validate = extensions_validate.concat(
//           ',' + filterExt[filter]
//         );
//       }
//     }

//     var arr_extensions = extensions_validate.split(',');
//     // if (file.size <= size) {
//     //   if (
//     //     arr_extensions.indexOf(
//     //       file.name.split('.')[file.name.split('.').length - 1]
//     //     ) === -1
//     //   ) {
//     //     console.log('erewrwerwe2r');
//     //     response = { status: 422, message: 'Invalid file format' };
//     //   } else {
//     const params = {
//       Bucket: s3details.bucketName,
//       Key: file,
//       Body: files,
//     };
//     console.log(params);

//     bucket.upload(params, function (err, data) {
//       if (err) {
//         console.log('There was an error uploading your file: ', err);
//         return false;
//       }

//       console.log('Successfully uploaded file.', data);
//       return true;
//     });
//     // }
//     return response;
//     // }
//   }
//   generateAwsFileUrl(S3key) {
//     if (S3key !== '' || S3key !== null) {
//       const s3Client = new AWS.S3({
//         region: s3details.region,
//         accessKeyId: s3details.accessKeyId,
//         secretAccessKey: s3details.secretAccessKey,
//       });
//       let params = { Bucket: s3details.bucketName, Key: S3key, Expires: 60 };

//       let S3url = s3Client.getSignedUrl('getObject', params);

//       return { status: 200, s3_url: S3url };
//     } else {
//       return '';
//     }
//   }
// }
