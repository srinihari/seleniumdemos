import { Injectable } from '@angular/core';
import {Config} from "./config/config"
import {HttpClient,HttpRequest} from '@angular/common/http';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  loginURL='admin-user/login';
  otpUrl='admin-user/verify-otp';
  stateUrl='company/get-states';
  constructor(
    private http:HttpClient,
    private router:Router
  ) { }

  userLogin(reqPayload){
    reqPayload["requester_type"] = "web";
     return this.http.post(`${Config.baseUrl}${this.loginURL}`,reqPayload);
  }
  verifyOtp(input){
    return this.http.post(`${Config.baseUrl}${this.otpUrl}`,input);
  }
  getState(){
    return this.http.get(`${Config.baseUrl}${this.stateUrl}`)
  }

  getDistrict(id){
    return this.http.get(`${Config.baseUrl}company/get-district?state_id=${id}`)
  }
  getCompanyMaster(role_id, company_id = false) {
    return this.http.get(
      `${Config.baseUrl}company/get-company?company_id=${company_id}&role_id=${role_id}`,
      {
        observe: 'response',
      }
    );
  }
  addFilter(filters) {
    let requestFilter = '';
    Object.keys(filters).map((key) => {
      if (filters[key] != undefined && filters[key] != '' && filters[key] != null) {
        requestFilter = requestFilter + '&' + key + '=' + filters[key];
      }
    });

    return requestFilter;
  }
  getCompanyBasedBranchs(branch_filter) {
     let requestFilter = this.addFilter(branch_filter);
    return this.http.get(
      `${Config.baseUrl}company/get-branch-details-by-company?${requestFilter}
    `,
      {
        observe: 'response',
      }
    );
  }
  createUpdateUser(requestData) {

    return this.http.post(
      `${Config.baseUrl}admin-user/create-update-user`,
      requestData,
      { observe: 'response' }
    );
  }

  getUsers(role_id,page) {
    return this.http.get(
      `${Config.baseUrl}admin-user/get-all-users?role_id=${role_id}&page=${page}&page_size=10`,
      { observe: 'response' }
    );
  }
  getUserById(id) {
    return this.http.get(
      `${Config.baseUrl}admin-user/get-individual-user?user_id=${id}`,
      { observe: 'response' }
    );
  }
  insertOrUpdateCompanyBranch(inputData) {
    return this.http.post(
      `${Config.baseUrl}company/create-update-branch`,
      inputData,
      {
        observe: 'response',
      }
    );
  }
  getBranchs(filter) {
    let requestFilter = this.addFilter(filter);
    return this.http.get(
      `${Config.baseUrl}company/get-branch-details?${requestFilter}`,
      { observe: 'response' }
    );
  }
  // getBranchByid(company_id, branch_id) {
  //   return this.http.get(
  //     `${Config.baseUrl}company/get-branch-details-indidual?company_id=${company_id}&branch_id=${branch_id}
  //   `,
  //     {
  //       observe: 'response',
  //     }
  //   );
  // }
  branchStatusUpdate(inputvalue) {
    return this.http.post(
      `${Config.baseUrl}company/branch-change-status`,
      inputvalue,
      {
        observe: 'response',
      }
    );
  }

  
}
