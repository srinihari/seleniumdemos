import { Component, OnInit, TemplateRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormsModule,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { GlobalService } from '../services/global.service';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';
import { CommonService } from '../common.service';
declare var swal: any;
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { DatePipe } from '@angular/common';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
const Excel = require('exceljs');
declare var jQuery: any;
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
})
export class EmployeeComponent implements OnInit {
  user_branch = localStorage.getItem('branch_id');
  modalRef: BsModalRef;
  view_branch_id;
  view_first_name;
  view_last_name;
  view_staff_code;
  view_email_address;
  view_mobile_number;
  view_gender;
  view_age;
  view_state;
  view_city;
  view_address_1;
  view_address_2;
  view_File_name;
  excelHeaders: string[];

  exceltemplate: string[];

  templateToExcel: string[][];
  templateReturnToExcel: string[][] = [this.excelHeaders, []];
  roleID = localStorage.getItem('role');
  userID = localStorage.getItem('createdBy');
  login_company_id = localStorage.getItem('company_id');
  alphaPattern = '[a-zA-Z .,]*';
  numberPattern = '^[0-9]*$';
  addressPattern = '^[0-9a-zA-Z ,-/]+$';
  employeeForm: FormGroup;
  emp_bulk_form: FormGroup;
  showLoadMore = false;
  page = 1;
  states = [];
  createUpdateText = 'Create';
  submitted = false;
  citys = [];
  employeeList = [];
  branchs = [];
  filter_branch_id = '';
  filter_staff_code = '';
  manualUpdate = true;
  swal: any;
  enable = true;
  total_count = 0;
  radio_value = 0;
  selectedFiles: FileList;
  bulk_value = 0;
  fileType =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  fileExtension = '.xlsx';
  employe_id;
  corona_status = '';
  allcities: any;
  constructor(
    private modalService: BsModalService,
    public router: Router,
    private route: ActivatedRoute,
    private datepipe: DatePipe,
    private fb: FormBuilder,
    public globalService: GlobalService,
    private spinner: NgxSpinnerService,
    private commonService: CommonService
  ) {}

  ngOnInit() {
  
    document.getElementById('bulk-emp').style.display = 'none';
    this.employeeForm = this.fb.group({
      id: [''],
      company_id: [''],
      branch_id: ['', [Validators.required]],
      first_name: ['', [Validators.required, Validators.pattern(this.alphaPattern)]],
      last_name: ['',[Validators.required, Validators.pattern(this.alphaPattern)]],
      gender: ['', [Validators.required]],
      age: ['', [Validators.required, Validators.min(18), Validators.max(99)]],
      staff_code: ['', [Validators.required]],
      emailaddress: ['', [Validators.required, Validators.email]],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      mobile_number: ['', [Validators.required]],
      locality: ['', [Validators.required]],
      sublocality: [''],
    });
    this.emp_bulk_form = this.fb.group({
      bulk_branch_id: ['', [Validators.required]],
      bulk_file: ['', [Validators.required]],
    });
    this.page = 1;
    this.getStates();
    this.getEmployees();
    this.getCompanyBasedBranch();
    this.getCities();
  }
  getCities() {
    this.globalService.getCities().subscribe((res) => {
      this.allcities = res.body['content'];
      setTimeout(() => {
        this.spinner.hide();
      }, 1000);
    });
  }
  getStates() {
    this.globalService.getStates().subscribe((res) => {
      this.states = res.body['content'];
      setTimeout(() => {
        this.spinner.hide();
      }, 1000);
    });
  }
  getDistrictByState(id, default_state = null) {
    this.globalService.getCityByState(id).subscribe((res) => {
      this.citys = res.body['content'];
      setTimeout(() => {
        this.employeeForm.controls['city'].setValue(default_state);
        this.spinner.hide();
      }, 300);
    });
  }

  selectState(e) {
    this.getDistrictByState(e.target.value);
  }
  get forms() {
    return this.employeeForm.controls;
  }
  get bulkforms() {
    return this.emp_bulk_form.controls;
  }
  createEmployee(form: FormGroup) {
    this.submitted = true;
    if (form.value.age == '0' || form.value.age == '00') {
      Swal.fire(
        'warning',
        'Zero value not accepted Provide valid age',
        'warning'
      );
      return false;
    }
    if (this.employeeForm.invalid) {
      return;
    }

    const inputData = {
      company_id: this.login_company_id,
      branch_id: form.value.branch_id,
      id: form.value.id ? form.value.id : '',
      first_name: form.value.first_name,
      last_name: form.value.last_name,
      gender: form.value.gender,
      age: form.value.age,
      staff_code: form.value.staff_code,
      email_address: form.value.emailaddress,
      phone_number: form.value.mobile_number,
      state: form.value.state,
      city: form.value.city,
      locality: form.value.locality,
      sublocality: form.value.sublocality
    };
    this.spinner.show();
    this.globalService
      .insertOrUpdateCompanyEmployee(inputData)
      .subscribe((res) => {
        if (res.body['status'] === 200) {
          jQuery('#add_employee').modal('hide');
          Swal.fire('Success!', res.body['message'], 'success');
          this.spinner.show();

          this.reset();
          this.page = 1;
          this.clearFilter();
        }
        if(res.body['status'] === 422) {
          this.submitted = true;
          if (res.body['message'].mobile_number) {
            Swal.fire('error!', res.body['message'].mobile_number, 'error');
            this.employeeForm.controls['mobile_number'].setErrors({
              invalid: res.body['message'].mobile_number,
            });
          }
          if (res.body['message'].email) {
            Swal.fire('error!', res.body['message'].email, 'error');
            this.employeeForm.controls['emailaddress'].setErrors({
              invalid: res.body['message'].email,
            });
          }
          if (res.body['message'].staff_code) {
            Swal.fire('error!', res.body['message'].staff_code, 'error');
            this.employeeForm.controls['staff_code'].setErrors({
              invalid: res.body['message'].staff_code,
            });
          }
          if (res.body['message'].age) {
            Swal.fire('error!', res.body['message'].age, 'error');
            /*this.employeeForm.controls['age'].setErrors({
              invalid: res.body['content'].age,
            });*/
          }
        } else if(res.body['status'] === 400) {
          Swal.fire('Warning', res.body['message'], 'warning');
        } 
        this.spinner.hide();
      });
  }

  addFilter(filter_staff_code) {
    this.page = 1;
    this.filter_staff_code = filter_staff_code;
    this.getEmployees();
  }

  clearFilter() {
    this.page = 1;
    this.filter_staff_code = '';
    this.filter_branch_id = '';
    this.getEmployees();
  }

  getEmployees() {
    if (this.page === 1) {
      this.employeeList = [];
    }

    let filter = {
      company_id: this.login_company_id,
      branch_id: parseInt(this.user_branch) ? this.user_branch : this.filter_branch_id,
      corona_status: this.corona_status,
      staff_code: this.filter_staff_code,
      page_size: 10,
    };

    this.spinner.show();
    this.globalService.getCompanyBasedEmployees(this.page, filter).subscribe(
      (res) => {
        this.total_count = res.body['content'].count;

        if (res.body['content']['rows'].length < 10) {
          this.showLoadMore = true;
        }

        if (res.body['status'] === 200) {
          for (let i = 0; i < res.body['content']['rows'].length; i++) {
            this.employeeList.push(res.body['content']['rows'][i]);
            this.spinner.hide();
          }

          if (
            this.employeeList.length < res.body['content'].count &&
            res.body['content']
          ) {
            this.showLoadMore = true;
          } else {
            this.showLoadMore = false;
          }
        } else {
          this.spinner.hide();
          this.showLoadMore = true;
        }
      },
      (error) => {
        this.employeeList = [];
        this.spinner.hide();
        this.showLoadMore = true;
      }
    );
    this.spinner.hide();
  }
  editEmployee(emp_id) {
    this.createUpdateText = 'Edit';
    jQuery('#add_employee').modal('show');
    document.getElementById('bulk-emp').style.display = 'none';
    document.getElementById('single-emp').style.display = 'block';
    this.globalService.getEmployeeByid(emp_id).subscribe((res) => {
      let comp_details = res.body['content'];
      this.employe_id = comp_details.id;
      if (res.body['status'] === 200) {
        this.employeeForm.controls['id'].setValue(comp_details.id);
        this.employeeForm.controls['branch_id'].setValue(
          comp_details.branch_id
        );
        this.employeeForm.controls['first_name'].setValue(
          comp_details.first_name
        );
        this.employeeForm.controls['last_name'].setValue(
          comp_details.last_name
        );
        this.employeeForm.controls['staff_code'].setValue(
          comp_details.staff_code
        );
        this.employeeForm.controls['gender'].setValue(comp_details.gender);
        this.employeeForm.controls['age'].setValue(comp_details.age);
        this.employeeForm.controls['emailaddress'].setValue(
          comp_details.email_address
        );
        this.employeeForm.controls['mobile_number'].setValue(
          comp_details.phone_number
        );
        this.employeeForm.controls['state'].setValue(comp_details.state);
        this.employeeForm.controls['city'].setValue(comp_details.city);
        this.employeeForm.controls['locality'].setValue(comp_details.locality);
        this.employeeForm.controls['sublocality'].setValue(
          comp_details.sublocality
        );
        if (comp_details.state != null) {
          this.getDistrictByState(comp_details.state, comp_details.city);
        }
      }
    });
  }
  reset() {
    this.submitted = false;
    this.employeeForm.reset();
    this.createUpdateText = 'Create';
  }
  reseta() {
    this.submitted = false;
    this.emp_bulk_form.reset();
    this.view_File_name = '';
    this.createUpdateText = 'Create';
  }

  loadMore() {
    this.spinner.show();
    this.page = this.page + 1;
    this.getEmployees();
  }
  getCompanyBasedBranch() {
    let filter = {
      company_id: this.login_company_id,
      branch_id: parseInt(this.user_branch)? this.user_branch : ''
    }
    this.globalService
      .getCompanyBasedBranchs(filter)
      .subscribe((res) => {
        this.branchs = res.body['content'];
        setTimeout(() => {
          this.spinner.hide();
        }, 1000);
      });
  }
  employeeStatusUpdate(value: boolean, employee_id) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'Are you sure you want to Change Status?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#CBCBCB',
      confirmButtonText: 'Confirm',
    }).then((result) => {
      if (result.isConfirmed == true) {
        let status;
        this.manualUpdate = value;
        if (value == false) {
          status = 2;
        } else if (value == true) {
          status = 1;
        }
        let inputvalue = {
          id: employee_id,
          status: status,
        };
        this.globalService.employeeStatusUpdate(inputvalue).subscribe((res) => {
          if (res.body['status'] === 200) {
            Swal.fire('Success!', res.body['message'], 'success');
          }
        });
      } else {
        this.page = 1;
        this.getEmployees();
      }
    });
  }

  async downloadSampleTemplate() {
    let temp = [];
    this.states.forEach((e) => {
      temp.push(e.name);
    });

    let temp1 = [];
    this.allcities.forEach((e) => {
      temp1.push(e.name);
    });

    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');
    worksheet.getCell('A1').value = 'Sno';
    worksheet.getCell('B1').value = 'staff_code';
    worksheet.getCell('C1').value = 'first_name';
    worksheet.getCell('D1').value = 'last_name';
    worksheet.getCell('E1').value = 'phone_number';
    worksheet.getCell('F1').value = 'email_address';
    worksheet.getCell('G1').value = 'gender';
    worksheet.getCell('H1').value = 'age';
    worksheet.getCell('I1').value = 'locality';
    worksheet.getCell('J1').value = 'sublocality';
    worksheet.getCell('K1').value = 'state';
    worksheet.getCell('L1').value = 'city';

    worksheet.getCell('A2').value = '1';
    worksheet.getCell('B2').value = 'v2e10333';
    worksheet.getCell('C2').value = 'Sara';
    worksheet.getCell('D2').value = 'M';
    worksheet.getCell('E2').value = '8945101010';
    worksheet.getCell('F2').value = 'raj@gmail.com';
    worksheet.getCell('G2').value = 'male';
    worksheet.getCell('H2').value = '21';
    worksheet.getCell('I2').value = 'erode';
    worksheet.getCell('J2').value = 'erode';

    const dobCol = worksheet.getColumn(13);
    dobCol.hidden = true;
    const dobCol1 = worksheet.getColumn(14);
    dobCol1.hidden = true;

    worksheet.getCell('K2').dataValidation = {
      type: 'list',
      allowBlank: true,
      showInputMessage: false,
      formulae: ['$M$1:$M$1048576'],
    };
    worksheet.getCell('L2').dataValidation = {
      type: 'list',
      allowBlank: true,
      showInputMessage: false,
      formulae: ['$N$1:$N$1048576'],
    };
    worksheet.getColumn(1).width = 20;
    worksheet.getColumn(2).width = 20;
    worksheet.getColumn(3).width = 20;
    worksheet.getColumn(4).width = 20;
    worksheet.getColumn(5).width = 20;
    worksheet.getColumn(6).width = 20;
    worksheet.getColumn(7).width = 20;
    worksheet.getColumn(8).width = 20;
    worksheet.getColumn(9).width = 20;
    worksheet.getColumn(10).width = 20;
    worksheet.getColumn(11).width = 20;
    worksheet.getColumn(12).width = 20;
    for (let index = 0; index < temp.length; index++) {
      worksheet.getCell(`M${index + 1}`).value = temp[index];
      const element = temp[index];
    }
    for (let j = 0; j < temp1.length; j++) {
      worksheet.getCell(`N${j + 1}`).value = temp1[j];
      const element = temp1[j];
    }
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      FileSaver.saveAs(blob, 'Employee List' + '.xlsx');
    });
  }

  deleteEmployees(company_id, emp_id) {
    this.page = 1;
    this.globalService.deleteEmployee(company_id, emp_id).subscribe((res) => {
      if (res.body['status'] === 200) {
        this.employeeList = [];
        Swal.fire('Success!', 'Employee Deleted Successfully!', 'success');
        this.getEmployees();
      }
    });
  }
  onChange(value) {
    this.bulk_value = value;

    if (value == 1) {
      document.getElementById('bulk-emp').style.display = 'block';
      document.getElementById('single-emp').style.display = 'none';
    }
    if (value == 0) {
      document.getElementById('bulk-emp').style.display = 'none';
      document.getElementById('single-emp').style.display = 'block';
    }
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
    this.view_File_name = this.selectedFiles.item(0).name;
  }

  employeeBulkUpload(form: FormGroup) {
    this.submitted = true;
    if (this.emp_bulk_form.invalid) {
      return;
    }
    let dataExport = [];
    let file;
    let files;
    if (this.selectedFiles != null) {
      const file = this.selectedFiles.item(0);

      if (file.size > 2097152) {
        Swal.fire('warning!', 'File Size Must be under 2 MB', 'warning');
        return false;
      } else if (
        file.type == 'application/vnd.ms-excel' ||
        file.type ==
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      ) {
        let formdata = new FormData();
        formdata.append('file', file);
        formdata.append('company_id', this.login_company_id);
        formdata.append('branch_id', form.value.bulk_branch_id);
        formdata.append('user_id', localStorage.getItem('createdBy'));
        this.spinner.show();
        this.globalService.employeeBulkUpload(formdata).subscribe((res) => {
          if (res.body['status'] === 200) {
            jQuery('#add_employee').modal('hide');
            let bulk_employee = res.body['content'];
            for (let i = 0; i < bulk_employee.length; i++) {
              dataExport.push({
                Sno: i + 1,
                staff_code: bulk_employee[i].staff_code,
                first_name: bulk_employee[i].first_name,
                last_name: bulk_employee[i].last_name,
                phone_number: bulk_employee[i].phone_number,
                email_address: bulk_employee[i].email_address,
                gender: bulk_employee[i].gender,
                age: bulk_employee[i].age,
                locality: bulk_employee[i].locality,
                sublocality: bulk_employee[i].sublocality,
                state: bulk_employee[i].state,
                city: bulk_employee[i].city,
                message: bulk_employee[i].message,
              });
            }
            this.exportExcel(dataExport, 'Employee List');
            Swal.fire('', 'Successfully Upload Refer Excel', 'success');
            this.page = 1;
            this.getEmployees();
            this.emp_bulk_form.reset();
          }
          if (res.body['status'] === 422 || res.body['status'] === 400) {
            this.spinner.hide();
            Swal.fire('error!', res.body['message'], 'error');
          }
          this.spinner.hide();
        });
      } else {
        Swal.fire('', 'xlsx and xlx type file only allowed', 'warning');
        return false;
      }
    } else {
      if (!form.value.bulk_branch_id) {
        Swal.fire('warning!', 'Branch is Required', 'warning');
        return false;
      } else {
        Swal.fire('warning!', 'File is Required', 'warning');
        return false;
      }
    }
  }
  exportExcel(dataToExport: any[], fileName: string) {
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(dataToExport);
    this.autofitColumns(dataToExport, ws);
    const wb: XLSX.WorkBook = { Sheets: { data: ws }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(wb, {
      bookType: 'xlsx',
      type: 'array',
    });
    this.saveExcelFile(excelBuffer, fileName);
  }

  saveExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: this.fileType });
    FileSaver.saveAs(
      data,
      fileName + '_export_' + new Date().getTime() + this.fileExtension
    );
  }

  autofitColumns(json: any[], worksheet: XLSX.WorkSheet, header?: string[]) {
    const jsonKeys = header ? header : Object.keys(json[0]);
    let objectMaxLength = [];
    for (let i = 0; i < json.length; i++) {
      let value = json[i];
      for (let j = 0; j < jsonKeys.length; j++) {
        if (typeof value[jsonKeys[j]] == 'number') {
          objectMaxLength[j] = 10;
        } else {
          const l = value[jsonKeys[j]] ? value[jsonKeys[j]].length : 0;

          objectMaxLength[j] = objectMaxLength[j] >= l ? objectMaxLength[j] : l;
        }
      }

      let key = jsonKeys;
      for (let j = 0; j < key.length; j++) {
        objectMaxLength[j] =
          objectMaxLength[j] >= key[j].length
            ? objectMaxLength[j]
            : key[j].length;
      }
    }

    const wscols = objectMaxLength.map((w) => {
      return { width: w };
    });

    return (worksheet['!cols'] = wscols);
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  employeeView(template: TemplateRef<any>, emp_id) {
    this.modalRef = this.modalService.show(template);
    this.globalService.getEmployeeByid(emp_id).subscribe((res) => {
      let emp_details = res.body['content'];
      this.view_branch_id = emp_details.employee_branch.branch_name;
      this.view_first_name = emp_details.first_name;
      this.view_last_name = emp_details.last_name;
      this.view_staff_code = emp_details.staff_code;
      this.view_gender = emp_details.gender;
      this.view_age = emp_details.age;
      this.view_email_address = emp_details.email_address;
      this.view_mobile_number = emp_details.phone_number;
      this.view_state = emp_details.employee_state.name;
      this.view_city = emp_details.employee_city.name;
      this.view_address_1 = emp_details.locality;
      this.view_address_2 = emp_details.sublocality;
    });
  }
  formReset() {
    this.employeeForm.reset();
    this.view_File_name = '';
    this.createUpdateText = 'Add';
  }
  async downloadSampleTemplate() {
    let temp = [];
    let temp1 = [];
    let temp2 = [];
    let temp3 = [];
    let temp4 = [];
    this.dept.forEach((e) => {
      temp.push(e.name);
    });
    this.class.forEach((e) => {
      temp1.push(e.name);
    });
    this.subjectData.forEach((e) => {
      temp2.push(e.name);
    });
    this.batchData.forEach((e) => {
      temp3.push(e.batch);
    });
    this.prodessorData.forEach((e) => {
      temp4.push(e.first_name);
    });
    const workbook = new Excel.Workbook();
    const worksheet = workbook.addWorksheet("Sheet1");
    worksheet.getCell("A1").value = "Sno";
    worksheet.getCell("B1").value = "Department";
    worksheet.getCell("C1").value = "Classroom";
    worksheet.getCell("D1").value = "Subject";
    worksheet.getCell("E1").value = "Batch";
    worksheet.getCell("F1").value = "Professor";
    worksheet.getCell("G1").value = "Start_date";
    worksheet.getCell("H1").value = "End_date";
    worksheet.getCell("I1").value = "Start_time";
    worksheet.getCell("J1").value = "End_time";
    worksheet.getCell("K1").value = "Days";

    worksheet.getCell("A2").value = "1";

    worksheet.getCell("G2").value = "MM/DD/YYYY";
    worksheet.getCell("H2").value = "MM/DD/YYYY";
    worksheet.getCell("I2").value = "HH-MM";
    worksheet.getCell("J2").value = "HH-MM";
    worksheet.getColumn(9).numFmt = "@";
    worksheet.getColumn(10).numFmt = "@";
    worksheet.getCell("K2").value = "1,2,3,4,5,6,7";

    const dobCol = worksheet.getColumn(12);
    dobCol.hidden = true;
    const dobCol1 = worksheet.getColumn(13);
    dobCol1.hidden = true;
    const dobCol2 = worksheet.getColumn(14);
    dobCol2.hidden = true;
    const dobCol3 = worksheet.getColumn(15);
    dobCol3.hidden = true;
    const dobCol4 = worksheet.getColumn(16);
    dobCol4.hidden = true;
    for (let i = 2; i < 2500; i++) {
      worksheet.getCell(`B${i}`).dataValidation = {
        type: "list",
        allowBlank: true,
        showInputMessage: false,
        formulae: ["$L$1:$L$1048576"],
      };
      worksheet.getCell(`C${i}`).dataValidation = {
        type: "list",
        allowBlank: true,
        showInputMessage: false,
        formulae: ["$M$1:$M$1048576"],
      };

      worksheet.getCell(`D${i}`).dataValidation = {
        type: "list",
        allowBlank: true,
        showInputMessage: false,
        formulae: ["$N$1:$N$1048576"],
      };
      worksheet.getCell(`E${i}`).dataValidation = {
        type: "list",
        allowBlank: true,
        showInputMessage: false,
        formulae: ["$O$1:$O$1048576"],
      };
      worksheet.getCell(`F${i}`).dataValidation = {
        type: "list",
        allowBlank: true,
        showInputMessage: false,
        formulae: ["$P$1:$P$1048576"],
      };
    }
    worksheet.getColumn(1).width = 20;
    worksheet.getColumn(2).width = 20;
    worksheet.getColumn(3).width = 20;
    worksheet.getColumn(4).width = 20;
    worksheet.getColumn(5).width = 20;
    worksheet.getColumn(6).width = 20;
    worksheet.getColumn(7).width = 20;
    worksheet.getColumn(8).width = 20;
    worksheet.getColumn(9).width = 20;
    worksheet.getColumn(10).width = 20;
    worksheet.getColumn(11).width = 20;
    worksheet.getColumn(12).width = 20;
    for (let index = 0; index < temp.length; index++) {
      worksheet.getCell(`L${index + 1}`).value = temp[index];
      const element = temp[index];
    }
    for (let index = 0; index < temp1.length; index++) {
      worksheet.getCell(`M${index + 1}`).value = temp1[index];
      const element = temp1[index];
    }
    for (let index = 0; index < temp2.length; index++) {
      worksheet.getCell(`N${index + 1}`).value = temp2[index];
      const element = temp2[index];
    }
    for (let index = 0; index < temp3.length; index++) {
      worksheet.getCell(`O${index + 1}`).value = temp3[index];
      const element = temp3[index];
    }
    for (let index = 0; index < temp4.length; index++) {
      worksheet.getCell(`P${index + 1}`).value = temp4[index];
      const element = temp4[index];
    }
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      FileSaver.saveAs(blob, "Schedule Sample List" + ".xlsx");
    });
  }
}


