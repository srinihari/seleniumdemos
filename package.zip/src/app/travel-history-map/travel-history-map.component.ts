import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { GlobalService } from '../services/global.service';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
@Component({
  selector: 'app-travel-history-map',
  templateUrl: './travel-history-map.component.html',
  styleUrls: ['./travel-history-map.component.css']
})
export class TravelHistoryMapComponent  implements OnInit {
  company_id = localStorage.getItem('company_id');
  user_branch = localStorage.getItem('branch_id');
  coronoStatus: any = '';
  employeesList = [];
  showLoadMore = false;
  page = 1;
  branch_id: '';
  staff_code = '';
  branchs = [];
  total_count = 10;
  fileType =
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  fileExtension = '.xlsx';
  corona_status: '';
  
  totalcount: any;
  filter_from: any;
  filter_end: any;
  filter_date: any;
  maxDate: Date;
  traceHistoryList=[];
  zoom = 9;
 
  lat =53.67890;
  lng =10.89065;
  mapshow=false;
  timezone = localStorage.getItem("timezone");

  constructor(
    public router: Router,
    private datepipe: DatePipe,
    public globalService: GlobalService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.spinner.show();
    this.page = 1;
    this.getCompanyBasedBranch();
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 1);

  }

  setTimeZone(timezone: any): void {
    this.timezone = timezone;
  }
 
  getTravel() {
    let filters = {
      page: this.page,
      page_size: this.totalcount,
      start_date: this.filter_from,
      end_date: this.filter_end,
      branch_id: parseInt(this.user_branch) ? this.user_branch : ''
    };
    this.globalService
    .getTraceHistory(
      this.staff_code,
      filters,
      this.company_id
    )
    .subscribe((res) => {
      if (res.body['message'].length <= 0) {
        Swal.fire('Error!', 'No Record Found!', 'error');
        this.spinner.hide();
        return false;
      } else {
        let tempArray = res.body['message']['records']['rows']
        ? res.body['message']['records']['rows']
        : [];
      this.totalcount = res.body['message'].total_records;
      for (let i = 0; i < tempArray.length; i++) {
     
        this.traceHistoryList.push(tempArray[i]);
       
        this.lat=parseInt(tempArray[i].latitude);
        this.lng=parseInt(tempArray[i].longitude);
        this.mapshow=true;
      }
    
        this.spinner.hide();
       
      }
    });
    
  }
  getCompanyBasedBranch() {
    let branch_filter = {
        company_id: this.company_id,
        branch_id: parseInt(this.user_branch) ? this.user_branch : ''
      };
    this.globalService
      .getCompanyBasedBranchs(branch_filter)
      .subscribe((res) => {
        this.branchs = res.body['content'];
        setTimeout(() => {
          this.spinner.hide();
        }, 1000);
      });
  }
  loadMore() {
    this.spinner.show();
    this.page = this.page + 1;
    this.getTravel();
  }

  addFilter(filter_date) {
    
    if (!this.staff_code && filter_date === undefined) {
      Swal.fire(
        'warning!',
        'Please provide Date and Staff Code to Search!',
        'warning'
      );
      return false;
    }
  
    if (!this.staff_code) {
      Swal.fire(
        'warning!',
        'Please provide  Staff Code to Search!',
        'warning'
      );
      return false;
    }
    if(filter_date === undefined)
    {
      Swal.fire(
        'warning!',
        'Please provide Date  to Search!',
        'warning'
      );
      return false; 
    }

    let userzone = this.timezone.substr(0, 3) + ":" + this.timezone.substr(3, 2);
    
    let from = moment(filter_date).format('YYYY-MM-DD 00:00:00' + userzone);
    let end = moment(filter_date).format('YYYY-MM-DD 23:59:59' + userzone);

    this.filter_from = this.datepipe.transform(from, "yyyy-MM-dd HH:mm:ss", "+0000");
    this.filter_end = this.datepipe.transform(end, "yyyy-MM-dd HH:mm:ss", "+0000");
 
    this.page = 1;

    this.getTravel();
  }
  clearFilter() {
    this.branch_id = '';
    this.coronoStatus = '';
    this.staff_code = '';
    this.page = 1;
    this.getTravel();
  }
}
