import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelHistoryMapComponent } from './travel-history-map.component';

describe('TravelHistoryMapComponent', () => {
  let component: TravelHistoryMapComponent;
  let fixture: ComponentFixture<TravelHistoryMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelHistoryMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelHistoryMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
