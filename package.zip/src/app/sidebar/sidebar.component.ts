import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  options: FormGroup;

  constructor(fb: FormBuilder,public router:Router) {this.options = fb.group({
    bottom: 0,
    fixed: false,
    top: 0
  }); }

  ngOnInit(): void {
  }
 shouldRun =true;;

 logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('role');
  localStorage.removeItem('company_id');
  localStorage.removeItem('mobile_number');
  localStorage.removeItem('email_address');
  localStorage.removeItem('state_id');
  localStorage.removeItem('district_id');
  localStorage.removeItem('state');
  localStorage.removeItem('createdBy');
  localStorage.removeItem('district');
  this.router.navigateByUrl('/login');
}
}
