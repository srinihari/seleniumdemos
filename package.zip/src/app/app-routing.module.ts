import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ProfessorComponent } from './professor/professor.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {
    path:'login',
    component:LoginComponent,
    pathMatch:'full',
  },
  {
    path:"user",
    component:UserComponent,
    pathMatch:'full',
  },
  {
    path:"professor",
    component:ProfessorComponent,
    pathMatch:'full',
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
