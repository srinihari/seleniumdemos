import { Component, OnInit,ViewChild,ElementRef  } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormArray, AbstractControl } from '@angular/forms';
import { GlobalService } from '../global.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import timezonesource from "../config/timezone";
import {MatPaginatorModule, PageEvent} from '@angular/material/paginator';
import {SelectionModel} from '@angular/cdk/collections';
import {CommonService} from "../common.service";
export interface PeriodicElement {
  name: string;
  email: number;
  mobile: number;
  edit: string;
  popover:string;
}
@Component({
  selector: 'app-professor',
  templateUrl: './professor.component.html',
  styleUrls: ['./professor.component.scss']
})
export class ProfessorComponent implements OnInit {
  displayedColumns: string[] = ['id', 'branch', 'company', 'action'];
  company_id=localStorage.getItem("company_id");
role_id=localStorage.getItem("role");
user_id=localStorage.getItem("user_id");
user_branch = localStorage.getItem('branch_id');
emailaddress='';
state:any;
stateList:any;
districtList:any;
district:any;
role=[];
userList:any=[];
submitted=false;
page=1;
city=[];
company:any;
branchList:any;
branch_list:any;
brch:any;
cmpList:any;
userForm: FormGroup;
 timezoneList: any;
 pageSize=10;
 usercount:any;
 cmp_id_edit:any;
alphaPattern = '[a-zA-Z ]*';
addressPattern = '^[#.0-9a-zA-Z ,-/]+$';
numberPattern = '^[0-9]*$';
emailPattern="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
citys=[];
selection = new SelectionModel<PeriodicElement>(true, []);;
selectedFiles:FileList;
total_count = 0;
dataSource:any;
companyList:any;
createUpdateText = 'Create';
showLoadMore = false;
myFlagForSlideToggle: boolean = true;
  constructor(  
    private fb:FormBuilder,
    private globalservice:GlobalService,
    private commonservice:CommonService) { }

  ngOnInit(): void {
    this.timezoneList = timezonesource;
    this.userForm=this.fb.group({
      id:[''],
      company_id:['',this.role_id === "1" ? [Validators.required] : ''],
      // branch_id:['',Validators.required],
      branch_name:['',[Validators.required,Validators.pattern(this.alphaPattern)]],
      email:['',[Validators.required,Validators.email]],
      locality:['',Validators.required],
      sublocality: [''],
      mobile_number:['',Validators.required],
      city_id:['',Validators.required],
      state_id:['',Validators.required],
      // pin_code: ['', Validators.required,this.fb.array([
      //   this.fb.control(null)
      // ])],
      pin_code: this.fb.array([
        this.fb.control(null)
      ]),
      timezone: ['', Validators.required]
  });
  this.getState();
   this.getBranchs(this.page,this.company_id)
   this.getCompanyList(
    this.role_id,
    this.company_id ? this.company_id : ''
  );
}
get f(){
  console.log('sdfsdf222222')

  return this.userForm.controls;
}

getState(){
  this.globalservice.getState().subscribe((res)=>{
    this.state=res['content'];
  })
}
getDistrict(id){
  this.globalservice.getDistrict(id).subscribe((res)=>{
    this.district=res['content'];
    console.log(this.district);
    // this.districtList=this.district['content'];
  })
}
selectState(e){
  this.getDistrict(e.value);
}

getBranchs(page,company_id){
  if(page == 1){
    this.branchList=[];
  }
  let filter={
    page:page,
    company_id:company_id,
    // branch_id:this.user_branch ? this.user_branch : "",
    page_size:10
  }
  this.globalservice.getBranchs(filter).subscribe((res)=>{
    this.total_count=res.body?.['content'].count;
    if (res.body?.['status'] === 200) {
      if(res.body?.['content'].count > 0){
        this.branchList=this.branchList.concat(res.body?.['content']['rows']);
        this.dataSource = this.branchList;
      }
      console.log('sdfsdfsdf',res.body?.['content'].count)
      this.showLoadMore =this.branchList.length < res.body?.['content'].count ? true : false;
    }
  },
  (error) =>{
    this.branchList=[];
  }
  )
}
 getCompanyBasedBranch(company_id = null, default_branch = null) {
   console.log('sdfsdfsdf',company_id);
  let company = (company_id) ? company_id : this.userForm.value.company_id;
  let filter = {
    company_id : company
  }
  this.globalservice
    .getCompanyBasedBranchs(filter)
    .subscribe((res) => {
      this.branch_list = res['body'];
      this.brch=this.branch_list['content'];
      setTimeout(() => {
        console.log(default_branch);
        this.userForm.controls['branch_id'].setValue(default_branch);
      }, 300);
    });
}
getDistrictByState(id, default_city = null) {
  this.globalservice.getDistrict(id).subscribe((res) => {
    this.district = res['content'];
    setTimeout(() => {
      if (default_city) {
        console.log("erwer 333",default_city);
        this.userForm.controls['city_id'].setValue(default_city);
      }
    }, 300);
  });
}
getCompanyList(role_id,company_id){
  this.globalservice.getCompanyMaster(role_id,company_id).subscribe((res)=>{
    this.companyList=res['body']?.['content'];
    // this.cmpList=this.companyList['content']
    console.log('dfsd fsdf',this.companyList);
    // this.company=this.cmpList[0].company_name;  
  })
}
createBranchs(form:FormGroup){
  this.submitted=true;
  if(this.userForm.invalid){
    console.log('sdfsdf')
    return;
  }
  let inputData=form.value;
  // inputData['role_id']=4;
  this.globalservice.createUpdateUser(inputData).subscribe((res)=>{
    const datas=res['body'];
    console.log(datas);
    if(res.body?.['status'] == 200){
      Swal.fire('Success!',res.body?.['content'], 'success');
      this.submitted = false;
      this.reset();
      this.page = 1;
      this.clear();
    }
  })
}

// public changePage(event: PageEvent) {
//   let pages = event.pageIndex;
//   this.getBranchs(pages);
// }
reset() {
  this.submitted = false;
  this.userForm.reset();
}
clear() {
  this.getBranchs(this.page,this.company_id);
}
loadMore() {
  // this.spinner.show();
  this.page = this.page + 1;
  this.getBranchs(this.page, this.company_id ? this.company_id : '');
}
// editUser(id){
//   // Swal.fire({  title: '<strong>HTML <u>example</u></strong>',  icon: 'info',  html:    'You can use <b>bold text</b>, ' +    '<a href="//sweetalert2.github.io">links</a> ' +    'and other HTML tags',  showCloseButton: true,  showCancelButton: true,  focusConfirm: false,  confirmButtonText:    '<i class="fa fa-thumbs-up"></i> Great!',  confirmButtonAriaLabel: 'Thumbs up, great!',  cancelButtonText:    '<i class="fa fa-thumbs-down"></i>',  cancelButtonAriaLabel: 'Thumbs down'})
//   // Swal.fire({
//   //   title: "Are you sure?",
//   //   text: "Aru you Sure want to edit",
//   //   type: 'warning',
//   //   showConfirmButton: true,
//   //   showCancelButton: true     
//   // })
//   // .then((result) => {

//   //   if (result.value) {  
//       this.globalservice.getUserById(id).subscribe((res)=>{
//         let userData = res.body?.['content'];
        
//          if(res['status'] == 200){
//           this.getCompanyBasedBranch(userData.content.company_id, userData.content.branch_id);
//           this.getDistrictByState(userData.content.state,userData.content.city);
//           this.userForm.controls['id'].setValue(userData.content.id);
//           this.userForm.controls['name'].setValue(userData.content.name);
//            this.userForm.controls['company_id'].setValue(userData.content.company_id);
//           // this.cmp_id_edit=80;
//           // console.log('sdfsdfsdf',this.cmp_id_edit);
//           this.userForm.controls['email'].setValue(userData.content.email);
//           this.userForm.controls['mobile_number'].setValue(userData.content.mobile_number);
//           this.userForm.controls['state_id'].setValue(userData.content.state);
//            this.userForm.controls['city_id'].setValue(userData.content.city);
//            this.userForm.controls['timezone'].setValue(userData.content.timezone);
//          }
//       })
//     // }else{
//     //   // swal("Fail");
//     //   }
//   // });
// }
branchStatusUpdate(event,branch_id) {
  let checked = false;
  Swal.fire({
    title: 'Are you sure?',
    text: 'Are you sure you want to Change Status?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'ok',
  }).then((result) => {
    if(result.value == true){
      let status;
      if(event.checked == false){
        status=2
      }else if(event.checked == true){
        status=1;
      }
      let inputvalue = {
            id: branch_id,
            status: status,
          };
          this.globalservice.branchStatusUpdate(inputvalue).subscribe((res) => {
                if (res.body?.['status'] === 200) {
                  Swal.fire('Success!', res.body?.['message'], 'success');
                }
              });
      console.log('werwe ',event.checked);
    }else {
        this.page = 1;
        this.getBranchs(1, this.company_id);
      }
   
    // console.log('sdfsdfsdf',checked);
    // if (result.isConfirmed == true) {
    //   let status;
    //   this.manualUpdate = value;
    //   if (value == false) {
    //     status = 2;
    //   } else if (value == true) {
    //     status = 1;
    //   }
    //   let inputvalue = {
    //     id: branch_id,
    //     status: status,
    //   };
    //   this.globalService.branchStatusUpdate(inputvalue).subscribe((res) => {
    //     if (res.body['status'] === 200) {
    //       Swal.fire('Success!', res.body['message'], 'success');
    //     }
    //   });
    // 
  });

}
createTextbox(): AbstractControl[] {
  return (<FormArray> this.userForm.get('pin_code')).controls
}

removePhone(index) {
  (this.userForm.get('pin_code') as FormArray).removeAt(index);
}
addPhone(): void {
  (this.userForm.get('pin_code') as FormArray).push(
    this.fb.control(null)
  );
}

}

