import { Injectable } from '@angular/core';
import {
  HttpResponse,
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';
import { Observable, throwError  } from 'rxjs';
import { tap, catchError } from "rxjs/operators";
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Injectable()
export class HttpTokenInterceptor implements HttpInterceptor {
    token:string;
  constructor(
    private routes: Router,
    ) {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const token = localStorage.getItem('token');
    let newHeaders = request.headers;
    if (token) {
      newHeaders = newHeaders.append('Authorization', 'Bearer ' + token);
    }
    const authReq = request.clone({ headers: newHeaders });
    return next.handle(authReq).pipe(
        tap(event => {
          if (event instanceof HttpResponse) { 
            if(event.body['status'] != 200){
              Swal.fire(
                'Error!',
                'Something went wrong, Please try again later',
                'error'
              );
            }
          }
        }),
        catchError((error) => {
          if(error.status ==401) {
            Swal.fire(
              'Information!',
              'Your not authorized to visit this page or session expired',
              'error'
            );
            this.routes.navigate(['/']);
          }
          return throwError(error);
        })
      );
  }
}
